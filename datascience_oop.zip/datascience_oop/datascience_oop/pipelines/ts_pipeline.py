import pandas as pd
import numpy as np
from ..core.base import PipelineComponent

class TimeSeriesPipeline:
    """Pipeline pour séries temporelles."""
    
    def __init__(self):
        self.components = {
            'loader': self.TimeSeriesLoader(),
            'preprocessor': self.TimeSeriesPreprocessor(),
            'feature_engineer': self.TimeSeriesFeatureEngineer(),
            'model': self.TimeSeriesModel(),
            'evaluator': self.TimeSeriesEvaluator()
        }
    
    class TimeSeriesLoader(PipelineComponent):
        def fit(self, X, y=None):
            pass
        
        def transform(self, X):
            # Suppose que X est un DataFrame avec une colonne 'date' et une colonne 'sales'
            if 'date' in X.columns and 'sales' in X.columns:
                data = X.copy()
                data['date'] = pd.to_datetime(data['date'])
                data = data.set_index('date')
                return data['sales']
            else:
                raise ValueError("Les colonnes 'date' et 'sales' sont requises")
    
    class TimeSeriesPreprocessor(PipelineComponent):
        def fit(self, X, y=None):
            pass
        
        def transform(self, series):
            # Détection et traitement des valeurs aberrantes
            # Interpolation des valeurs manquantes
            series_clean = series.interpolate(method='time')
            return series_clean
    
    class TimeSeriesFeatureEngineer(PipelineComponent):
        def __init__(self, n_lags=7, window_sizes=[7, 30]):
            self.n_lags = n_lags
            self.window_sizes = window_sizes
        
        def fit(self, X, y=None):
            pass
        
        def transform(self, series):
            features = pd.DataFrame(index=series.index)
            
            # Lag features
            for lag in range(1, self.n_lags + 1):
                features[f'lag_{lag}'] = series.shift(lag)
            
            # Rolling statistics
            for window in self.window_sizes:
                features[f'rolling_mean_{window}'] = series.rolling(window=window).mean()
                features[f'rolling_std_{window}'] = series.rolling(window=window).std()
            
            # Features temporelles
            features['day_of_week'] = series.index.dayofweek
            features['month'] = series.index.month
            features['quarter'] = series.index.quarter
            
            return features.dropna()
    
    class TimeSeriesModel(PipelineComponent):
        def __init__(self, model_type='arima'):
            self.model_type = model_type
        
        def fit(self, X, y):
            if self.model_type == 'arima':
                from statsmodels.tsa.arima.model import ARIMA
                self.model = ARIMA(y, order=(1,1,1))
                self.model_fit = self.model.fit()
        
        def transform(self, X):
            if self.model_type == 'arima':
                return self.model_fit.forecast(steps=len(X))
    
    class TimeSeriesEvaluator:
        def evaluate(self, predictions, actual):
            from sklearn.metrics import mean_absolute_error, mean_squared_error
            mae = mean_absolute_error(actual, predictions)
            rmse = np.sqrt(mean_squared_error(actual, predictions))
            mape = np.mean(np.abs((actual - predictions) / actual)) * 100
            return {'MAE': mae, 'RMSE': rmse, 'MAPE': mape}