from .ml_pipeline import MLPipeline
from ..models.cv_strategies import CrossValidationContext

class MLPipelineWithCV(MLPipeline):
    """Pipeline ML avec support de validation croisée."""
    
    def __init__(self, components, cv_strategy=None):
        super().__init__(components)
        self.cv_context = CrossValidationContext(cv_strategy)
    
    def cross_validate(self, X, y, scoring='accuracy'):
        """Exécute la validation croisée."""
        model = self.components['model'].model
        
        if model is None:
            raise ValueError("Le modèle doit être entraîné d'abord")
        
        return self.cv_context.perform_cv(model, X, y, scoring)
    
    def hyperparameter_tuning(self, param_grid, X, y, cv_strategy=None):
        """Recherche d'hyperparamètres avec validation croisée."""
        from sklearn.model_selection import GridSearchCV
        
        # Utiliser la stratégie fournie ou celle par défaut
        cv = cv_strategy or self.cv_context.strategy.cv
        
        model_class = self.components['model'].model_class
        model_params = self.components['model'].model_params
        
        model = model_class(**model_params)
        
        grid_search = GridSearchCV(
            model, param_grid,
            cv=cv,
            scoring='accuracy',
            n_jobs=-1,
            verbose=1
        )
        
        grid_search.fit(X, y)
        
        # Mettre à jour le modèle avec les meilleurs paramètres
        self.components['model'].model = grid_search.best_estimator_
        
        return {
            'best_params': grid_search.best_params_,
            'best_score': grid_search.best_score_,
            'cv_results': grid_search.cv_results_
        }