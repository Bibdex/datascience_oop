import pickle
from ..core.base import PipelineComponent
from ..data.loader import DataLoader
from ..data.transformer import StandardScaler
from ..models.trainer import ModelTrainer
from ..models.evaluator import ModelEvaluator
from sklearn.metrics import accuracy_score, classification_report

class MLPipeline:
    """Pipeline ML complet."""
    
    def __init__(self, components):
        self.components = components
        self.history = []
    
    def run(self, data):
        """Exécute tous les composants en séquence."""
        current_data = data
        
        for name, component in self.components.items():
            print(f"Exécution du composant: {name}")
            
            # Si c'est le DataLoader, il retourne un dict
            if name == 'data_loader':
                current_data = component.transform(current_data)
            else:
                # Pour les autres composants, appliquer aux données d'entraînement
                if 'X_train' in current_data:
                    if name == 'scaler':
                        component.fit(current_data['X_train'])
                        current_data['X_train_scaled'] = component.transform(current_data['X_train'])
                        current_data['X_test_scaled'] = component.transform(current_data['X_test'])
                    elif name == 'model':
                        component.fit(current_data['X_train_scaled'], current_data['y_train'])
                        current_data['y_pred'] = component.transform(current_data['X_test_scaled'])
                        current_data['y_pred_train'] = component.transform(current_data['X_train_scaled'])
                
            self.history.append((name, current_data.copy()))
        
        return current_data
    
    def evaluate(self, results):
        """Évalue les performances du modèle."""
        metrics = {}
        
        # Accuracy
        metrics['accuracy'] = accuracy_score(
            results['y_test'], results['y_pred']
        )
        
        # Classification report
        metrics['report'] = classification_report(
            results['y_test'], results['y_pred']
        )
        
        # Feature importance (si disponible)
        if hasattr(self.components['model'].model, 'feature_importances_'):
            metrics['feature_importance'] = dict(zip(
                results['X_train'].columns,
                self.components['model'].model.feature_importances_
            ))
        
        return metrics
    
    def save(self, filepath):
        """Sauvegarde le pipeline."""
        with open(filepath, 'wb') as f:
            pickle.dump(self, f)
    
    @classmethod
    def load(cls, filepath):
        """Charge un pipeline sauvegardé."""
        with open(filepath, 'rb') as f:
            return pickle.load(f)


class ValidatedMLPipeline(MLPipeline):
    """Pipeline ML avec validation intégrée."""
    
    def __init__(self, components, validation_rules=None):
        super().__init__(components)
        from ..data.validator import DataValidator
        self.validator = DataValidator(validation_rules)
    
    def run_with_validation(self, data, fail_fast=False):
        """Exécute le pipeline avec validation préalable."""
        
        # Étape 1: Validation des données d'entrée
        print("=== Validation des données d'entrée ===")
        validation_report = self.validator.validate(data)
        
        if validation_report['errors'] > 0:
            print(f" {validation_report['errors']} erreurs de validation trouvées")
            
            if fail_fast:
                raise ValueError("Échec de validation des données")
            else:
                print("Continuer malgré les erreurs...")
        
        # Sauvegarder le rapport de validation
        self.validator.save_report('validation_report.json')
        
        # Étape 2: Exécution normale du pipeline
        return super().run(data)