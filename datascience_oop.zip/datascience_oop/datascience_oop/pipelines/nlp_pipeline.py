import pandas as pd
import numpy as np
import json
from ..core.base import PipelineComponent

class TextClassificationPipeline:
    """Pipeline pour classification de texte."""
    
    def __init__(self):
        self.components = {
            'loader': self.TextLoader(),
            'preprocessor': self.TextPreprocessor(),
            'vectorizer': self.TextVectorizer(),
            'model': self.TextModel(),
            'evaluator': self.TextEvaluator()
        }
    
    class TextLoader(PipelineComponent):
        def fit(self, X, y=None):
            pass
        
        def transform(self, filepath):
            if filepath.endswith('.json'):
                with open(filepath, 'r') as f:
                    data = json.load(f)
                return pd.DataFrame(data)
            else:
                return pd.read_csv(filepath)
    
    class TextPreprocessor(PipelineComponent):
        def fit(self, X, y=None):
            pass
        
        def transform(self, texts):
            import re
            import nltk
            from nltk.corpus import stopwords
            from nltk.stem import WordNetLemmatizer
            
            # Télécharger les ressources NLTK si nécessaire
            try:
                nltk.data.find('tokenizers/punkt')
            except LookupError:
                nltk.download('punkt')
                nltk.download('stopwords')
                nltk.download('wordnet')
            
            processed_texts = []
            for text in texts:
                # Convertir en minuscules
                text = text.lower()
                
                # Supprimer les caractères spéciaux et chiffres
                text = re.sub(r'[^a-zA-Z\s]', '', text)
                
                # Tokenization
                tokens = nltk.word_tokenize(text)
                
                # Supprimer les stopwords
                stop_words = set(stopwords.words('english'))
                tokens = [word for word in tokens if word not in stop_words]
                
                # Lemmatisation
                lemmatizer = WordNetLemmatizer()
                tokens = [lemmatizer.lemmatize(word) for word in tokens]
                
                processed_texts.append(' '.join(tokens))
            
            return processed_texts
    
    class TextVectorizer(PipelineComponent):
        def __init__(self, method='tfidf', max_features=5000):
            self.method = method
            self.max_features = max_features
        
        def fit(self, X, y=None):
            if self.method == 'tfidf':
                from sklearn.feature_extraction.text import TfidfVectorizer
                self.vectorizer = TfidfVectorizer(max_features=self.max_features)
                self.vectorizer.fit(X)
        
        def transform(self, X):
            return self.vectorizer.transform(X)
    
    class TextModel(PipelineComponent):
        def __init__(self, model_type='logistic_regression'):
            self.model_type = model_type
        
        def fit(self, X, y):
            if self.model_type == 'logistic_regression':
                from sklearn.linear_model import LogisticRegression
                self.model = LogisticRegression(max_iter=1000)
                self.model.fit(X, y)
        
        def transform(self, X):
            return self.model.predict(X)
    
    class TextEvaluator:
        def evaluate(self, y_true, y_pred):
            from sklearn.metrics import classification_report, confusion_matrix
            return {
                'report': classification_report(y_true, y_pred),
                'confusion_matrix': confusion_matrix(y_true, y_pred)
            }