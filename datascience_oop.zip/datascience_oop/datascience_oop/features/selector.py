"""
Sélection de features.
"""

import pandas as pd
import numpy as np
from typing import Optional, Dict, Any, List, Union
from abc import ABC, abstractmethod
from sklearn.feature_selection import (
    VarianceThreshold, SelectKBest, SelectFromModel,
    RFE, f_classif, mutual_info_classif, f_regression
)
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from ..core.base import PipelineComponent
from ..core.decorators import timing_decorator, log_execution

class FeatureSelector(PipelineComponent, ABC):
    """Classe abstraite pour la sélection de features."""
    
    @abstractmethod
    def select_features(self, X: pd.DataFrame, y: Optional[pd.Series] = None) -> pd.DataFrame:
        """Sélectionne les features."""
        pass
    
    def process(self, data: Any) -> Any:
        """Interface pour PipelineComponent."""
        if isinstance(data, tuple) and len(data) == 2:
            X, y = data
            return self.select_features(X, y)
        elif isinstance(data, pd.DataFrame):
            return self.select_features(data)
        return data

class VarianceThresholdSelector(FeatureSelector):
    """Sélection de features basée sur la variance."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'threshold': 0.0,
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.selector = None
        self.selected_features = []
    
    def fit(self, X: pd.DataFrame, y: Optional[pd.Series] = None):
        """Ajuste le sélecteur."""
        self.selector = VarianceThreshold(threshold=self.config['threshold'])
        self.selector.fit(X)
        self.selected_features = X.columns[self.selector.get_support()].tolist()
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def select_features(self, X: pd.DataFrame, y: Optional[pd.Series] = None) -> pd.DataFrame:
        """Sélectionne les features avec une variance suffisante."""
        if not self.is_fitted:
            self.fit(X, y)
        
        X_selected = self.selector.transform(X)
        
        # Créer un DataFrame avec les features sélectionnées
        result = pd.DataFrame(
            X_selected,
            columns=self.selected_features,
            index=X.index
        )
        
        if self.config['verbose']:
            n_removed = X.shape[1] - result.shape[1]
            print(f"Features sélectionnées: {result.shape[1]}/{X.shape[1]} "
                  f"({n_removed} features à faible variance supprimées)")
        
        return result

class CorrelationSelector(FeatureSelector):
    """Sélection de features basée sur la corrélation."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'threshold': 0.9,
            'method': 'pearson',
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.selected_features = []
        self.correlation_matrix = None
    
    def fit(self, X: pd.DataFrame, y: Optional[pd.Series] = None):
        """Ajuste le sélecteur."""
        # Calculer la matrice de corrélation
        self.correlation_matrix = X.corr(method=self.config['method']).abs()
        
        # Trouver les features à supprimer
        upper_tri = self.correlation_matrix.where(
            np.triu(np.ones(self.correlation_matrix.shape), k=1).astype(bool)
        )
        
        # Trouver les features avec corrélation > seuil
        to_drop = [
            column for column in upper_tri.columns 
            if any(upper_tri[column] > self.config['threshold'])
        ]
        
        # Features sélectionnées
        self.selected_features = [col for col in X.columns if col not in to_drop]
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def select_features(self, X: pd.DataFrame, y: Optional[pd.Series] = None) -> pd.DataFrame:
        """Sélectionne les features non corrélées."""
        if not self.is_fitted:
            self.fit(X, y)
        
        result = X[self.selected_features]
        
        if self.config['verbose']:
            n_removed = X.shape[1] - result.shape[1]
            print(f"Features sélectionnées: {result.shape[1]}/{X.shape[1]} "
                  f"({n_removed} features corrélées supprimées)")
        
        return result

class StatisticalSelector(FeatureSelector):
    """Sélection de features basée sur des tests statistiques."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'k': 10,
            'score_func': 'f_classif',  # 'f_classif', 'mutual_info_classif', 'f_regression'
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.selector = None
        self.selected_features = []
        self.feature_scores = {}
    
    def fit(self, X: pd.DataFrame, y: pd.Series):
        """Ajuste le sélecteur."""
        if y is None:
            raise ValueError("y est requis pour StatisticalSelector")
        
        # Sélectionner la fonction de score
        if self.config['score_func'] == 'f_classif':
            score_func = f_classif
        elif self.config['score_func'] == 'mutual_info_classif':
            score_func = mutual_info_classif
        elif self.config['score_func'] == 'f_regression':
            score_func = f_regression
        else:
            raise ValueError(f"Fonction de score non reconnue: {self.config['score_func']}")
        
        # Créer le sélecteur
        self.selector = SelectKBest(
            score_func=score_func,
            k=min(self.config['k'], X.shape[1])
        )
        
        # Ajuster
        self.selector.fit(X, y)
        
        # Features sélectionnées
        self.selected_features = X.columns[self.selector.get_support()].tolist()
        
        # Scores des features
        self.feature_scores = dict(zip(
            X.columns,
            self.selector.scores_
        ))
        
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def select_features(self, X: pd.DataFrame, y: Optional[pd.Series] = None) -> pd.DataFrame:
        """Sélectionne les k meilleures features."""
        if not self.is_fitted:
            if y is None:
                raise ValueError("y est requis pour l'ajustement initial")
            self.fit(X, y)
        
        X_selected = self.selector.transform(X)
        
        # Créer un DataFrame avec les features sélectionnées
        result = pd.DataFrame(
            X_selected,
            columns=self.selected_features,
            index=X.index
        )
        
        if self.config['verbose']:
            print(f"Features sélectionnées: {result.shape[1]}/{X.shape[1]}")
            print("Top 10 des features par score:")
            sorted_scores = sorted(self.feature_scores.items(), key=lambda x: x[1], reverse=True)
            for feature, score in sorted_scores[:10]:
                print(f"  {feature}: {score:.4f}")
        
        return result
    
    def get_feature_scores(self) -> Dict[str, float]:
        """Retourne les scores de toutes les features."""
        return self.feature_scores.copy()

class ModelBasedSelector(FeatureSelector):
    """Sélection de features basée sur l'importance du modèle."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'model_type': 'random_forest',  # 'random_forest', 'xgboost', 'logistic'
            'threshold': 'mean',  # 'mean', 'median', ou une valeur numérique
            'max_features': None,
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.selector = None
        self.selected_features = []
        self.feature_importances = {}
    
    def fit(self, X: pd.DataFrame, y: pd.Series):
        """Ajuste le sélecteur."""
        if y is None:
            raise ValueError("y est requis pour ModelBasedSelector")
        
        # Sélectionner le modèle
        if self.config['model_type'] == 'random_forest':
            if len(y.unique()) > 2:  # Classification multi-classe
                model = RandomForestClassifier(n_estimators=100, random_state=42)
            else:  # Régression ou classification binaire
                model = RandomForestRegressor(n_estimators=100, random_state=42)
        else:
            raise ValueError(f"Type de modèle non reconnu: {self.config['model_type']}")
        
        # Créer le sélecteur
        self.selector = SelectFromModel(
            model,
            threshold=self.config['threshold'],
            max_features=self.config['max_features']
        )
        
        # Ajuster
        self.selector.fit(X, y)
        
        # Features sélectionnées
        self.selected_features = X.columns[self.selector.get_support()].tolist()
        
        # Importances des features
        if hasattr(self.selector.estimator_, 'feature_importances_'):
            self.feature_importances = dict(zip(
                X.columns,
                self.selector.estimator_.feature_importances_
            ))
        
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def select_features(self, X: pd.DataFrame, y: Optional[pd.Series] = None) -> pd.DataFrame:
        """Sélectionne les features basées sur l'importance du modèle."""
        if not self.is_fitted:
            if y is None:
                raise ValueError("y est requis pour l'ajustement initial")
            self.fit(X, y)
        
        X_selected = self.selector.transform(X)
        
        # Créer un DataFrame avec les features sélectionnées
        result = pd.DataFrame(
            X_selected,
            columns=self.selected_features,
            index=X.index
        )
        
        if self.config['verbose']:
            print(f"Features sélectionnées: {result.shape[1]}/{X.shape[1]}")
            
            if self.feature_importances:
                print("Top 10 des features par importance:")
                sorted_importances = sorted(
                    self.feature_importances.items(), 
                    key=lambda x: x[1], 
                    reverse=True
                )
                for feature, importance in sorted_importances[:10]:
                    print(f"  {feature}: {importance:.4f}")
        
        return result
    
    def get_feature_importances(self) -> Dict[str, float]:
        """Retourne les importances de toutes les features."""
        return self.feature_importances.copy()

class RFESelector(FeatureSelector):
    """Sélection récursive de features (RFE)."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'n_features_to_select': None,
            'step': 1,
            'estimator': 'random_forest',
            'verbose': 0,
            'verbose_user': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.selector = None
        self.selected_features = []
        self.ranking = {}
    
    def fit(self, X: pd.DataFrame, y: pd.Series):
        """Ajuste le sélecteur RFE."""
        if y is None:
            raise ValueError("y est requis pour RFESelector")
        
        # Sélectionner l'estimateur
        if self.config['estimator'] == 'random_forest':
            if len(y.unique()) > 2:
                estimator = RandomForestClassifier(n_estimators=100, random_state=42)
            else:
                estimator = RandomForestRegressor(n_estimators=100, random_state=42)
        else:
            raise ValueError(f"Estimateur non reconnu: {self.config['estimator']}")
        
        # Créer le sélecteur RFE
        self.selector = RFE(
            estimator=estimator,
            n_features_to_select=self.config['n_features_to_select'],
            step=self.config['step'],
            verbose=self.config['verbose']
        )
        
        # Ajuster
        self.selector.fit(X, y)
        
        # Features sélectionnées
        self.selected_features = X.columns[self.selector.get_support()].tolist()
        
        # Ranking des features
        self.ranking = dict(zip(X.columns, self.selector.ranking_))
        
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def select_features(self, X: pd.DataFrame, y: Optional[pd.Series] = None) -> pd.DataFrame:
        """Sélectionne les features avec RFE."""
        if not self.is_fitted:
            if y is None:
                raise ValueError("y est requis pour l'ajustement initial")
            self.fit(X, y)
        
        X_selected = self.selector.transform(X)
        
        # Créer un DataFrame avec les features sélectionnées
        result = pd.DataFrame(
            X_selected,
            columns=self.selected_features,
            index=X.index
        )
        
        if self.config['verbose_user']:
            print(f"Features sélectionnées: {result.shape[1]}/{X.shape[1]}")
            print("Ranking des features (1 = sélectionnée):")
            sorted_ranking = sorted(self.ranking.items(), key=lambda x: x[1])
            for feature, rank in sorted_ranking[:10]:
                print(f"  {feature}: {rank}")
        
        return result
    
    def get_feature_ranking(self) -> Dict[str, int]:
        """Retourne le ranking de toutes les features."""
        return self.ranking.copy()