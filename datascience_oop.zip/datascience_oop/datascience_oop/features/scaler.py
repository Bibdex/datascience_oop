"""
Normalisation et standardisation des features.
"""

import pandas as pd
import numpy as np
from typing import Optional, Dict, Any, List, Union
from abc import ABC, abstractmethod
from sklearn.preprocessing import (
    StandardScaler as SklearnStandardScaler,
    MinMaxScaler as SklearnMinMaxScaler,
    RobustScaler as SklearnRobustScaler,
    MaxAbsScaler,
    Normalizer
)
from ..core.base import PipelineComponent
from ..core.decorators import timing_decorator, log_execution

class FeatureScaler(PipelineComponent, ABC):
    """Classe abstraite pour la normalisation des features."""
    
    @abstractmethod
    def scale(self, X: pd.DataFrame) -> pd.DataFrame:
        """Normalise les features."""
        pass
    
    def process(self, data: Any) -> Any:
        """Interface pour PipelineComponent."""
        if isinstance(data, pd.DataFrame):
            return self.scale(data)
        return data

class StandardScaler(FeatureScaler):
    """Standardisation (moyenne=0, écart-type=1)."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'with_mean': True,
            'with_std': True,
            'columns': None,
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.scaler = None
        self.columns_to_scale = []
        self.feature_names = []
    
    def fit(self, X: pd.DataFrame, y=None):
        """Ajuste le scaler."""
        # Déterminer les colonnes à normaliser
        if self.config['columns'] is None:
            # Toutes les colonnes numériques
            self.columns_to_scale = X.select_dtypes(include=[np.number]).columns.tolist()
        else:
            # Colonnes spécifiées
            self.columns_to_scale = [col for col in self.config['columns'] if col in X.columns]
        
        if len(self.columns_to_scale) == 0:
            self.is_fitted = True
            return self
        
        # Sauvegarder les noms des features
        self.feature_names = self.columns_to_scale
        
        # Créer et ajuster le scaler
        self.scaler = SklearnStandardScaler(
            with_mean=self.config['with_mean'],
            with_std=self.config['with_std']
        )
        
        self.scaler.fit(X[self.columns_to_scale])
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def scale(self, X: pd.DataFrame) -> pd.DataFrame:
        """Standardise les features."""
        if not self.is_fitted:
            self.fit(X)
        
        X_scaled = X.copy()
        
        if len(self.columns_to_scale) > 0:
            # Appliquer la standardisation
            scaled_values = self.scaler.transform(X_scaled[self.columns_to_scale])
            
            # Mettre à jour le DataFrame
            X_scaled[self.columns_to_scale] = scaled_values
            
            if self.config['verbose']:
                # Vérifier les statistiques
                means = X_scaled[self.columns_to_scale].mean()
                stds = X_scaled[self.columns_to_scale].std()
                print(f"Standardisation appliquée à {len(self.columns_to_scale)} colonnes")
                print(f"Moyennes après standardisation: {means.mean():.6f} (devrait être ~0)")
                print(f"Écarts-types après standardisation: {stds.mean():.6f} (devrait être ~1)")
        
        return X_scaled
    
    def inverse_transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transforme inverse les données standardisées."""
        self._check_is_fitted()
        
        X_inverse = X.copy()
        
        if len(self.columns_to_scale) > 0:
            # Appliquer la transformation inverse
            inverse_values = self.scaler.inverse_transform(X_inverse[self.columns_to_scale])
            
            # Mettre à jour le DataFrame
            X_inverse[self.columns_to_scale] = inverse_values
        
        return X_inverse

class MinMaxScaler(FeatureScaler):
    """Normalisation Min-Max (valeurs entre 0 et 1)."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'feature_range': (0, 1),
            'columns': None,
            'clip': False,
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.scaler = None
        self.columns_to_scale = []
    
    def fit(self, X: pd.DataFrame, y=None):
        """Ajuste le scaler."""
        # Déterminer les colonnes à normaliser
        if self.config['columns'] is None:
            # Toutes les colonnes numériques
            self.columns_to_scale = X.select_dtypes(include=[np.number]).columns.tolist()
        else:
            # Colonnes spécifiées
            self.columns_to_scale = [col for col in self.config['columns'] if col in X.columns]
        
        if len(self.columns_to_scale) == 0:
            self.is_fitted = True
            return self
        
        # Créer et ajuster le scaler
        self.scaler = SklearnMinMaxScaler(
            feature_range=self.config['feature_range'],
            clip=self.config['clip']
        )
        
        self.scaler.fit(X[self.columns_to_scale])
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def scale(self, X: pd.DataFrame) -> pd.DataFrame:
        """Normalise Min-Max les features."""
        if not self.is_fitted:
            self.fit(X)
        
        X_scaled = X.copy()
        
        if len(self.columns_to_scale) > 0:
            # Appliquer la normalisation
            scaled_values = self.scaler.transform(X_scaled[self.columns_to_scale])
            
            # Mettre à jour le DataFrame
            X_scaled[self.columns_to_scale] = scaled_values
            
            if self.config['verbose']:
                # Vérifier les statistiques
                mins = X_scaled[self.columns_to_scale].min()
                maxs = X_scaled[self.columns_to_scale].max()
                print(f"Normalisation Min-Max appliquée à {len(self.columns_to_scale)} colonnes")
                print(f"Plage cible: {self.config['feature_range']}")
                print(f"Valeurs min après normalisation: {mins.mean():.6f}")
                print(f"Valeurs max après normalisation: {maxs.mean():.6f}")
        
        return X_scaled
    
    def inverse_transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transforme inverse les données normalisées."""
        self._check_is_fitted()
        
        X_inverse = X.copy()
        
        if len(self.columns_to_scale) > 0:
            # Appliquer la transformation inverse
            inverse_values = self.scaler.inverse_transform(X_inverse[self.columns_to_scale])
            
            # Mettre à jour le DataFrame
            X_inverse[self.columns_to_scale] = inverse_values
        
        return X_inverse

class RobustScaler(FeatureScaler):
    """Normalisation robuste aux outliers."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'with_centering': True,
            'with_scaling': True,
            'quantile_range': (25.0, 75.0),
            'columns': None,
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.scaler = None
        self.columns_to_scale = []
    
    def fit(self, X: pd.DataFrame, y=None):
        """Ajuste le scaler."""
        # Déterminer les colonnes à normaliser
        if self.config['columns'] is None:
            # Toutes les colonnes numériques
            self.columns_to_scale = X.select_dtypes(include=[np.number]).columns.tolist()
        else:
            # Colonnes spécifiées
            self.columns_to_scale = [col for col in self.config['columns'] if col in X.columns]
        
        if len(self.columns_to_scale) == 0:
            self.is_fitted = True
            return self
        
        # Créer et ajuster le scaler
        self.scaler = SklearnRobustScaler(
            with_centering=self.config['with_centering'],
            with_scaling=self.config['with_scaling'],
            quantile_range=self.config['quantile_range']
        )
        
        self.scaler.fit(X[self.columns_to_scale])
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def scale(self, X: pd.DataFrame) -> pd.DataFrame:
        """Normalise robuste les features."""
        if not self.is_fitted:
            self.fit(X)
        
        X_scaled = X.copy()
        
        if len(self.columns_to_scale) > 0:
            # Appliquer la normalisation
            scaled_values = self.scaler.transform(X_scaled[self.columns_to_scale])
            
            # Mettre à jour le DataFrame
            X_scaled[self.columns_to_scale] = scaled_values
            
            if self.config['verbose']:
                print(f"Normalisation robuste appliquée à {len(self.columns_to_scale)} colonnes")
                print(f"Plage de quantiles: {self.config['quantile_range']}")
        
        return X_scaled
    
    def inverse_transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transforme inverse les données normalisées."""
        self._check_is_fitted()
        
        X_inverse = X.copy()
        
        if len(self.columns_to_scale) > 0:
            # Appliquer la transformation inverse
            inverse_values = self.scaler.inverse_transform(X_inverse[self.columns_to_scale])
            
            # Mettre à jour le DataFrame
            X_inverse[self.columns_to_scale] = inverse_values
        
        return X_inverse

class MaxAbsScaler(FeatureScaler):
    """Normalisation par la valeur absolue maximale."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'columns': None,
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.scaler = None
        self.columns_to_scale = []
    
    def fit(self, X: pd.DataFrame, y=None):
        """Ajuste le scaler."""
        # Déterminer les colonnes à normaliser
        if self.config['columns'] is None:
            # Toutes les colonnes numériques
            self.columns_to_scale = X.select_dtypes(include=[np.number]).columns.tolist()
        else:
            # Colonnes spécifiées
            self.columns_to_scale = [col for col in self.config['columns'] if col in X.columns]
        
        if len(self.columns_to_scale) == 0:
            self.is_fitted = True
            return self
        
        # Créer et ajuster le scaler
        self.scaler = MaxAbsScaler()
        
        self.scaler.fit(X[self.columns_to_scale])
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def scale(self, X: pd.DataFrame) -> pd.DataFrame:
        """Normalise par la valeur absolue maximale."""
        if not self.is_fitted:
            self.fit(X)
        
        X_scaled = X.copy()
        
        if len(self.columns_to_scale) > 0:
            # Appliquer la normalisation
            scaled_values = self.scaler.transform(X_scaled[self.columns_to_scale])
            
            # Mettre à jour le DataFrame
            X_scaled[self.columns_to_scale] = scaled_values
            
            if self.config['verbose']:
                max_vals = X_scaled[self.columns_to_scale].abs().max()
                print(f"Normalisation MaxAbs appliquée à {len(self.columns_to_scale)} colonnes")
                print(f"Valeurs absolues max après normalisation: {max_vals.mean():.6f}")
        
        return X_scaled
    
    def inverse_transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transforme inverse les données normalisées."""
        self._check_is_fitted()
        
        X_inverse = X.copy()
        
        if len(self.columns_to_scale) > 0:
            # Appliquer la transformation inverse
            inverse_values = self.scaler.inverse_transform(X_inverse[self.columns_to_scale])
            
            # Mettre à jour le DataFrame
            X_inverse[self.columns_to_scale] = inverse_values
        
        return X_inverse

class Normalizer(FeatureScaler):
    """Normalisation par échantillon (ligne)."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'norm': 'l2',  # 'l1', 'l2', 'max'
            'columns': None,
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.scaler = None
        self.columns_to_scale = []
    
    def fit(self, X: pd.DataFrame, y=None):
        """Ajuste le normalizer."""
        # Déterminer les colonnes à normaliser
        if self.config['columns'] is None:
            # Toutes les colonnes numériques
            self.columns_to_scale = X.select_dtypes(include=[np.number]).columns.tolist()
        else:
            # Colonnes spécifiées
            self.columns_to_scale = [col for col in self.config['columns'] if col in X.columns]
        
        if len(self.columns_to_scale) == 0:
            self.is_fitted = True
            return self
        
        # Créer et ajuster le normalizer
        self.scaler = Normalizer(norm=self.config['norm'])
        
        # Note: Normalizer n'a pas de méthode fit significative
        # On l'appelle quand même pour la cohérence
        self.scaler.fit(X[self.columns_to_scale])
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def scale(self, X: pd.DataFrame) -> pd.DataFrame:
        """Normalise par échantillon."""
        if not self.is_fitted:
            self.fit(X)
        
        X_scaled = X.copy()
        
        if len(self.columns_to_scale) > 0:
            # Appliquer la normalisation
            scaled_values = self.scaler.transform(X_scaled[self.columns_to_scale])
            
            # Mettre à jour le DataFrame
            X_scaled[self.columns_to_scale] = scaled_values
            
            if self.config['verbose']:
                print(f"Normalisation par échantillon appliquée à {len(self.columns_to_scale)} colonnes")
                print(f"Norme utilisée: {self.config['norm']}")
        
        return X_scaled
    
    def inverse_transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transforme inverse n'est pas disponible pour Normalizer."""
        raise NotImplementedError(
            "La transformation inverse n'est pas disponible pour Normalizer"
        )

class CustomScaler(FeatureScaler):
    """Scaler personnalisable avec différentes méthodes."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'method': 'zscore',  # 'zscore', 'minmax', 'robust', 'log', 'boxcox'
            'columns': None,
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.scalers = {}
        self.columns_to_scale = []
    
    def fit(self, X: pd.DataFrame, y=None):
        """Ajuste le scaler."""
        # Déterminer les colonnes à normaliser
        if self.config['columns'] is None:
            # Toutes les colonnes numériques
            self.columns_to_scale = X.select_dtypes(include=[np.number]).columns.tolist()
        else:
            # Colonnes spécifiées
            self.columns_to_scale = [col for col in self.config['columns'] if col in X.columns]
        
        if len(self.columns_to_scale) == 0:
            self.is_fitted = True
            return self
        
        method = self.config['method']
        
        if method == 'zscore':
            # Z-score normalization
            self.means = X[self.columns_to_scale].mean()
            self.stds = X[self.columns_to_scale].std().replace(0, 1)  # Éviter division par zéro
        
        elif method == 'minmax':
            # Min-Max normalization
            self.mins = X[self.columns_to_scale].min()
            self.maxs = X[self.columns_to_scale].max()
            self.ranges = self.maxs - self.mins
            self.ranges = self.ranges.replace(0, 1)  # Éviter division par zéro
        
        elif method == 'robust':
            # Robust normalization (using IQR)
            Q1 = X[self.columns_to_scale].quantile(0.25)
            Q3 = X[self.columns_to_scale].quantile(0.75)
            self.IQR = Q3 - Q1
            self.IQR = self.IQR.replace(0, 1)  # Éviter division par zéro
            self.medians = X[self.columns_to_scale].median()
        
        elif method == 'log':
            # Log transformation (requiert des valeurs positives)
            # Pas de paramètres à ajuster
        
        elif method == 'boxcox':
            # Box-Cox transformation
            from scipy import stats
            self.boxcox_lambdas = {}
            for col in self.columns_to_scale:
                # Box-Cox nécessite des valeurs positives
                if (X[col] > 0).all():
                    _, lambda_val = stats.boxcox(X[col])
                    self.boxcox_lambdas[col] = lambda_val
                else:
                    # Si non positif, utiliser Yeo-Johnson ou autre
                    self.boxcox_lambdas[col] = None
        
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def scale(self, X: pd.DataFrame) -> pd.DataFrame:
        """Applique la normalisation personnalisée."""
        if not self.is_fitted:
            self.fit(X)
        
        X_scaled = X.copy()
        method = self.config['method']
        
        if method == 'zscore':
            # Z-score
            for col in self.columns_to_scale:
                X_scaled[col] = (X_scaled[col] - self.means[col]) / self.stds[col]
        
        elif method == 'minmax':
            # Min-Max
            for col in self.columns_to_scale:
                X_scaled[col] = (X_scaled[col] - self.mins[col]) / self.ranges[col]
        
        elif method == 'robust':
            # Robust
            for col in self.columns_to_scale:
                X_scaled[col] = (X_scaled[col] - self.medians[col]) / self.IQR[col]
        
        elif method == 'log':
            # Log
            for col in self.columns_to_scale:
                # S'assurer que les valeurs sont positives
                min_val = X_scaled[col].min()
                if min_val <= 0:
                    # Décaler pour rendre positif
                    shift = abs(min_val) + 1
                    X_scaled[col] = X_scaled[col] + shift
                X_scaled[col] = np.log1p(X_scaled[col])
        
        elif method == 'boxcox':
            # Box-Cox
            from scipy import stats
            for col in self.columns_to_scale:
                lambda_val = self.boxcox_lambdas.get(col)
                if lambda_val is not None:
                    X_scaled[col] = stats.boxcox(X_scaled[col], lmbda=lambda_val)
                else:
                    # Yeo-Johnson pour valeurs non positives
                    # (simplifié)
                    X_scaled[col] = np.sign(X_scaled[col]) * np.log1p(np.abs(X_scaled[col]))
        
        if self.config['verbose']:
            print(f"Normalisation '{method}' appliquée à {len(self.columns_to_scale)} colonnes")
        
        return X_scaled
    
    def inverse_transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transforme inverse les données normalisées."""
        self._check_is_fitted()
        
        X_inverse = X.copy()
        method = self.config['method']
        
        if method == 'zscore':
            for col in self.columns_to_scale:
                X_inverse[col] = (X_inverse[col] * self.stds[col]) + self.means[col]
        
        elif method == 'minmax':
            for col in self.columns_to_scale:
                X_inverse[col] = (X_inverse[col] * self.ranges[col]) + self.mins[col]
        
        elif method == 'robust':
            for col in self.columns_to_scale:
                X_inverse[col] = (X_inverse[col] * self.IQR[col]) + self.medians[col]
        
        elif method == 'log':
            for col in self.columns_to_scale:
                X_inverse[col] = np.expm1(X_inverse[col])
        
        elif method == 'boxcox':
            from scipy import stats
            for col in self.columns_to_scale:
                lambda_val = self.boxcox_lambdas.get(col)
                if lambda_val is not None:
                    # Inverse Box-Cox
                    if lambda_val == 0:
                        X_inverse[col] = np.exp(X_inverse[col])
                    else:
                        X_inverse[col] = (lambda_val * X_inverse[col] + 1) ** (1 / lambda_val)
        
        return X_inverse