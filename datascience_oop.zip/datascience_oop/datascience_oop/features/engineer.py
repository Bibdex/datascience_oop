"""
Ingénierie des features.
"""

import pandas as pd
import numpy as np
from typing import Optional, Dict, Any, List
from abc import ABC, abstractmethod
import re
from datetime import datetime
from ..core.base import PipelineComponent
from ..core.decorators import timing_decorator, log_execution

class FeatureEngineer(PipelineComponent, ABC):
    """Classe abstraite pour l'ingénierie des features."""
    
    @abstractmethod
    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée de nouvelles features."""
        pass
    
    def process(self, data: Any) -> Any:
        """Interface pour PipelineComponent."""
        if isinstance(data, pd.DataFrame):
            return self.engineer_features(data)
        return data

class BasicFeatureEngineer(FeatureEngineer):
    """Ingénieur de features de base."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'create_interactions': False,
            'create_polynomials': False,
            'polynomial_degree': 2,
            'create_statistical': True,
            'statistical_features': ['mean', 'std', 'min', 'max'],
            'create_bins': False,
            'bin_columns': [],
            'n_bins': 5,
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
    
    @timing_decorator
    @log_execution
    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée de nouvelles features."""
        df_engineered = df.copy()
        
        # Features statistiques
        if self.config['create_statistical']:
            df_engineered = self._create_statistical_features(df_engineered)
        
        # Features polynomiales
        if self.config['create_polynomials']:
            df_engineered = self._create_polynomial_features(df_engineered)
        
        # Interactions
        if self.config['create_interactions']:
            df_engineered = self._create_interaction_features(df_engineered)
        
        # Binning
        if self.config['create_bins'] and self.config['bin_columns']:
            df_engineered = self._create_binned_features(df_engineered)
        
        if self.config['verbose']:
            print(f"Features créées: {df_engineered.shape[1] - df.shape[1]} nouvelles colonnes")
        
        return df_engineered
    
    def _create_statistical_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features statistiques."""
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        
        for stat in self.config['statistical_features']:
            if stat == 'mean':
                df[f'all_features_mean'] = df[numeric_cols].mean(axis=1)
            elif stat == 'std':
                df[f'all_features_std'] = df[numeric_cols].std(axis=1)
            elif stat == 'min':
                df[f'all_features_min'] = df[numeric_cols].min(axis=1)
            elif stat == 'max':
                df[f'all_features_max'] = df[numeric_cols].max(axis=1)
            elif stat == 'median':
                df[f'all_features_median'] = df[numeric_cols].median(axis=1)
            elif stat == 'sum':
                df[f'all_features_sum'] = df[numeric_cols].sum(axis=1)
        
        return df
    
    def _create_polynomial_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features polynomiales."""
        from sklearn.preprocessing import PolynomialFeatures
        
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        
        if len(numeric_cols) == 0:
            return df
        
        # Sélectionner les colonnes numériques
        X_numeric = df[numeric_cols]
        
        # Créer les features polynomiales
        poly = PolynomialFeatures(
            degree=self.config['polynomial_degree'],
            include_bias=False,
            interaction_only=False
        )
        
        X_poly = poly.fit_transform(X_numeric)
        
        # Créer les noms des colonnes
        feature_names = poly.get_feature_names_out(numeric_cols)
        
        # Créer un DataFrame avec les nouvelles features
        df_poly = pd.DataFrame(X_poly, columns=feature_names, index=df.index)
        
        # Ajouter les nouvelles features au DataFrame original
        # (sans les colonnes originales pour éviter la duplication)
        new_cols = [col for col in df_poly.columns if col not in df.columns]
        df = pd.concat([df, df_poly[new_cols]], axis=1)
        
        return df
    
    def _create_interaction_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features d'interaction."""
        from itertools import combinations
        
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        
        if len(numeric_cols) < 2:
            return df
        
        # Créer des interactions par paires
        for col1, col2 in combinations(numeric_cols, 2):
            df[f'{col1}_x_{col2}'] = df[col1] * df[col2]
            df[f'{col1}_div_{col2}'] = df[col1] / df[col2].replace(0, np.nan)
        
        return df
    
    def _create_binned_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features binned (catégorielles à partir de numériques)."""
        for col in self.config['bin_columns']:
            if col in df.columns and df[col].dtype in [np.float64, np.int64]:
                # Créer des bins égaux
                df[f'{col}_bin'] = pd.cut(
                    df[col],
                    bins=self.config['n_bins'],
                    labels=False
                )
                
                # Créer des bins basés sur les quantiles
                df[f'{col}_qbin'] = pd.qcut(
                    df[col],
                    q=self.config['n_bins'],
                    labels=False,
                    duplicates='drop'
                )
        
        return df

class TimeSeriesFeatureEngineer(FeatureEngineer):
    """Ingénieur de features pour séries temporelles."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'date_column': 'date',
            'target_column': 'value',
            'lags': [1, 7, 30],
            'rolling_windows': [7, 30, 90],
            'rolling_stats': ['mean', 'std', 'min', 'max'],
            'create_date_features': True,
            'date_features': ['year', 'month', 'day', 'dayofweek', 'quarter'],
            'create_cyclical_features': True,
            'create_holiday_features': False,
            'country': 'US',
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
    
    @timing_decorator
    @log_execution
    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features pour séries temporelles."""
        df_engineered = df.copy()
        
        # S'assurer que la colonne date est au bon format
        if self.config['date_column'] in df_engineered.columns:
            df_engineered[self.config['date_column']] = pd.to_datetime(
                df_engineered[self.config['date_column']]
            )
            
            # Trier par date
            df_engineered = df_engineered.sort_values(self.config['date_column'])
            
            # Features de date
            if self.config['create_date_features']:
                df_engineered = self._create_date_features(df_engineered)
            
            # Features cycliques
            if self.config['create_cyclical_features']:
                df_engineered = self._create_cyclical_features(df_engineered)
            
            # Features de vacances
            if self.config['create_holiday_features']:
                df_engineered = self._create_holiday_features(df_engineered)
        
        # Features de lag
        if self.config['target_column'] in df_engineered.columns:
            df_engineered = self._create_lag_features(df_engineered)
        
        # Features de rolling
        if self.config['target_column'] in df_engineered.columns:
            df_engineered = self._create_rolling_features(df_engineered)
        
        # Features de différence
        df_engineered = self._create_difference_features(df_engineered)
        
        if self.config['verbose']:
            print(f"Features de séries temporelles créées: "
                  f"{df_engineered.shape[1] - df.shape[1]} nouvelles colonnes")
        
        return df_engineered
    
    def _create_date_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features à partir de la date."""
        date_col = self.config['date_column']
        
        for feature in self.config['date_features']:
            if feature == 'year':
                df[f'{date_col}_year'] = df[date_col].dt.year
            elif feature == 'month':
                df[f'{date_col}_month'] = df[date_col].dt.month
            elif feature == 'day':
                df[f'{date_col}_day'] = df[date_col].dt.day
            elif feature == 'dayofweek':
                df[f'{date_col}_dayofweek'] = df[date_col].dt.dayofweek
            elif feature == 'quarter':
                df[f'{date_col}_quarter'] = df[date_col].dt.quarter
            elif feature == 'weekofyear':
                df[f'{date_col}_weekofyear'] = df[date_col].dt.isocalendar().week
            elif feature == 'is_weekend':
                df[f'{date_col}_is_weekend'] = df[date_col].dt.dayofweek >= 5
            elif feature == 'is_month_start':
                df[f'{date_col}_is_month_start'] = df[date_col].dt.is_month_start
            elif feature == 'is_month_end':
                df[f'{date_col}_is_month_end'] = df[date_col].dt.is_month_end
        
        return df
    
    def _create_cyclical_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features cycliques (saisonnalité)."""
        date_col = self.config['date_column']
        
        # Mois cyclique
        if f'{date_col}_month' in df.columns:
            df[f'{date_col}_month_sin'] = np.sin(2 * np.pi * df[f'{date_col}_month'] / 12)
            df[f'{date_col}_month_cos'] = np.cos(2 * np.pi * df[f'{date_col}_month'] / 12)
        
        # Jour de la semaine cyclique
        if f'{date_col}_dayofweek' in df.columns:
            df[f'{date_col}_dayofweek_sin'] = np.sin(2 * np.pi * df[f'{date_col}_dayofweek'] / 7)
            df[f'{date_col}_dayofweek_cos'] = np.cos(2 * np.pi * df[f'{date_col}_dayofweek'] / 7)
        
        # Jour de l'année cyclique
        if f'{date_col}_dayofyear' in df.columns or 'dayofyear' in df.columns:
            dayofyear = df[f'{date_col}_dayofyear'] if f'{date_col}_dayofyear' in df.columns else df['dayofyear']
            df[f'{date_col}_dayofyear_sin'] = np.sin(2 * np.pi * dayofyear / 365.25)
            df[f'{date_col}_dayofyear_cos'] = np.cos(2 * np.pi * dayofyear / 365.25)
        
        return df
    
    def _create_holiday_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features pour les jours fériés."""
        try:
            import holidays
            
            date_col = self.config['date_column']
            country = self.config['country']
            
            # Créer un objet holidays pour le pays spécifié
            holiday_obj = getattr(holidays, country)()
            
            # Vérifier si chaque date est un jour férié
            df[f'{date_col}_is_holiday'] = df[date_col].apply(lambda x: x in holiday_obj)
            
            # Nom du jour férié
            df[f'{date_col}_holiday_name'] = df[date_col].apply(
                lambda x: holiday_obj.get(x, '')
            )
        
        except ImportError:
            print("Warning: package 'holidays' non installé. "
                  "Installation: pip install holidays")
        
        return df
    
    def _create_lag_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features de lag."""
        target_col = self.config['target_column']
        
        for lag in self.config['lags']:
            df[f'{target_col}_lag_{lag}'] = df[target_col].shift(lag)
        
        return df
    
    def _create_rolling_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features de rolling statistics."""
        target_col = self.config['target_column']
        
        for window in self.config['rolling_windows']:
            for stat in self.config['rolling_stats']:
                if stat == 'mean':
                    df[f'{target_col}_rolling_mean_{window}'] = (
                        df[target_col].rolling(window=window, min_periods=1).mean()
                    )
                elif stat == 'std':
                    df[f'{target_col}_rolling_std_{window}'] = (
                        df[target_col].rolling(window=window, min_periods=1).std()
                    )
                elif stat == 'min':
                    df[f'{target_col}_rolling_min_{window}'] = (
                        df[target_col].rolling(window=window, min_periods=1).min()
                    )
                elif stat == 'max':
                    df[f'{target_col}_rolling_max_{window}'] = (
                        df[target_col].rolling(window=window, min_periods=1).max()
                    )
                elif stat == 'median':
                    df[f'{target_col}_rolling_median_{window}'] = (
                        df[target_col].rolling(window=window, min_periods=1).median()
                    )
        
        return df
    
    def _create_difference_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features de différence."""
        target_col = self.config['target_column']
        
        if target_col in df.columns:
            # Différence avec la période précédente
            df[f'{target_col}_diff_1'] = df[target_col].diff(1)
            
            # Différence saisonnière (7 jours pour des données quotidiennes)
            df[f'{target_col}_diff_7'] = df[target_col].diff(7)
            
            # Différence en pourcentage
            df[f'{target_col}_pct_change_1'] = df[target_col].pct_change(1)
        
        return df

class TextFeatureEngineer(FeatureEngineer):
    """Ingénieur de features pour le texte."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'text_column': 'text',
            'create_basic_features': True,
            'create_lexical_features': True,
            'create_sentiment_features': True,
            'create_readability_features': False,
            'language': 'english',
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
    
    @timing_decorator
    @log_execution
    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des features à partir de texte."""
        df_engineered = df.copy()
        
        text_col = self.config['text_column']
        
        if text_col not in df_engineered.columns:
            print(f"Warning: colonne de texte '{text_col}' non trouvée")
            return df_engineered
        
        # Features basiques
        if self.config['create_basic_features']:
            df_engineered = self._create_basic_text_features(df_engineered, text_col)
        
        # Features lexicales
        if self.config['create_lexical_features']:
            df_engineered = self._create_lexical_features(df_engineered, text_col)
        
        # Features de sentiment
        if self.config['create_sentiment_features']:
            df_engineered = self._create_sentiment_features(df_engineered, text_col)
        
        # Features de lisibilité
        if self.config['create_readability_features']:
            df_engineered = self._create_readability_features(df_engineered, text_col)
        
        if self.config['verbose']:
            print(f"Features de texte créées: {df_engineered.shape[1] - df.shape[1]} nouvelles colonnes")
        
        return df_engineered
    
    def _create_basic_text_features(self, df: pd.DataFrame, text_col: str) -> pd.DataFrame:
        """Crée des features basiques de texte."""
        # Longueur du texte
        df[f'{text_col}_length'] = df[text_col].astype(str).str.len()
        
        # Nombre de mots
        df[f'{text_col}_word_count'] = df[text_col].astype(str).str.split().str.len()
        
        # Nombre de caractères sans espaces
        df[f'{text_col}_char_count_no_spaces'] = (
            df[text_col].astype(str).str.replace(' ', '').str.len()
        )
        
        # Longueur moyenne des mots
        df[f'{text_col}_avg_word_length'] = (
            df[f'{text_col}_char_count_no_spaces'] / 
            df[f'{text_col}_word_count'].replace(0, np.nan)
        )
        
        # Nombre de phrases (approximatif)
        df[f'{text_col}_sentence_count'] = df[text_col].astype(str).str.count(r'[.!?]+')
        
        return df
    
    def _create_lexical_features(self, df: pd.DataFrame, text_col: str) -> pd.DataFrame:
        """Crée des features lexicales."""
        try:
            import nltk
            from nltk.corpus import stopwords
            
            # Télécharger les ressources NLTK si nécessaire
            try:
                nltk.data.find('tokenizers/punkt')
            except LookupError:
                nltk.download('punkt')
                nltk.download('stopwords')
            
            # Obtenir les stopwords
            stop_words = set(stopwords.words(self.config['language']))
            
            # Tokenizer
            df['tokens'] = df[text_col].astype(str).apply(nltk.word_tokenize)
            
            # Nombre de stopwords
            df[f'{text_col}_stopword_count'] = df['tokens'].apply(
                lambda tokens: sum(1 for token in tokens if token.lower() in stop_words)
            )
            
            # Ratio de stopwords
            df[f'{text_col}_stopword_ratio'] = (
                df[f'{text_col}_stopword_count'] / 
                df[f'{text_col}_word_count'].replace(0, np.nan)
            )
            
            # Nombre de mots uniques
            df[f'{text_col}_unique_word_count'] = df['tokens'].apply(
                lambda tokens: len(set(tokens))
            )
            
            # Ratio de mots uniques (richesse lexicale)
            df[f'{text_col}_lexical_diversity'] = (
                df[f'{text_col}_unique_word_count'] / 
                df[f'{text_col}_word_count'].replace(0, np.nan)
            )
            
            # Supprimer la colonne temporaire
            df = df.drop('tokens', axis=1)
        
        except ImportError:
            print("Warning: package 'nltk' non installé. "
                  "Installation: pip install nltk")
        
        return df
    
    def _create_sentiment_features(self, df: pd.DataFrame, text_col: str) -> pd.DataFrame:
        """Crée des features de sentiment."""
        try:
            from textblob import TextBlob
            
            # Polarity et subjectivity
            df[f'{text_col}_polarity'] = df[text_col].astype(str).apply(
                lambda text: TextBlob(text).sentiment.polarity
            )
            
            df[f'{text_col}_subjectivity'] = df[text_col].astype(str).apply(
                lambda text: TextBlob(text).sentiment.subjectivity
            )
            
            # Catégorie de sentiment
            df[f'{text_col}_sentiment'] = df[f'{text_col}_polarity'].apply(
                lambda p: 'positive' if p > 0.1 else ('negative' if p < -0.1 else 'neutral')
            )
        
        except ImportError:
            print("Warning: package 'textblob' non installé. "
                  "Installation: pip install textblob")
        
        return df
    
    def _create_readability_features(self, df: pd.DataFrame, text_col: str) -> pd.DataFrame:
        """Crée des features de lisibilité."""
        # Ici on pourrait implémenter des métriques de lisibilité
        # comme Flesch Reading Ease, Gunning Fog Index, etc.
        
        # Pour l'instant, on crée des features simples
        # Nombre de mots longs (> 6 caractères)
        df[f'{text_col}_long_word_count'] = df[text_col].astype(str).apply(
            lambda text: sum(1 for word in text.split() if len(word) > 6)
        )
        
        # Ratio de mots longs
        df[f'{text_col}_long_word_ratio'] = (
            df[f'{text_col}_long_word_count'] / 
            df[f'{text_col}_word_count'].replace(0, np.nan)
        )
        
        return df