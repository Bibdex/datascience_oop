"""
Module models - Modèles ML et évaluation.
"""

from .base_model import BaseModel, ModelFactory, ModelRegistry
from .trainer import (
    ModelTrainer, RandomForestTrainer, LogisticRegressionTrainer,
    XGBoostTrainer, SVMTrainer, KNeighborsTrainer
)
from .evaluator import ModelEvaluator, ClassificationEvaluator, RegressionEvaluator
from .cv_strategies import (
    CrossValidationStrategy, KFoldStrategy, StratifiedKFoldStrategy,
    TimeSeriesCVStrategy, CrossValidationContext
)

__all__ = [
    # Base
    'BaseModel',
    'ModelFactory',
    'ModelRegistry',
    
    # Trainers
    'ModelTrainer',
    'RandomForestTrainer',
    'LogisticRegressionTrainer',
    'XGBoostTrainer',
    'SVMTrainer',
    'KNeighborsTrainer',
    
    # Evaluators
    'ModelEvaluator',
    'ClassificationEvaluator',
    'RegressionEvaluator',
    
    # Cross-Validation
    'CrossValidationStrategy',
    'KFoldStrategy',
    'StratifiedKFoldStrategy',
    'TimeSeriesCVStrategy',
    'CrossValidationContext',
]