"""
Évaluation des modèles ML.
"""

import pandas as pd
import numpy as np
from typing import Optional, Dict, Any, List, Tuple, Union
from abc import ABC, abstractmethod
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report,
    mean_squared_error, mean_absolute_error, r2_score,
    explained_variance_score, mean_absolute_percentage_error
)
from ..core.base import PipelineComponent
from ..core.decorators import timing_decorator, log_execution

class ModelEvaluator(PipelineComponent, ABC):
    """Classe abstraite pour l'évaluation des modèles."""
    
    @abstractmethod
    def evaluate(self, y_true, y_pred, y_pred_proba=None) -> Dict[str, Any]:
        """Évalue les prédictions du modèle."""
        pass
    
    def process(self, data: Any) -> Any:
        """Interface pour PipelineComponent."""
        if isinstance(data, tuple) and len(data) >= 2:
            return self.evaluate(*data)
        return data

class ClassificationEvaluator(ModelEvaluator):
    """Évaluateur pour les modèles de classification."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'average': 'weighted',  # 'micro', 'macro', 'weighted', 'binary'
            'labels': None,
            'target_names': None,
            'generate_report': True,
            'generate_plots': False,
            'plot_dir': '.',
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
    
    @timing_decorator
    @log_execution
    def evaluate(self, y_true, y_pred, y_pred_proba=None) -> Dict[str, Any]:
        """Évalue les prédictions d'un modèle de classification."""
        results = {}
        
        # Métriques de base
        results['accuracy'] = accuracy_score(y_true, y_pred)
        
        # Précision, Rappel, F1
        average = self.config['average']
        labels = self.config['labels']
        
        results['precision'] = precision_score(
            y_true, y_pred, average=average, labels=labels, zero_division=0
        )
        results['recall'] = recall_score(
            y_true, y_pred, average=average, labels=labels, zero_division=0
        )
        results['f1'] = f1_score(
            y_true, y_pred, average=average, labels=labels, zero_division=0
        )
        
        # AUC-ROC (si les probabilités sont fournies)
        if y_pred_proba is not None:
            try:
                # Pour la classification binaire
                if y_pred_proba.shape[1] == 2:
                    results['roc_auc'] = roc_auc_score(y_true, y_pred_proba[:, 1])
                else:
                    # Pour la classification multi-classe
                    results['roc_auc'] = roc_auc_score(
                        y_true, y_pred_proba, multi_class='ovr', average=average
                    )
            except:
                results['roc_auc'] = None
        
        # Matrice de confusion
        results['confusion_matrix'] = confusion_matrix(y_true, y_pred, labels=labels)
        
        # Rapport de classification détaillé
        if self.config['generate_report']:
            results['classification_report'] = classification_report(
                y_true, y_pred,
                target_names=self.config['target_names'],
                labels=labels,
                output_dict=True
            )
        
        # Générer des plots si demandé
        if self.config['generate_plots']:
            self._generate_plots(y_true, y_pred, y_pred_proba, results)
        
        # Affichage des résultats
        if self.config['verbose']:
            self._print_results(results)
        
        return results
    
    def _generate_plots(self, y_true, y_pred, y_pred_proba, results):
        """Génère des visualisations pour l'évaluation."""
        plot_dir = self.config['plot_dir']
        
        # 1. Matrice de confusion
        plt.figure(figsize=(10, 8))
        sns.heatmap(
            results['confusion_matrix'],
            annot=True, fmt='d', cmap='Blues',
            xticklabels=self.config['target_names'] or range(results['confusion_matrix'].shape[0]),
            yticklabels=self.config['target_names'] or range(results['confusion_matrix'].shape[1])
        )
        plt.title('Matrice de Confusion')
        plt.ylabel('Vérité Terrain')
        plt.xlabel('Prédictions')
        plt.tight_layout()
        plt.savefig(f'{plot_dir}/confusion_matrix.png', dpi=300)
        plt.close()
        
        # 2. Courbe ROC (si les probabilités sont fournies)
        if y_pred_proba is not None and results.get('roc_auc') is not None:
            from sklearn.metrics import roc_curve
            
            plt.figure(figsize=(10, 8))
            
            if y_pred_proba.shape[1] == 2:
                # Classification binaire
                fpr, tpr, _ = roc_curve(y_true, y_pred_proba[:, 1])
                plt.plot(fpr, tpr, label=f'ROC curve (AUC = {results["roc_auc"]:.3f})')
            else:
                # Classification multi-classe
                from sklearn.preprocessing import label_binarize
                
                n_classes = y_pred_proba.shape[1]
                y_true_bin = label_binarize(y_true, classes=range(n_classes))
                
                for i in range(n_classes):
                    fpr, tpr, _ = roc_curve(y_true_bin[:, i], y_pred_proba[:, i])
                    plt.plot(fpr, tpr, label=f'Class {i} (AUC = {roc_auc_score(y_true_bin[:, i], y_pred_proba[:, i]):.3f})')
            
            plt.plot([0, 1], [0, 1], 'k--', label='Random')
            plt.xlabel('False Positive Rate')
            plt.ylabel('True Positive Rate')
            plt.title('Courbe ROC')
            plt.legend()
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(f'{plot_dir}/roc_curve.png', dpi=300)
            plt.close()
        
        # 3. Bar plot des métriques
        metrics = ['accuracy', 'precision', 'recall', 'f1']
        if 'roc_auc' in results and results['roc_auc'] is not None:
            metrics.append('roc_auc')
        
        metric_values = [results[m] for m in metrics]
        
        plt.figure(figsize=(10, 6))
        bars = plt.bar(metrics, metric_values, color='skyblue')
        plt.title('Métriques de Classification')
        plt.ylabel('Score')
        plt.ylim(0, 1)
        
        # Ajouter les valeurs sur les barres
        for bar, value in zip(bars, metric_values):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                    f'{value:.3f}', ha='center', va='bottom')
        
        plt.tight_layout()
        plt.savefig(f'{plot_dir}/classification_metrics.png', dpi=300)
        plt.close()
    
    def _print_results(self, results: Dict[str, Any]):
        """Affiche les résultats de l'évaluation."""
        print("\n" + "=" * 60)
        print("ÉVALUATION DE CLASSIFICATION")
        print("=" * 60)
        
        print(f"\nMétriques principales:")
        print(f"  Accuracy:  {results['accuracy']:.4f}")
        print(f"  Precision: {results['precision']:.4f}")
        print(f"  Rappel:    {results['recall']:.4f}")
        print(f"  F1-score:  {results['f1']:.4f}")
        
        if 'roc_auc' in results and results['roc_auc'] is not None:
            print(f"  AUC-ROC:   {results['roc_auc']:.4f}")
        
        print(f"\nMatrice de confusion:")
        print(results['confusion_matrix'])
        
        if 'classification_report' in results:
            print(f"\nRapport de classification détaillé:")
            report_df = pd.DataFrame(results['classification_report']).transpose()
            print(report_df.to_string())

class RegressionEvaluator(ModelEvaluator):
    """Évaluateur pour les modèles de régression."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'generate_report': True,
            'generate_plots': False,
            'plot_dir': '.',
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
    
    @timing_decorator
    @log_execution
    def evaluate(self, y_true, y_pred, y_pred_proba=None) -> Dict[str, Any]:
        """Évalue les prédictions d'un modèle de régression."""
        results = {}
        
        # Métriques de base
        results['mse'] = mean_squared_error(y_true, y_pred)
        results['rmse'] = np.sqrt(results['mse'])
        results['mae'] = mean_absolute_error(y_true, y_pred)
        results['r2'] = r2_score(y_true, y_pred)
        results['explained_variance'] = explained_variance_score(y_true, y_pred)
        
        # MAPE (Mean Absolute Percentage Error)
        try:
            results['mape'] = mean_absolute_percentage_error(y_true, y_pred)
        except:
            # MAPE peut échouer si y_true contient des zéros
            results['mape'] = None
        
        # Erreur maximale
        results['max_error'] = np.max(np.abs(y_true - y_pred))
        
        # Erreur moyenne absolue en pourcentage (alternative)
        if results['mape'] is None:
            epsilon = np.finfo(np.float64).eps
            results['mape_alt'] = np.mean(
                np.abs((y_true - y_pred) / np.maximum(np.abs(y_true), epsilon))
            ) * 100
        
        # Générer des plots si demandé
        if self.config['generate_plots']:
            self._generate_plots(y_true, y_pred, results)
        
        # Affichage des résultats
        if self.config['verbose']:
            self._print_results(results)
        
        return results
    
    def _generate_plots(self, y_true, y_pred, results):
        """Génère des visualisations pour l'évaluation."""
        plot_dir = self.config['plot_dir']
        
        # 1. Scatter plot des prédictions vs vraies valeurs
        plt.figure(figsize=(10, 8))
        plt.scatter(y_true, y_pred, alpha=0.5)
        
        # Ligne idéale (y = x)
        min_val = min(y_true.min(), y_pred.min())
        max_val = max(y_true.max(), y_pred.max())
        plt.plot([min_val, max_val], [min_val, max_val], 'r--', label='Parfait')
        
        plt.xlabel('Valeurs Réelles')
        plt.ylabel('Prédictions')
        plt.title('Prédictions vs Valeurs Réelles')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f'{plot_dir}/predictions_vs_actual.png', dpi=300)
        plt.close()
        
        # 2. Histogramme des résidus
        residuals = y_true - y_pred
        
        plt.figure(figsize=(10, 8))
        plt.hist(residuals, bins=50, alpha=0.7, edgecolor='black')
        plt.xlabel('Résidus')
        plt.ylabel('Fréquence')
        plt.title('Distribution des Résidus')
        plt.axvline(x=0, color='r', linestyle='--', label='Moyenne = 0')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f'{plot_dir}/residuals_distribution.png', dpi=300)
        plt.close()
        
        # 3. Q-Q plot des résidus (normalité)
        plt.figure(figsize=(10, 8))
        from scipy import stats
        stats.probplot(residuals, dist="norm", plot=plt)
        plt.title('Q-Q Plot des Résidus')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f'{plot_dir}/qq_plot.png', dpi=300)
        plt.close()
        
        # 4. Bar plot des métriques
        metrics = ['rmse', 'mae', 'r2', 'explained_variance']
        metric_names = ['RMSE', 'MAE', 'R²', 'Explained Variance']
        metric_values = [results[m] for m in metrics]
        
        plt.figure(figsize=(12, 6))
        bars = plt.bar(metric_names, metric_values, color=['red', 'orange', 'green', 'blue'])
        plt.title('Métriques de Régression')
        plt.ylabel('Valeur')
        
        # Ajuster les limites de l'axe Y
        min_val = min(metric_values)
        max_val = max(metric_values)
        plt.ylim(min_val * 0.9, max_val * 1.1)
        
        # Ajouter les valeurs sur les barres
        for bar, value in zip(bars, metric_values):
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2, height + (0.01 * max_val),
                    f'{value:.4f}', ha='center', va='bottom')
        
        plt.tight_layout()
        plt.savefig(f'{plot_dir}/regression_metrics.png', dpi=300)
        plt.close()
    
    def _print_results(self, results: Dict[str, Any]):
        """Affiche les résultats de l'évaluation."""
        print("\n" + "=" * 60)
        print("ÉVALUATION DE RÉGRESSION")
        print("=" * 60)
        
        print(f"\nMétriques principales:")
        print(f"  MSE (Mean Squared Error):      {results['mse']:.4f}")
        print(f"  RMSE (Root Mean Squared Error): {results['rmse']:.4f}")
        print(f"  MAE (Mean Absolute Error):      {results['mae']:.4f}")
        print(f"  R² Score:                       {results['r2']:.4f}")
        print(f"  Explained Variance:             {results['explained_variance']:.4f}")
        
        if results['mape'] is not None:
            print(f"  MAPE (Mean Absolute % Error):   {results['mape']:.2f}%")
        elif 'mape_alt' in results:
            print(f"  MAPE (alternative):             {results['mape_alt']:.2f}%")
        
        print(f"  Max Error:                      {results['max_error']:.4f}")

class TimeSeriesEvaluator(ModelEvaluator):
    """Évaluateur pour les modèles de séries temporelles."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'horizon': 1,
            'generate_plots': False,
            'plot_dir': '.',
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
    
    @timing_decorator
    @log_execution
    def evaluate(self, y_true, y_pred, y_pred_proba=None) -> Dict[str, Any]:
        """Évalue les prédictions d'un modèle de séries temporelles."""
        results = {}
        
        # Métriques de base (héritées de la régression)
        reg_evaluator = RegressionEvaluator(config={
            'generate_report': False,
            'generate_plots': False,
            'verbose': False
        })
        reg_results = reg_evaluator.evaluate(y_true, y_pred)
        
        # Ajouter les métriques de régression
        results.update(reg_results)
        
        # Métriques spécifiques aux séries temporelles
        
        # MASE (Mean Absolute Scaled Error)
        # Nécessite les valeurs historiques pour le calcul
        if hasattr(self, 'y_train'):
            # Calculer la MAE du modèle naïf (prédiction = dernière valeur)
            naive_mae = np.mean(np.abs(np.diff(self.y_train)))
            if naive_mae > 0:
                results['mase'] = results['mae'] / naive_mae
        
        # SMAPE (Symmetric Mean Absolute Percentage Error)
        denominator = np.abs(y_true) + np.abs(y_pred)
        mask = denominator > 0
        if mask.any():
            results['smape'] = 100 * np.mean(
                2 * np.abs(y_pred[mask] - y_true[mask]) / denominator[mask]
            )
        else:
            results['smape'] = None
        
        # Directional Accuracy
        if len(y_true) > 1:
            true_direction = np.sign(np.diff(y_true))
            pred_direction = np.sign(np.diff(y_pred))
            results['direction_accuracy'] = np.mean(true_direction == pred_direction)
        
        # Générer des plots si demandé
        if self.config['generate_plots']:
            self._generate_plots(y_true, y_pred, results)
        
        # Affichage des résultats
        if self.config['verbose']:
            self._print_results(results)
        
        return results
    
    def set_train_data(self, y_train):
        """Définit les données d'entraînement pour le calcul du MASE."""
        self.y_train = y_train
    
    def _generate_plots(self, y_true, y_pred, results):
        """Génère des visualisations pour l'évaluation des séries temporelles."""
        plot_dir = self.config['plot_dir']
        
        # 1. Série temporelle des prédictions vs vraies valeurs
        plt.figure(figsize=(15, 8))
        plt.plot(y_true, label='Valeurs Réelles', alpha=0.7)
        plt.plot(y_pred, label='Prédictions', alpha=0.7)
        plt.xlabel('Temps')
        plt.ylabel('Valeur')
        plt.title('Série Temporelle: Prédictions vs Valeurs Réelles')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f'{plot_dir}/time_series_predictions.png', dpi=300)
        plt.close()
        
        # 2. Plot des résidus au cours du temps
        residuals = y_true - y_pred
        
        plt.figure(figsize=(15, 8))
        plt.plot(residuals, label='Résidus', color='red', alpha=0.7)
        plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)
        plt.xlabel('Temps')
        plt.ylabel('Résidu')
        plt.title('Résidus au cours du Temps')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f'{plot_dir}/time_series_residuals.png', dpi=300)
        plt.close()
        
        # 3. Autocorrélation des résidus
        from statsmodels.graphics.tsaplots import plot_acf
        
        plt.figure(figsize=(12, 6))
        plot_acf(residuals, lags=min(40, len(residuals)//2))
        plt.title('Autocorrélation des Résidus')
        plt.tight_layout()
        plt.savefig(f'{plot_dir}/residuals_autocorrelation.png', dpi=300)
        plt.close()
    
    def _print_results(self, results: Dict[str, Any]):
        """Affiche les résultats de l'évaluation."""
        print("\n" + "=" * 60)
        print("ÉVALUATION DE SÉRIES TEMPORELLES")
        print("=" * 60)
        
        print(f"\nMétriques de régression:")
        print(f"  RMSE: {results['rmse']:.4f}")
        print(f"  MAE:  {results['mae']:.4f}")
        print(f"  R²:   {results['r2']:.4f}")
        
        print(f"\nMétriques spécifiques aux séries temporelles:")
        if 'mase' in results:
            print(f"  MASE: {results['mase']:.4f}")
        
        if results.get('smape') is not None:
            print(f"  SMAPE: {results['smape']:.2f}%")
        
        if 'direction_accuracy' in results:
            print(f"  Directional Accuracy: {results['direction_accuracy']:.4f}")

class ModelComparison:
    """Classe pour comparer plusieurs modèles."""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.results = {}
        self.best_model = None
    
    def add_model(self, model_name: str, y_true, y_pred, y_pred_proba=None):
        """Ajoute les résultats d'un modèle à la comparaison."""
        # Déterminer le type d'évaluation
        # (simplification: on vérifie si les valeurs sont discrètes)
        if len(np.unique(y_true)) < 10 and all(y_true.astype(int) == y_true):
            # Classification
            evaluator = ClassificationEvaluator(config={
                'generate_report': False,
                'generate_plots': False,
                'verbose': False
            })
            results = evaluator.evaluate(y_true, y_pred, y_pred_proba)
            results['type'] = 'classification'
        else:
            # Régression
            evaluator = RegressionEvaluator(config={
                'generate_report': False,
                'generate_plots': False,
                'verbose': False
            })
            results = evaluator.evaluate(y_true, y_pred, y_pred_proba)
            results['type'] = 'regression'
        
        self.results[model_name] = results
    
    def compare(self, metric: str = None) -> pd.DataFrame:
        """Compare les modèles et retourne un DataFrame."""
        if not self.results:
            raise ValueError("Aucun modèle à comparer")
        
        # Déterminer le type de problème
        problem_types = set([r['type'] for r in self.results.values()])
        if len(problem_types) > 1:
            raise ValueError("Impossible de comparer des modèles de types différents")
        
        problem_type = list(problem_types)[0]
        
        # Sélectionner les métriques pertinentes
        if problem_type == 'classification':
            default_metrics = ['accuracy', 'precision', 'recall', 'f1']
            if any('roc_auc' in r for r in self.results.values()):
                default_metrics.append('roc_auc')
        else:
            default_metrics = ['rmse', 'mae', 'r2', 'explained_variance']
        
        # Utiliser la métrique spécifiée ou les métriques par défaut
        metrics_to_compare = [metric] if metric else default_metrics
        
        # Créer le DataFrame de comparaison
        comparison_data = []
        
        for model_name, results in self.results.items():
            row = {'Model': model_name}
            
            for metric_name in metrics_to_compare:
                if metric_name in results:
                    row[metric_name] = results[metric_name]
                else:
                    row[metric_name] = None
            
            comparison_data.append(row)
        
        df_comparison = pd.DataFrame(comparison_data)
        
        # Déterminer le meilleur modèle
        if metric:
            # Pour les métriques où plus c'est mieux (accuracy, r2, etc.)
            if metric in ['accuracy', 'precision', 'recall', 'f1', 'roc_auc', 
                         'r2', 'explained_variance']:
                best_idx = df_comparison[metric].idxmax()
                best_value = df_comparison.loc[best_idx, metric]
                self.best_model = df_comparison.loc[best_idx, 'Model']
                
                print(f"\nMeilleur modèle selon {metric}: {self.best_model} ({best_value:.4f})")
            
            # Pour les métriques où moins c'est mieux (rmse, mae, etc.)
            elif metric in ['rmse', 'mae', 'mse']:
                best_idx = df_comparison[metric].idxmin()
                best_value = df_comparison.loc[best_idx, metric]
                self.best_model = df_comparison.loc[best_idx, 'Model']
                
                print(f"\nMeilleur modèle selon {metric}: {self.best_model} ({best_value:.4f})")
        
        return df_comparison
    
    def plot_comparison(self, metric: str, save_path: str = None):
        """Crée un graphique de comparaison des modèles."""
        if metric not in next(iter(self.results.values())):
            raise ValueError(f"Métrique '{metric}' non disponible")
        
        model_names = list(self.results.keys())
        metric_values = [self.results[name][metric] for name in model_names]
        
        plt.figure(figsize=(12, 6))
        bars = plt.bar(model_names, metric_values, color='skyblue')
        plt.title(f'Comparaison des Modèles - {metric.upper()}')
        plt.ylabel(metric.upper())
        plt.xticks(rotation=45, ha='right')
        
        # Ajouter les valeurs sur les barres
        for bar, value in zip(bars, metric_values):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                    f'{value:.4f}', ha='center', va='bottom')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300)
        
        plt.show()