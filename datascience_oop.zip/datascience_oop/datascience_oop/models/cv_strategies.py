"""
Stratégies de validation croisée.
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, List, Tuple
import numpy as np
from sklearn.model_selection import (
    KFold, StratifiedKFold, TimeSeriesSplit,
    cross_val_score, cross_validate
)
from ..core.base import BaseEstimator
from ..core.decorators import timing_decorator, log_execution

class CrossValidationStrategy(ABC):
    """Interface pour les stratégies de validation croisée."""
    
    @abstractmethod
    def split(self, X, y):
        """Génère les splits d'indices."""
        pass
    
    @abstractmethod
    def evaluate(self, model, X, y, scoring='accuracy'):
        """Évalue le modèle avec cette stratégie."""
        pass
    
    @abstractmethod
    def get_name(self):
        """Retourne le nom de la stratégie."""
        pass

class KFoldStrategy(CrossValidationStrategy):
    """Stratégie K-Fold standard."""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.default_config = {
            'n_splits': 5,
            'shuffle': True,
            'random_state': 42
        }
        self.config = {**self.default_config, **self.config}
        
        self.cv = KFold(
            n_splits=self.config['n_splits'],
            shuffle=self.config['shuffle'],
            random_state=self.config['random_state']
        )
    
    def split(self, X, y=None):
        """Génère les splits d'indices."""
        return self.cv.split(X, y)
    
    @timing_decorator
    @log_execution
    def evaluate(self, model, X, y, scoring='accuracy'):
        """Évalue le modèle avec K-Fold CV."""
        scores = cross_val_score(
            model, X, y,
            cv=self.cv,
            scoring=scoring,
            n_jobs=self.config.get('n_jobs', -1)
        )
        
        return {
            'strategy': self.get_name(),
            'mean': scores.mean(),
            'std': scores.std(),
            'scores': scores.tolist(),
            'n_splits': self.config['n_splits']
        }
    
    def get_name(self):
        """Retourne le nom de la stratégie."""
        shuffle_str = " shuffled" if self.config['shuffle'] else ""
        return f"KFold ({self.config['n_splits']} splits{shuffle_str})"

class StratifiedKFoldStrategy(CrossValidationStrategy):
    """Stratégie Stratified K-Fold pour données déséquilibrées."""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.default_config = {
            'n_splits': 5,
            'shuffle': True,
            'random_state': 42
        }
        self.config = {**self.default_config, **self.config}
        
        self.cv = StratifiedKFold(
            n_splits=self.config['n_splits'],
            shuffle=self.config['shuffle'],
            random_state=self.config['random_state']
        )
    
    def split(self, X, y):
        """Génère les splits d'indices."""
        if y is None:
            raise ValueError("StratifiedKFold nécessite y")
        return self.cv.split(X, y)
    
    @timing_decorator
    @log_execution
    def evaluate(self, model, X, y, scoring='accuracy'):
        """Évalue le modèle avec Stratified K-Fold CV."""
        scores = cross_val_score(
            model, X, y,
            cv=self.cv,
            scoring=scoring,
            n_jobs=self.config.get('n_jobs', -1)
        )
        
        return {
            'strategy': self.get_name(),
            'mean': scores.mean(),
            'std': scores.std(),
            'scores': scores.tolist(),
            'n_splits': self.config['n_splits']
        }
    
    def get_name(self):
        """Retourne le nom de la stratégie."""
        shuffle_str = " shuffled" if self.config['shuffle'] else ""
        return f"StratifiedKFold ({self.config['n_splits']} splits{shuffle_str})"

class TimeSeriesCVStrategy(CrossValidationStrategy):
    """Stratégie pour séries temporelles."""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.default_config = {
            'n_splits': 5,
            'max_train_size': None,
            'test_size': None,
            'gap': 0
        }
        self.config = {**self.default_config, **self.config}
        
        self.cv = TimeSeriesSplit(
            n_splits=self.config['n_splits'],
            max_train_size=self.config['max_train_size'],
            test_size=self.config['test_size'],
            gap=self.config['gap']
        )
    
    def split(self, X, y=None):
        """Génère les splits d'indices."""
        return self.cv.split(X)
    
    @timing_decorator
    @log_execution
    def evaluate(self, model, X, y, scoring='neg_mean_squared_error'):
        """Évalue le modèle avec Time Series CV."""
        scores = cross_val_score(
            model, X, y,
            cv=self.cv,
            scoring=scoring,
            n_jobs=self.config.get('n_jobs', -1)
        )
        
        return {
            'strategy': self.get_name(),
            'mean': scores.mean(),
            'std': scores.std(),
            'scores': scores.tolist(),
            'n_splits': self.config['n_splits']
        }
    
    def get_name(self):
        """Retourne le nom de la stratégie."""
        return f"TimeSeriesSplit ({self.config['n_splits']} splits)"

class LeaveOneOutStrategy(CrossValidationStrategy):
    """Stratégie Leave-One-Out."""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        from sklearn.model_selection import LeaveOneOut
        self.cv = LeaveOneOut()
    
    def split(self, X, y=None):
        """Génère les splits d'indices."""
        return self.cv.split(X, y)
    
    @timing_decorator
    @log_execution
    def evaluate(self, model, X, y, scoring='accuracy'):
        """Évalue le modèle avec Leave-One-Out CV."""
        scores = cross_val_score(
            model, X, y,
            cv=self.cv,
            scoring=scoring,
            n_jobs=self.config.get('n_jobs', -1)
        )
        
        return {
            'strategy': self.get_name(),
            'mean': scores.mean(),
            'std': scores.std(),
            'scores': scores.tolist(),
            'n_splits': len(X)  # LOOCV a n_splits = n_samples
        }
    
    def get_name(self):
        """Retourne le nom de la stratégie."""
        return "Leave-One-Out"

class RepeatedKFoldStrategy(CrossValidationStrategy):
    """Stratégie Repeated K-Fold."""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.default_config = {
            'n_splits': 5,
            'n_repeats': 10,
            'random_state': 42
        }
        self.config = {**self.default_config, **self.config}
        
        from sklearn.model_selection import RepeatedKFold
        self.cv = RepeatedKFold(
            n_splits=self.config['n_splits'],
            n_repeats=self.config['n_repeats'],
            random_state=self.config['random_state']
        )
    
    def split(self, X, y=None):
        """Génère les splits d'indices."""
        return self.cv.split(X, y)
    
    @timing_decorator
    @log_execution
    def evaluate(self, model, X, y, scoring='accuracy'):
        """Évalue le modèle avec Repeated K-Fold CV."""
        scores = cross_val_score(
            model, X, y,
            cv=self.cv,
            scoring=scoring,
            n_jobs=self.config.get('n_jobs', -1)
        )
        
        return {
            'strategy': self.get_name(),
            'mean': scores.mean(),
            'std': scores.std(),
            'scores': scores.tolist(),
            'n_splits': self.config['n_splits'],
            'n_repeats': self.config['n_repeats'],
            'total_splits': self.config['n_splits'] * self.config['n_repeats']
        }
    
    def get_name(self):
        """Retourne le nom de la stratégie."""
        return f"RepeatedKFold ({self.config['n_splits']} splits × {self.config['n_repeats']} repeats)"

class GroupKFoldStrategy(CrossValidationStrategy):
    """Stratégie Group K-Fold."""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.default_config = {
            'n_splits': 5,
            'shuffle': False,
            'random_state': None
        }
        self.config = {**self.default_config, **self.config}
        
        from sklearn.model_selection import GroupKFold
        self.cv = GroupKFold(
            n_splits=self.config['n_splits']
        )
    
    def split(self, X, y, groups):
        """Génère les splits d'indices avec groupes."""
        return self.cv.split(X, y, groups)
    
    @timing_decorator
    @log_execution
    def evaluate(self, model, X, y, groups, scoring='accuracy'):
        """Évalue le modèle avec Group K-Fold CV."""
        from sklearn.model_selection import cross_val_score
        
        scores = cross_val_score(
            model, X, y,
            cv=self.cv,
            scoring=scoring,
            groups=groups,
            n_jobs=self.config.get('n_jobs', -1)
        )
        
        return {
            'strategy': self.get_name(),
            'mean': scores.mean(),
            'std': scores.std(),
            'scores': scores.tolist(),
            'n_splits': self.config['n_splits']
        }
    
    def get_name(self):
        """Retourne le nom de la stratégie."""
        return f"GroupKFold ({self.config['n_splits']} splits)"

class CrossValidationContext:
    """Contexte qui utilise une stratégie de validation croisée (pattern Strategy)."""
    
    def __init__(self, strategy: CrossValidationStrategy = None):
        self.strategy = strategy or KFoldStrategy()
    
    def set_strategy(self, strategy: CrossValidationStrategy):
        """Change la stratégie à la volée."""
        self.strategy = strategy
    
    def perform_cv(self, model, X, y, **kwargs):
        """Exécute la validation croisée avec la stratégie courante."""
        if self.strategy is None:
            raise ValueError("Aucune stratégie définie")
        
        print(f"Utilisation de la stratégie: {self.strategy.get_name()}")
        return self.strategy.evaluate(model, X, y, **kwargs)
    
    def compare_strategies(self, strategies: List[CrossValidationStrategy], 
                          model, X, y, scoring='accuracy'):
        """Compare plusieurs stratégies de validation croisée."""
        comparison = {}
        
        for strategy in strategies:
            self.set_strategy(strategy)
            results = self.perform_cv(model, X, y, scoring=scoring)
            comparison[strategy.get_name()] = results
        
        return comparison
    
    def hyperparameter_tuning(self, model, param_grid, X, y, 
                            scoring='accuracy', refit=True):
        """Recherche d'hyperparamètres avec validation croisée."""
        from sklearn.model_selection import GridSearchCV
        
        grid_search = GridSearchCV(
            model,
            param_grid,
            cv=self.strategy.cv,
            scoring=scoring,
            refit=refit,
            n_jobs=self.strategy.config.get('n_jobs', -1),
            verbose=1
        )
        
        grid_search.fit(X, y)
        
        return {
            'best_estimator': grid_search.best_estimator_,
            'best_params': grid_search.best_params_,
            'best_score': grid_search.best_score_,
            'cv_results': grid_search.cv_results_,
            'strategy': self.strategy.get_name()
        }

class NestedCrossValidation:
    """Validation croisée imbriquée."""
    
    def __init__(self, inner_strategy=None, outer_strategy=None):
        self.inner_strategy = inner_strategy or StratifiedKFoldStrategy({'n_splits': 5})
        self.outer_strategy = outer_strategy or StratifiedKFoldStrategy({'n_splits': 5})
        
        self.inner_context = CrossValidationContext(self.inner_strategy)
        self.outer_context = CrossValidationContext(self.outer_strategy)
    
    @timing_decorator
    @log_execution
    def evaluate(self, model, X, y, param_grid=None, scoring='accuracy'):
        """Exécute une validation croisée imbriquée."""
        outer_scores = []
        best_models = []
        
        # Obtenir les splits externes
        outer_splits = list(self.outer_strategy.split(X, y))
        
        print(f"Début de la validation croisée imbriquée")
        print(f"  Stratégie externe: {self.outer_strategy.get_name()}")
        print(f"  Stratégie interne: {self.inner_strategy.get_name()}")
        
        for i, (train_idx, test_idx) in enumerate(outer_splits):
            print(f"\nFold externe {i+1}/{len(outer_splits)}")
            
            # Split des données
            X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
            y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
            
            if param_grid:
                # Recherche d'hyperparamètres sur le fold interne
                tuning_results = self.inner_context.hyperparameter_tuning(
                    model, param_grid, X_train, y_train, scoring=scoring
                )
                
                best_model = tuning_results['best_estimator']
                best_models.append(best_model)
                
                # Évaluer sur le fold de test externe
                score = best_model.score(X_test, y_test)
            else:
                # Entraîner simplement le modèle
                model.fit(X_train, y_train)
                score = model.score(X_test, y_test)
            
            outer_scores.append(score)
            print(f"  Score sur le fold de test: {score:.4f}")
        
        return {
            'outer_scores': outer_scores,
            'mean_score': np.mean(outer_scores),
            'std_score': np.std(outer_scores),
            'best_models': best_models if param_grid else [],
            'inner_strategy': self.inner_strategy.get_name(),
            'outer_strategy': self.outer_strategy.get_name()
        }