"""
Classes pour l'entraînement des modèles ML.
"""

import pandas as pd
import numpy as np
from typing import Optional, Dict, Any, List, Union
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LogisticRegression, LinearRegression, Ridge, Lasso
from sklearn.svm import SVC, SVR
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.naive_bayes import GaussianNB
from xgboost import XGBClassifier, XGBRegressor
from lightgbm import LGBMClassifier, LGBMRegressor
from catboost import CatBoostClassifier, CatBoostRegressor
from ..models.base_model import BaseModel
from ..core.decorators import timing_decorator, log_execution

class ModelTrainer(BaseModel):
    """Classe de base pour les entraîneurs de modèles."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = None
        self.default_config = {
            'random_state': 42,
            'verbose': False,
            'n_jobs': -1
        }
        self.config = {**self.default_config, **(config or {})}
    
    def _create_model(self):
        """Crée l'instance du modèle (à implémenter par les sous-classes)."""
        raise NotImplementedError
    
    @timing_decorator
    @log_execution
    def fit(self, X, y):
        """Entraîne le modèle."""
        # Créer le modèle s'il n'existe pas
        if self.model is None:
            self.model = self._create_model()
        
        # Sauvegarder les noms des features
        if hasattr(X, 'columns'):
            self.feature_names = list(X.columns)
        elif isinstance(X, pd.DataFrame):
            self.feature_names = list(X.columns)
        else:
            self.feature_names = [f'feature_{i}' for i in range(X.shape[1])]
        
        # Sauvegarder le nom de la target
        if hasattr(y, 'name'):
            self.target_name = y.name
        elif isinstance(y, pd.Series):
            self.target_name = y.name
        
        # Entraîner le modèle
        self.model.fit(X, y)
        self.is_fitted = True
        
        return self
    
    def predict(self, X):
        """Fait des prédictions."""
        self._check_is_fitted()
        return self.model.predict(X)
    
    def predict_proba(self, X):
        """Fait des prédictions probabilistes."""
        self._check_is_fitted()
        
        if hasattr(self.model, 'predict_proba'):
            return self.model.predict_proba(X)
        else:
            raise NotImplementedError(
                f"Le modèle {self.__class__.__name__} ne supporte pas predict_proba"
            )
    
    def get_params(self, deep: bool = True) -> Dict:
        """Retourne les paramètres du modèle."""
        if self.model is not None:
            return self.model.get_params(deep)
        return super().get_params(deep)

class RandomForestTrainer(ModelTrainer):
    """Entraîneur pour Random Forest."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'random_forest'
        self.rf_config = {
            'n_estimators': 100,
            'max_depth': None,
            'min_samples_split': 2,
            'min_samples_leaf': 1,
            'max_features': 'auto'
        }
        self.config = {**self.rf_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle Random Forest."""
        # Déterminer si c'est une classification ou régression
        # Note: on ne peut pas savoir sans y, donc on crée un classificateur par défaut
        # L'utilisateur peut spécifier 'regression' dans config
        model_type = self.config.get('problem_type', 'classification')
        
        if model_type == 'regression':
            return RandomForestRegressor(**{
                k: v for k, v in self.config.items()
                if k in RandomForestRegressor.__init__.__code__.co_varnames
            })
        else:
            return RandomForestClassifier(**{
                k: v for k, v in self.config.items()
                if k in RandomForestClassifier.__init__.__code__.co_varnames
            })

class LogisticRegressionTrainer(ModelTrainer):
    """Entraîneur pour Logistic Regression."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'logistic_regression'
        self.lr_config = {
            'penalty': 'l2',
            'C': 1.0,
            'solver': 'lbfgs',
            'max_iter': 100,
            'multi_class': 'auto'
        }
        self.config = {**self.lr_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle Logistic Regression."""
        return LogisticRegression(**{
            k: v for k, v in self.config.items()
            if k in LogisticRegression.__init__.__code__.co_varnames
        })

class XGBoostTrainer(ModelTrainer):
    """Entraîneur pour XGBoost."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'xgboost'
        self.xgb_config = {
            'n_estimators': 100,
            'max_depth': 6,
            'learning_rate': 0.3,
            'subsample': 1.0,
            'colsample_bytree': 1.0,
            'objective': 'binary:logistic',
            'eval_metric': 'logloss'
        }
        self.config = {**self.xgb_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle XGBoost."""
        # Déterminer si c'est une classification ou régression
        objective = self.config.get('objective', 'binary:logistic')
        
        if 'reg' in objective or 'regression' in objective:
            return XGBRegressor(**{
                k: v for k, v in self.config.items()
                if k in XGBRegressor.__init__.__code__.co_varnames
            })
        else:
            return XGBClassifier(**{
                k: v for k, v in self.config.items()
                if k in XGBClassifier.__init__.__code__.co_varnames
            })

class SVMTrainer(ModelTrainer):
    """Entraîneur pour SVM."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'svm'
        self.svm_config = {
            'C': 1.0,
            'kernel': 'rbf',
            'gamma': 'scale',
            'probability': True
        }
        self.config = {**self.svm_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle SVM."""
        # Déterminer si c'est une classification ou régression
        problem_type = self.config.get('problem_type', 'classification')
        
        if problem_type == 'regression':
            return SVR(**{
                k: v for k, v in self.config.items()
                if k in SVR.__init__.__code__.co_varnames
            })
        else:
            return SVC(**{
                k: v for k, v in self.config.items()
                if k in SVC.__init__.__code__.co_varnames
            })

class KNeighborsTrainer(ModelTrainer):
    """Entraîneur pour K-Nearest Neighbors."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'knn'
        self.knn_config = {
            'n_neighbors': 5,
            'weights': 'uniform',
            'algorithm': 'auto',
            'leaf_size': 30,
            'p': 2  # distance metric (2 = Euclidean)
        }
        self.config = {**self.knn_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle K-Nearest Neighbors."""
        # Déterminer si c'est une classification ou régression
        problem_type = self.config.get('problem_type', 'classification')
        
        if problem_type == 'regression':
            return KNeighborsRegressor(**{
                k: v for k, v in self.config.items()
                if k in KNeighborsRegressor.__init__.__code__.co_varnames
            })
        else:
            return KNeighborsClassifier(**{
                k: v for k, v in self.config.items()
                if k in KNeighborsClassifier.__init__.__code__.co_varnames
            })

class DecisionTreeTrainer(ModelTrainer):
    """Entraîneur pour Decision Tree."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'decision_tree'
        self.dt_config = {
            'max_depth': None,
            'min_samples_split': 2,
            'min_samples_leaf': 1,
            'max_features': None,
            'random_state': 42
        }
        self.config = {**self.dt_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle Decision Tree."""
        # Déterminer si c'est une classification ou régression
        problem_type = self.config.get('problem_type', 'classification')
        
        if problem_type == 'regression':
            return DecisionTreeRegressor(**{
                k: v for k, v in self.config.items()
                if k in DecisionTreeRegressor.__init__.__code__.co_varnames
            })
        else:
            return DecisionTreeClassifier(**{
                k: v for k, v in self.config.items()
                if k in DecisionTreeClassifier.__init__.__code__.co_varnames
            })

class NaiveBayesTrainer(ModelTrainer):
    """Entraîneur pour Naive Bayes."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'naive_bayes'
        self.nb_config = {
            'var_smoothing': 1e-9
        }
        self.config = {**self.nb_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle Naive Bayes."""
        return GaussianNB(**self.config)

class LinearRegressionTrainer(ModelTrainer):
    """Entraîneur pour Linear Regression."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'linear_regression'
        self.linreg_config = {
            'fit_intercept': True,
            'normalize': False,  # Déprécié dans scikit-learn > 1.0
            'copy_X': True,
            'n_jobs': None
        }
        self.config = {**self.linreg_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle Linear Regression."""
        return LinearRegression(**{
            k: v for k, v in self.config.items()
            if k in LinearRegression.__init__.__code__.co_varnames
        })

class RidgeRegressionTrainer(ModelTrainer):
    """Entraîneur pour Ridge Regression."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'ridge_regression'
        self.ridge_config = {
            'alpha': 1.0,
            'fit_intercept': True,
            'normalize': False,
            'copy_X': True,
            'max_iter': None,
            'tol': 0.001,
            'solver': 'auto',
            'random_state': None
        }
        self.config = {**self.ridge_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle Ridge Regression."""
        return Ridge(**{
            k: v for k, v in self.config.items()
            if k in Ridge.__init__.__code__.co_varnames
        })

class LassoRegressionTrainer(ModelTrainer):
    """Entraîneur pour Lasso Regression."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'lasso_regression'
        self.lasso_config = {
            'alpha': 1.0,
            'fit_intercept': True,
            'normalize': False,
            'precompute': False,
            'copy_X': True,
            'max_iter': 1000,
            'tol': 0.0001,
            'warm_start': False,
            'positive': False,
            'random_state': None,
            'selection': 'cyclic'
        }
        self.config = {**self.lasso_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle Lasso Regression."""
        return Lasso(**{
            k: v for k, v in self.config.items()
            if k in Lasso.__init__.__code__.co_varnames
        })

class LightGBMTrainer(ModelTrainer):
    """Entraîneur pour LightGBM."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'lightgbm'
        self.lgb_config = {
            'n_estimators': 100,
            'max_depth': -1,
            'learning_rate': 0.1,
            'num_leaves': 31,
            'subsample': 1.0,
            'colsample_bytree': 1.0,
            'objective': 'binary',
            'metric': 'binary_logloss',
            'boosting_type': 'gbdt',
            'verbose': -1
        }
        self.config = {**self.lgb_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle LightGBM."""
        # Déterminer si c'est une classification ou régression
        objective = self.config.get('objective', 'binary')
        
        if 'regression' in objective or 'l2' in objective or 'mse' in objective:
            return LGBMRegressor(**{
                k: v for k, v in self.config.items()
                if k in LGBMRegressor.__init__.__code__.co_varnames
            })
        else:
            return LGBMClassifier(**{
                k: v for k, v in self.config.items()
                if k in LGBMClassifier.__init__.__code__.co_varnames
            })

class CatBoostTrainer(ModelTrainer):
    """Entraîneur pour CatBoost."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model_type = 'catboost'
        self.cb_config = {
            'iterations': 100,
            'depth': 6,
            'learning_rate': 0.03,
            'loss_function': 'Logloss',
            'verbose': False,
            'random_seed': 42
        }
        self.config = {**self.cb_config, **self.config}
    
    def _create_model(self):
        """Crée un modèle CatBoost."""
        # Déterminer si c'est une classification ou régression
        loss_function = self.config.get('loss_function', 'Logloss')
        
        if 'RMSE' in loss_function or 'MAE' in loss_function or 'Quantile' in loss_function:
            return CatBoostRegressor(**{
                k: v for k, v in self.config.items()
                if k in CatBoostRegressor.__init__.__code__.co_varnames
            })
        else:
            return CatBoostClassifier(**{
                k: v for k, v in self.config.items()
                if k in CatBoostClassifier.__init__.__code__.co_varnames
            })

# Factory simplifiée
class TrainerFactory:
    """Factory pour créer des entraîneurs de modèles."""
    
    _trainers = {
        'random_forest': RandomForestTrainer,
        'logistic_regression': LogisticRegressionTrainer,
        'xgboost': XGBoostTrainer,
        'svm': SVMTrainer,
        'knn': KNeighborsTrainer,
        'decision_tree': DecisionTreeTrainer,
        'naive_bayes': NaiveBayesTrainer,
        'linear_regression': LinearRegressionTrainer,
        'ridge': RidgeRegressionTrainer,
        'lasso': LassoRegressionTrainer,
        'lightgbm': LightGBMTrainer,
        'catboost': CatBoostTrainer
    }
    
    @classmethod
    def create_trainer(cls, trainer_type: str, **kwargs) -> ModelTrainer:
        """Crée un entraîneur basé sur le type."""
        if trainer_type not in cls._trainers:
            raise ValueError(f"Type d'entraîneur non supporté: {trainer_type}")
        
        return cls._trainers[trainer_type](config=kwargs)
    
    @classmethod
    def list_trainers(cls) -> List[str]:
        """Liste tous les entraîneurs disponibles."""
        return list(cls._trainers.keys())