"""
Classes de base pour les modèles ML.
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, List, Union
import pandas as pd
import numpy as np
import pickle
import json
from ..core.base import BaseEstimator
from ..core.decorators import timing_decorator, log_execution

class BaseModel(BaseEstimator, ABC):
    """Classe de base abstraite pour tous les modèles ML."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.model = None
        self.feature_names = []
        self.target_name = None
    
    @abstractmethod
    def fit(self, X, y):
        """Entraîne le modèle."""
        pass
    
    @abstractmethod
    def predict(self, X):
        """Fait des prédictions."""
        pass
    
    def predict_proba(self, X):
        """Fait des prédictions probabilistes (pour classification)."""
        if hasattr(self.model, 'predict_proba'):
            return self.model.predict_proba(X)
        else:
            raise NotImplementedError(
                f"Le modèle {self.__class__.__name__} ne supporte pas predict_proba"
            )
    
    def predict_log_proba(self, X):
        """Fait des prédictions log-probabilistes."""
        if hasattr(self.model, 'predict_log_proba'):
            return self.model.predict_log_proba(X)
        else:
            raise NotImplementedError(
                f"Le modèle {self.__class__.__name__} ne supporte pas predict_log_proba"
            )
    
    def score(self, X, y):
        """Évalue le modèle."""
        if hasattr(self.model, 'score'):
            return self.model.score(X, y)
        else:
            from sklearn.metrics import accuracy_score
            y_pred = self.predict(X)
            return accuracy_score(y, y_pred)
    
    def save(self, filepath: str):
        """Sauvegarde le modèle."""
        with open(filepath, 'wb') as f:
            pickle.dump(self, f)
    
    @classmethod
    def load(cls, filepath: str):
        """Charge un modèle sauvegardé."""
        with open(filepath, 'rb') as f:
            return pickle.load(f)
    
    def get_params(self, deep: bool = True) -> Dict:
        """Retourne les paramètres du modèle."""
        if self.model is not None and hasattr(self.model, 'get_params'):
            return self.model.get_params(deep)
        return self.config.copy()
    
    def set_params(self, **params):
        """Définit les paramètres du modèle."""
        if self.model is not None and hasattr(self.model, 'set_params'):
            self.model.set_params(**params)
        else:
            self.config.update(params)
        return self
    
    def get_feature_importance(self) -> Dict[str, float]:
        """Retourne l'importance des features."""
        if hasattr(self.model, 'feature_importances_'):
            importance_dict = dict(zip(
                self.feature_names,
                self.model.feature_importances_
            ))
            return importance_dict
        elif hasattr(self.model, 'coef_'):
            # Pour les modèles linéaires
            if len(self.model.coef_.shape) == 1:
                importance_dict = dict(zip(
                    self.feature_names,
                    self.model.coef_
                ))
            else:
                # Multi-class
                importance_dict = {}
                for i in range(self.model.coef_.shape[0]):
                    for j, feature in enumerate(self.feature_names):
                        importance_dict[f'{feature}_class_{i}'] = self.model.coef_[i, j]
            return importance_dict
        else:
            return {}
    
    def to_json(self) -> str:
        """Convertit le modèle en JSON."""
        model_info = {
            'model_type': self.__class__.__name__,
            'config': self.config,
            'is_fitted': self.is_fitted,
            'feature_names': self.feature_names,
            'target_name': self.target_name
        }
        return json.dumps(model_info, indent=2)

class ModelFactory:
    """Factory pour créer des modèles ML."""
    
    @staticmethod
    def create_model(model_type: str, **kwargs) -> BaseModel:
        """Crée un modèle basé sur le type."""
        from .trainer import (
            RandomForestTrainer, LogisticRegressionTrainer,
            XGBoostTrainer, SVMTrainer, KNeighborsTrainer
        )
        
        model_map = {
            'random_forest': RandomForestTrainer,
            'logistic_regression': LogisticRegressionTrainer,
            'xgboost': XGBoostTrainer,
            'svm': SVMTrainer,
            'knn': KNeighborsTrainer
        }
        
        if model_type not in model_map:
            raise ValueError(f"Type de modèle non supporté: {model_type}")
        
        return model_map[model_type](config=kwargs)
    
    @staticmethod
    def create_from_config(config: Dict) -> BaseModel:
        """Crée un modèle à partir d'une configuration."""
        model_type = config.get('model_type')
        if not model_type:
            raise ValueError("La configuration doit contenir 'model_type'")
        
        model_config = config.get('model_config', {})
        return ModelFactory.create_model(model_type, **model_config)

class ModelRegistry:
    """Registre pour les modèles ML."""
    
    _models = {}
    
    @classmethod
    def register(cls, name: str, model_class):
        """Enregistre une classe de modèle."""
        cls._models[name] = model_class
    
    @classmethod
    def get(cls, name: str) -> BaseModel:
        """Récupère une instance de modèle."""
        if name not in cls._models:
            raise KeyError(f"Modèle '{name}' non trouvé dans le registre")
        
        return cls._models[name]()
    
    @classmethod
    def list_models(cls) -> List[str]:
        """Liste tous les modèles enregistrés."""
        return list(cls._models.keys())
    
    @classmethod
    def register_default_models(cls):
        """Enregistre les modèles par défaut."""
        from .trainer import (
            RandomForestTrainer, LogisticRegressionTrainer,
            XGBoostTrainer, SVMTrainer, KNeighborsTrainer
        )
        
        cls.register('random_forest', RandomForestTrainer)
        cls.register('logistic_regression', LogisticRegressionTrainer)
        cls.register('xgboost', XGBoostTrainer)
        cls.register('svm', SVMTrainer)
        cls.register('knn', KNeighborsTrainer)