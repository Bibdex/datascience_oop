"""
Décorateurs pour le package.
"""

import time
import functools
import logging
from datetime import datetime
from typing import Callable, Any, Type, Tuple
import inspect

# Configuration du logger
logger = logging.getLogger(__name__)

def timing_decorator(func: Callable) -> Callable:
    """Décorateur qui mesure le temps d'exécution."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs) -> Any:
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        
        duration = end_time - start_time
        logger.info(f"{func.__name__} exécuté en {duration:.4f} secondes")
        
        # Enregistrer dans un fichier de timing
        try:
            with open('timing_log.txt', 'a') as f:
                f.write(f"{datetime.now()}: {func.__name__} - {duration:.4f}s\n")
        except:
            pass
        
        return result
    return wrapper

def timing_with_threshold(threshold: float = 1.0) -> Callable:
    """Décorateur avec seuil d'alerte."""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            start_time = time.time()
            result = func(*args, **kwargs)
            end_time = time.time()
            
            duration = end_time - start_time
            if duration > threshold:
                logger.warning(
                    f"{func.__name__} a pris {duration:.4f}s (> {threshold}s)"
                )
            
            return result
        return wrapper
    return decorator

def log_execution(func: Callable) -> Callable:
    """Décorateur pour logger l'exécution des méthodes."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs) -> Any:
        # Récupérer le nom de la classe si c'est une méthode d'instance
        class_name = None
        if args and hasattr(args[0], '__class__'):
            class_name = args[0].__class__.__name__
        
        func_name = f"{class_name}.{func.__name__}" if class_name else func.__name__
        
        logger.info(f"Début de {func_name}")
        logger.debug(f"Arguments: {args[1:] if class_name else args}, {kwargs}")
        
        try:
            result = func(*args, **kwargs)
            logger.info(f"Succès de {func_name}")
            return result
        except Exception as e:
            logger.error(f"Échec de {func_name}: {str(e)}", exc_info=True)
            raise
    
    return wrapper

def validate_input_types(*type_constraints: Tuple[Type, ...]) -> Callable:
    """Décorateur pour valider les types des arguments."""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            # Obtenir la signature de la fonction
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            
            # Validation des types
            for param_name, param_value in bound_args.arguments.items():
                param = sig.parameters[param_name]
                
                # Vérifier s'il y a une annotation de type
                if param.annotation != inspect.Parameter.empty:
                    expected_type = param.annotation
                    
                    # Gérer les types optionnels (Union[Type, None])
                    if hasattr(expected_type, '__origin__') and expected_type.__origin__ == type(Union):
                        expected_types = expected_type.__args__
                    else:
                        expected_types = (expected_type,)
                    
                    # Vérifier si le type correspond
                    if not isinstance(param_value, expected_types) and param_value is not None:
                        raise TypeError(
                            f"Le paramètre '{param_name}' de {func.__name__} doit être de type "
                            f"{expected_type}, pas {type(param_value).__name__}"
                        )
            
            return func(*args, **kwargs)
        return wrapper
    return decorator

def retry_on_failure(max_retries: int = 3, delay: float = 1.0) -> Callable:
    """Décorateur pour réessayer en cas d'échec."""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    logger.warning(
                        f"Tentative {attempt + 1}/{max_retries} échouée pour {func.__name__}: {str(e)}"
                    )
                    
                    if attempt < max_retries - 1:
                        time.sleep(delay * (attempt + 1))  # Backoff exponentiel
            
            # Si toutes les tentatives ont échoué
            logger.error(f"Toutes les tentatives ont échoué pour {func.__name__}")
            raise last_exception
        
        return wrapper
    return decorator

def cache_result(cache_key: str = None) -> Callable:
    """Décorateur pour mettre en cache les résultats."""
    cache = {}
    
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            # Générer une clé de cache
            if cache_key:
                key = cache_key
            else:
                key = f"{func.__name__}_{args}_{kwargs}"
            
            # Vérifier si le résultat est en cache
            if key in cache:
                logger.debug(f"Récupération depuis le cache: {func.__name__}")
                return cache[key]
            
            # Exécuter la fonction
            result = func(*args, **kwargs)
            
            # Mettre en cache
            cache[key] = result
            logger.debug(f"Résultat mis en cache: {func.__name__}")
            
            return result
        
        return wrapper
    return decorator