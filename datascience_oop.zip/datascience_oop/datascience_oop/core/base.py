"""
Classes de base abstraites pour le package.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple
import pandas as pd
import numpy as np

class BaseEstimator(ABC):
    """Classe de base pour tous les estimateurs."""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.is_fitted = False
    
    @abstractmethod
    def fit(self, X, y=None):
        """Ajuste l'estimateur aux données."""
        pass
    
    @abstractmethod
    def transform(self, X):
        """Transforme les données."""
        pass
    
    def fit_transform(self, X, y=None):
        """Ajuste et transforme les données."""
        self.fit(X, y)
        return self.transform(X)
    
    def _check_is_fitted(self):
        """Vérifie si l'estimateur a été ajusté."""
        if not self.is_fitted:
            raise RuntimeError("L'estimateur doit être ajusté avant d'être utilisé.")

class PipelineComponent(BaseEstimator):
    """Composant abstrait de pipeline."""
    
    def __init__(self, name: str = None, config: Optional[Dict] = None):
        super().__init__(config)
        self.name = name or self.__class__.__name__
        self.metadata = {}
    
    @abstractmethod
    def process(self, data: Any) -> Any:
        """Traite les données."""
        pass
    
    def get_params(self) -> Dict:
        """Retourne les paramètres du composant."""
        return self.config.copy()
    
    def set_params(self, **params):
        """Définit les paramètres du composant."""
        self.config.update(params)
        return self

class ValidationRule(ABC):
    """Règle abstraite de validation."""
    
    def __init__(self, column: Optional[str] = None, 
                 severity: str = 'error',
                 description: str = ''):
        self.column = column
        self.severity = severity  # 'error', 'warning', 'info'
        self.description = description
    
    @abstractmethod
    def validate(self, df: pd.DataFrame) -> Tuple[bool, str]:
        """Valide le DataFrame et retourne (succès, message)."""
        pass
    
    def get_name(self) -> str:
        """Retourne le nom de la règle."""
        return self.__class__.__name__
    
    def __str__(self) -> str:
        return f"{self.get_name()}(column={self.column}, severity={self.severity})"

class Registry:
    """Registre pour les composants (pattern Registry)."""
    
    _components = {}
    
    @classmethod
    def register(cls, name: str, component_class):
        """Enregistre une classe de composant."""
        cls._components[name] = component_class
    
    @classmethod
    def get(cls, name: str):
        """Récupère une classe de composant."""
        if name not in cls._components:
            raise KeyError(f"Composant '{name}' non trouvé dans le registre")
        return cls._components[name]
    
    @classmethod
    def list_components(cls) -> List[str]:
        """Liste tous les composants enregistrés."""
        return list(cls._components.keys())