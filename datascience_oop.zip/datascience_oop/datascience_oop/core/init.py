"""
Module core - Classes de base et composants fondamentaux.
"""

from .base import PipelineComponent, ValidationRule, BaseEstimator
from .decorators import timing_decorator, log_execution, validate_input_types
from .exceptions import (
    DataValidationError, PipelineError, 
    ModelTrainingError, ConfigurationError
)

__all__ = [
    'PipelineComponent',
    'ValidationRule',
    'BaseEstimator',
    'timing_decorator',
    'log_execution',
    'validate_input_types',
    'DataValidationError',
    'PipelineError',
    'ModelTrainingError',
    'ConfigurationError',
]