"""
Exceptions personnalisées pour le package.
"""

class DataScienceOOPError(Exception):
    """Exception de base pour le package."""
    pass

class ConfigurationError(DataScienceOOPError):
    """Erreur de configuration."""
    pass

class DataValidationError(DataScienceOOPError):
    """Erreur de validation des données."""
    pass

class PipelineError(DataScienceOOPError):
    """Erreur d'exécution du pipeline."""
    pass

class ModelTrainingError(DataScienceOOPError):
    """Erreur d'entraînement du modèle."""
    pass

class FeatureEngineeringError(DataScienceOOPError):
    """Erreur d'ingénierie des features."""
    pass

class SerializationError(DataScienceOOPError):
    """Erreur de sérialisation."""
    pass

class DatasetError(DataScienceOOPError):
    """Erreur liée aux datasets."""
    pass

class ValidationRuleError(DataValidationError):
    """Erreur spécifique à une règle de validation."""
    pass

class CrossValidationError(DataScienceOOPError):
    """Erreur de validation croisée."""
    pass

class DecoratorError(DataScienceOOPError):
    """Erreur liée aux décorateurs."""
    pass