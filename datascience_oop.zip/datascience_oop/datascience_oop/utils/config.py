import json
import yaml
from pathlib import Path
from typing import Dict, Any, Optional

class ConfigManager:
    """Gestionnaire de configuration."""
    
    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path
        self.config = {}
        
        if config_path:
            self.load(config_path)
    
    def load(self, filepath: str):
        """Charge la configuration depuis un fichier."""
        path = Path(filepath)
        
        if not path.exists():
            raise FileNotFoundError(f"Fichier de configuration non trouvé: {filepath}")
        
        if path.suffix in ['.json']:
            self._load_json(filepath)
        elif path.suffix in ['.yaml', '.yml']:
            self._load_yaml(filepath)
        else:
            raise ValueError(f"Format non supporté: {path.suffix}")
        
        return self
    
    def _load_json(self, filepath: str):
        with open(filepath, 'r') as f:
            self.config = json.load(f)
    
    def _load_yaml(self, filepath: str):
        try:
            import yaml
            with open(filepath, 'r') as f:
                self.config = yaml.safe_load(f)
        except ImportError:
            raise ImportError("PyYAML est requis pour charger les fichiers YAML")
    
    def get(self, key: str, default: Any = None) -> Any:
        """Récupère une valeur de configuration."""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """Définit une valeur de configuration."""
        keys = key.split('.')
        config = self.config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
    
    def save(self, filepath: str):
        """Sauvegarde la configuration dans un fichier."""
        path = Path(filepath)
        
        if path.suffix == '.json':
            with open(filepath, 'w') as f:
                json.dump(self.config, f, indent=2)
        elif path.suffix in ['.yaml', '.yml']:
            import yaml
            with open(filepath, 'w') as f:
                yaml.dump(self.config, f, default_flow_style=False)
        else:
            raise ValueError(f"Format non supporté: {path.suffix}")
    
    def merge(self, other_config: Dict):
        """Fusionne avec une autre configuration."""
        self._merge_dicts(self.config, other_config)
    
    def _merge_dicts(self, target: Dict, source: Dict):
        """Fusionne récursivement deux dictionnaires."""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self._merge_dicts(target[key], value)
            else:
                target[key] = value
    
    def get_pipeline_config(self, pipeline_type: str) -> Dict:
        """Récupère la configuration pour un type de pipeline spécifique."""
        return self.get(f'pipelines.{pipeline_type}', {})
    
    def get_model_config(self, model_name: str) -> Dict:
        """Récupère la configuration pour un modèle spécifique."""
        return self.get(f'models.{model_name}', {})

# Configuration par défaut
DEFAULT_CONFIG = {
    'data': {
        'test_size': 0.2,
        'random_state': 42,
        'validation': {
            'fail_fast': False
        }
    },
    'models': {
        'random_forest': {
            'n_estimators': 100,
            'random_state': 42
        },
        'logistic_regression': {
            'max_iter': 1000,
            'random_state': 42
        }
    },
    'pipelines': {
        'ml': {
            'components': ['data_loader', 'scaler', 'model'],
            'cv_strategy': 'kfold'
        }
    },
    'logging': {
        'level': 'INFO',
        'file': 'pipeline.log',
        'console': True
    }
}