import pickle
import json
import joblib
import yaml
from pathlib import Path
from typing import Any, Dict
import pandas as pd
import numpy as np

def save_object(obj: Any, filepath: str, format: str = 'pickle'):
    """
    Sauvegarde un objet dans un fichier.
    
    Args:
        obj: L'objet à sauvegarder
        filepath: Chemin du fichier
        format: Format de sérialisation ('pickle', 'joblib', 'json', 'yaml')
    """
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    if format == 'pickle':
        with open(filepath, 'wb') as f:
            pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)
    
    elif format == 'joblib':
        joblib.dump(obj, filepath, compress=3)
    
    elif format == 'json':
        # Pour les objets sérialisables en JSON
        if isinstance(obj, (dict, list, str, int, float, bool, type(None))):
            with open(filepath, 'w') as f:
                json.dump(obj, f, indent=2)
        else:
            raise ValueError("L'objet n'est pas sérialisable en JSON")
    
    elif format == 'yaml':
        import yaml
        with open(filepath, 'w') as f:
            yaml.dump(obj, f, default_flow_style=False)
    
    else:
        raise ValueError(f"Format non supporté: {format}")

def load_object(filepath: str, format: str = 'auto') -> Any:
    """
    Charge un objet depuis un fichier.
    
    Args:
        filepath: Chemin du fichier
        format: Format de sérialisation ('auto', 'pickle', 'joblib', 'json', 'yaml')
    
    Returns:
        L'objet chargé
    """
    path = Path(filepath)
    
    if not path.exists():
        raise FileNotFoundError(f"Fichier non trouvé: {filepath}")
    
    # Détection automatique du format
    if format == 'auto':
        suffix = path.suffix.lower()
        if suffix == '.pkl' or suffix == '.pickle':
            format = 'pickle'
        elif suffix == '.joblib':
            format = 'joblib'
        elif suffix == '.json':
            format = 'json'
        elif suffix in ['.yaml', '.yml']:
            format = 'yaml'
        else:
            raise ValueError(f"Impossible de détecter le format pour: {suffix}")
    
    if format == 'pickle':
        with open(filepath, 'rb') as f:
            return pickle.load(f)
    
    elif format == 'joblib':
        return joblib.load(filepath)
    
    elif format == 'json':
        with open(filepath, 'r') as f:
            return json.load(f)
    
    elif format == 'yaml':
        import yaml
        with open(filepath, 'r') as f:
            return yaml.safe_load(f)
    
    else:
        raise ValueError(f"Format non supporté: {format}")

class ModelSerializer:
    """Sérialiseur spécialisé pour les modèles ML."""
    
    @staticmethod
    def save_model(model, filepath: str, metadata: Dict = None):
        """
        Sauvegarde un modèle avec ses métadonnées.
        
        Args:
            model: Le modèle à sauvegarder
            filepath: Chemin du fichier
            metadata: Métadonnées supplémentaires
        """
        import joblib
        
        data = {
            'model': model,
            'metadata': metadata or {},
            'timestamp': pd.Timestamp.now().isoformat(),
            'model_type': type(model).__name__
        }
        
        save_object(data, filepath, format='joblib')
    
    @staticmethod
    def load_model(filepath: str):
        """
        Charge un modèle sauvegardé.
        
        Returns:
            Tuple (model, metadata)
        """
        data = load_object(filepath, format='joblib')
        
        model = data['model']
        metadata = data.get('metadata', {})
        
        return model, metadata
    
    @staticmethod
    def save_pipeline(pipeline, filepath: str):
        """Sauvegarde un pipeline complet."""
        save_object(pipeline, filepath, format='pickle')
    
    @staticmethod
    def load_pipeline(filepath: str):
        """Charge un pipeline complet."""
        return load_object(filepath, format='pickle')

class DataSerializer:
    """Sérialiseur spécialisé pour les données."""
    
    @staticmethod
    def save_dataframe(df: pd.DataFrame, filepath: str, format: str = 'parquet'):
        """
        Sauvegarde un DataFrame.
        
        Args:
            df: DataFrame à sauvegarder
            filepath: Chemin du fichier
            format: Format ('parquet', 'csv', 'feather', 'pickle')
        """
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        if format == 'parquet':
            df.to_parquet(filepath, index=False)
        elif format == 'csv':
            df.to_csv(filepath, index=False)
        elif format == 'feather':
            df.to_feather(filepath)
        elif format == 'pickle':
            df.to_pickle(filepath)
        else:
            raise ValueError(f"Format non supporté: {format}")
    
    @staticmethod
    def load_dataframe(filepath: str, format: str = 'auto') -> pd.DataFrame:
        """
        Charge un DataFrame.
        
        Args:
            filepath: Chemin du fichier
            format: Format ('auto', 'parquet', 'csv', 'feather', 'pickle')
        """
        path = Path(filepath)
        
        # Détection automatique du format
        if format == 'auto':
            suffix = path.suffix.lower()
            if suffix == '.parquet':
                format = 'parquet'
            elif suffix == '.csv':
                format = 'csv'
            elif suffix == '.feather':
                format = 'feather'
            elif suffix in ['.pkl', '.pickle']:
                format = 'pickle'
            else:
                raise ValueError(f"Impossible de détecter le format pour: {suffix}")
        
        if format == 'parquet':
            return pd.read_parquet(filepath)
        elif format == 'csv':
            return pd.read_csv(filepath)
        elif format == 'feather':
            return pd.read_feather(filepath)
        elif format == 'pickle':
            return pd.read_pickle(filepath)
        else:
            raise ValueError(f"Format non supporté: {format}")