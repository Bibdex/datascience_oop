import logging
import sys
from datetime import datetime
from pathlib import Path

def setup_logging(log_file=None, level=logging.INFO, console=True):
    """
    Configure le logging pour l'application.
    
    Args:
        log_file (str): Chemin du fichier de log
        level (int): Niveau de logging
        console (bool): Afficher les logs dans la console
    """
    # Créer le formateur
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Configurer le logger racine
    logger = logging.getLogger()
    logger.setLevel(level)
    
    # Nettoyer les handlers existants
    logger.handlers.clear()
    
    # Handler console
    if console:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    # Handler fichier
    if log_file:
        # Créer le répertoire si nécessaire
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger

def get_logger(name):
    """Retourne un logger nommé."""
    return logging.getLogger(name)

class PipelineLogger:
    """Logger spécialisé pour les pipelines."""
    
    def __init__(self, pipeline_name):
        self.logger = get_logger(pipeline_name)
        self.pipeline_name = pipeline_name
    
    def start_pipeline(self):
        self.logger.info(f"Début du pipeline: {self.pipeline_name}")
    
    def end_pipeline(self, success=True):
        status = "SUCCÈS" if success else "ÉCHEC"
        self.logger.info(f"Fin du pipeline: {self.pipeline_name} - {status}")
    
    def log_component(self, component_name, message=""):
        self.logger.info(f"Composant {component_name}: {message}")
    
    def log_metric(self, metric_name, value):
        self.logger.info(f"Métrique {metric_name}: {value}")
    
    def log_error(self, error_message, exception=None):
        self.logger.error(f"Erreur: {error_message}")
        if exception:
            self.logger.exception(exception)