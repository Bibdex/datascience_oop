"""
Classes pour le nettoyage des données.
"""

import pandas as pd
import numpy as np
from typing import Optional, Dict, Any, List
from abc import ABC, abstractmethod
from ..core.base import PipelineComponent
from ..core.decorators import timing_decorator, log_execution
from ..core.exceptions import DataValidationError

class DataCleaner(PipelineComponent, ABC):
    """Classe abstraite pour le nettoyage des données."""
    
    @abstractmethod
    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        """Nettoie le DataFrame."""
        pass
    
    def process(self, data: Any) -> Any:
        """Interface pour PipelineComponent."""
        if isinstance(data, pd.DataFrame):
            return self.clean(data)
        return data

class BasicDataCleaner(DataCleaner):
    """Nettoyeur de données de base."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'remove_duplicates': True,
            'handle_missing': True,
            'missing_strategy': 'auto',  # 'auto', 'median', 'mean', 'constant', 'drop'
            'missing_constant': 0,
            'remove_outliers': False,
            'outlier_method': 'iqr',  # 'iqr', 'zscore'
            'iqr_factor': 1.5,
            'zscore_threshold': 3,
            'encode_categorical': False,
            'categorical_strategy': 'onehot',  # 'onehot', 'label', 'ordinal'
            'verbose': True
        }
        self.config = {**self.default_config, **(config or {})}
    
    @timing_decorator
    @log_execution
    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        """Nettoie le DataFrame avec les configurations spécifiées."""
        df_clean = df.copy()
        
        # 1. Supprimer les doublons
        if self.config['remove_duplicates']:
            df_clean = self._remove_duplicates(df_clean)
        
        # 2. Gérer les valeurs manquantes
        if self.config['handle_missing']:
            df_clean = self._handle_missing_values(df_clean)
        
        # 3. Supprimer les outliers
        if self.config['remove_outliers']:
            if self.config['outlier_method'] == 'iqr':
                df_clean = self._remove_outliers_iqr(df_clean)
            elif self.config['outlier_method'] == 'zscore':
                df_clean = self._remove_outliers_zscore(df_clean)
        
        # 4. Encoder les variables catégorielles
        if self.config['encode_categorical']:
            df_clean = self._encode_categorical(df_clean)
        
        if self.config['verbose']:
            print(f"Données nettoyées: {df_clean.shape[0]} lignes, {df_clean.shape[1]} colonnes")
        
        return df_clean
    
    def _remove_duplicates(self, df: pd.DataFrame) -> pd.DataFrame:
        """Supprime les lignes en double."""
        n_duplicates = df.duplicated().sum()
        if n_duplicates > 0:
            df_clean = df.drop_duplicates()
            if self.config['verbose']:
                print(f"Suppression de {n_duplicates} doublons")
            return df_clean
        return df
    
    def _handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """Gère les valeurs manquantes."""
        missing_counts = df.isnull().sum()
        total_missing = missing_counts.sum()
        
        if total_missing == 0:
            return df
        
        if self.config['verbose']:
            print(f"Valeurs manquantes détectées: {total_missing}")
        
        strategy = self.config['missing_strategy']
        
        if strategy == 'drop':
            # Supprimer les lignes avec des valeurs manquantes
            df_clean = df.dropna()
            if self.config['verbose']:
                print(f"Suppression de {len(df) - len(df_clean)} lignes avec valeurs manquantes")
        
        elif strategy == 'auto':
            # Stratégie automatique basée sur le type de données
            for col in df.columns:
                if df[col].dtype in ['float64', 'int64']:
                    # Pour les colonnes numériques: remplacer par la médiane
                    df[col] = df[col].fillna(df[col].median())
                elif df[col].dtype == 'object':
                    # Pour les colonnes catégorielles: remplacer par le mode
                    if not df[col].mode().empty:
                        df[col] = df[col].fillna(df[col].mode()[0])
        
        elif strategy in ['median', 'mean']:
            # Pour les colonnes numériques seulement
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            for col in numeric_cols:
                if strategy == 'median':
                    df[col] = df[col].fillna(df[col].median())
                else:  # mean
                    df[col] = df[col].fillna(df[col].mean())
        
        elif strategy == 'constant':
            constant = self.config['missing_constant']
            df = df.fillna(constant)
        
        else:
            raise ValueError(f"Stratégie de valeurs manquantes non reconnue: {strategy}")
        
        return df
    
    def _remove_outliers_iqr(self, df: pd.DataFrame) -> pd.DataFrame:
        """Supprime les outliers en utilisant la méthode IQR."""
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        mask = pd.Series([True] * len(df), index=df.index)
        
        for col in numeric_cols:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - self.config['iqr_factor'] * IQR
            upper_bound = Q3 + self.config['iqr_factor'] * IQR
            
            col_mask = (df[col] >= lower_bound) & (df[col] <= upper_bound)
            mask = mask & col_mask
        
        n_outliers = (~mask).sum()
        if n_outliers > 0 and self.config['verbose']:
            print(f"Suppression de {n_outliers} outliers (méthode IQR)")
        
        return df[mask].reset_index(drop=True)
    
    def _remove_outliers_zscore(self, df: pd.DataFrame) -> pd.DataFrame:
        """Supprime les outliers en utilisant les Z-scores."""
        from scipy import stats
        
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        mask = pd.Series([True] * len(df), index=df.index)
        
        for col in numeric_cols:
            z_scores = np.abs(stats.zscore(df[col].fillna(df[col].mean())))
            col_mask = z_scores < self.config['zscore_threshold']
            mask = mask & col_mask
        
        n_outliers = (~mask).sum()
        if n_outliers > 0 and self.config['verbose']:
            print(f"Suppression de {n_outliers} outliers (méthode Z-score)")
        
        return df[mask].reset_index(drop=True)
    
    def _encode_categorical(self, df: pd.DataFrame) -> pd.DataFrame:
        """Encode les variables catégorielles."""
        categorical_cols = df.select_dtypes(include=['object']).columns
        
        if len(categorical_cols) == 0:
            return df
        
        strategy = self.config['categorical_strategy']
        
        if strategy == 'onehot':
            # One-hot encoding
            df_encoded = pd.get_dummies(df, columns=categorical_cols, drop_first=True)
        
        elif strategy == 'label':
            # Label encoding
            from sklearn.preprocessing import LabelEncoder
            df_encoded = df.copy()
            for col in categorical_cols:
                le = LabelEncoder()
                df_encoded[col] = le.fit_transform(df_encoded[col].fillna('Missing'))
        
        elif strategy == 'ordinal':
            # Ordinal encoding (basé sur la fréquence)
            df_encoded = df.copy()
            for col in categorical_cols:
                freq = df_encoded[col].value_counts()
                mapping = {val: idx for idx, (val, _) in enumerate(freq.items())}
                df_encoded[col] = df_encoded[col].map(mapping)
        
        else:
            raise ValueError(f"Stratégie d'encodage non reconnue: {strategy}")
        
        if self.config['verbose']:
            print(f"Encodage de {len(categorical_cols)} variables catégorielles")
        
        return df_encoded

class TitanicDataCleaner(BasicDataCleaner):
    """Nettoyeur spécialisé pour le dataset Titanic."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.titanic_config = {
            'age_strategy': 'median',  # 'median', 'mean', 'constant', 'predict'
            'age_constant': 29.0,
            'cabin_strategy': 'extract',  # 'drop', 'extract', 'keep'
            'embarked_strategy': 'mode',  # 'mode', 'drop', 'constant'
            'embarked_constant': 'S',
            'name_strategy': 'extract_title',  # 'keep', 'extract_title', 'drop'
            'ticket_strategy': 'keep',  # 'keep', 'drop', 'extract_prefix'
            'extract_family_features': True,
            'create_age_groups': True,
            'fare_bins': 4
        }
        self.config = {**self.titanic_config, **self.config}
    
    @timing_decorator
    @log_execution
    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        """Nettoie le dataset Titanic avec des traitements spécifiques."""
        df_clean = super().clean(df)
        
        # Traitements spécifiques Titanic
        df_clean = self._handle_age(df_clean)
        df_clean = self._handle_cabin(df_clean)
        df_clean = self._handle_embarked(df_clean)
        df_clean = self._handle_name(df_clean)
        df_clean = self._handle_ticket(df_clean)
        
        # Feature engineering
        if self.config['extract_family_features']:
            df_clean = self._extract_family_features(df_clean)
        
        if self.config['create_age_groups']:
            df_clean = self._create_age_groups(df_clean)
        
        # Encodage final
        df_clean = self._final_encoding(df_clean)
        
        return df_clean
    
    def _handle_age(self, df: pd.DataFrame) -> pd.DataFrame:
        """Gère les valeurs manquantes d'âge."""
        strategy = self.config['age_strategy']
        
        if strategy == 'median':
            df['Age'] = df['Age'].fillna(df['Age'].median())
        elif strategy == 'mean':
            df['Age'] = df['Age'].fillna(df['Age'].mean())
        elif strategy == 'constant':
            df['Age'] = df['Age'].fillna(self.config['age_constant'])
        elif strategy == 'predict':
            # Prédiction de l'âge basée sur d'autres features
            df = self._predict_missing_age(df)
        
        return df
    
    def _handle_cabin(self, df: pd.DataFrame) -> pd.DataFrame:
        """Gère la colonne Cabin."""
        strategy = self.config['cabin_strategy']
        
        if strategy == 'drop':
            df = df.drop('Cabin', axis=1)
        elif strategy == 'extract':
            # Extraire le pont (première lettre)
            df['Deck'] = df['Cabin'].str[0]
            df['Deck'] = df['Deck'].fillna('Unknown')
            
            # Extraire le numéro de cabine
            df['CabinNumber'] = df['Cabin'].str.extract('(\d+)')
            df['CabinNumber'] = pd.to_numeric(df['CabinNumber'], errors='coerce')
            
            df = df.drop('Cabin', axis=1)
        
        return df
    
    def _handle_embarked(self, df: pd.DataFrame) -> pd.DataFrame:
        """Gère les valeurs manquantes d'embarquement."""
        strategy = self.config['embarked_strategy']
        
        if strategy == 'mode':
            df['Embarked'] = df['Embarked'].fillna(df['Embarked'].mode()[0])
        elif strategy == 'constant':
            df['Embarked'] = df['Embarked'].fillna(self.config['embarked_constant'])
        elif strategy == 'drop':
            df = df.dropna(subset=['Embarked'])
        
        return df
    
    def _handle_name(self, df: pd.DataFrame) -> pd.DataFrame:
        """Extrait des informations du nom."""
        strategy = self.config['name_strategy']
        
        if strategy == 'extract_title':
            # Extraire le titre
            df['Title'] = df['Name'].str.extract(' ([A-Za-z]+)\.', expand=False)
            
            # Regrouper les titres rares
            title_counts = df['Title'].value_counts()
            rare_titles = title_counts[title_counts < 10].index
            df['Title'] = df['Title'].replace(rare_titles, 'Rare')
            
            # Standardiser les titres
            title_mapping = {
                'Mlle': 'Miss', 'Ms': 'Miss', 'Mme': 'Mrs',
                'Capt': 'Officer', 'Col': 'Officer', 'Major': 'Officer',
                'Dr': 'Officer', 'Rev': 'Officer', 'Jonkheer': 'Royalty',
                'Don': 'Royalty', 'Sir': 'Royalty', 'Lady': 'Royalty',
                'Countess': 'Royalty', 'Dona': 'Royalty'
            }
            df['Title'] = df['Title'].replace(title_mapping)
        
        return df
    
    def _handle_ticket(self, df: pd.DataFrame) -> pd.DataFrame:
        """Gère la colonne Ticket."""
        strategy = self.config['ticket_strategy']
        
        if strategy == 'drop':
            df = df.drop('Ticket', axis=1)
        elif strategy == 'extract_prefix':
            # Extraire le préfixe du ticket
            df['TicketPrefix'] = df['Ticket'].str.extract('([A-Za-z\.\/]+)')
            df['TicketPrefix'] = df['TicketPrefix'].fillna('None')
            df = df.drop('Ticket', axis=1)
        
        return df
    
    def _extract_family_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Extrait des features familiales."""
        # Taille de la famille
        df['FamilySize'] = df['SibSp'] + df['Parch'] + 1
        
        # Est seul
        df['IsAlone'] = (df['FamilySize'] == 1).astype(int)
        
        # Catégories de taille familiale
        df['FamilyType'] = pd.cut(
            df['FamilySize'],
            bins=[0, 1, 4, 11],
            labels=['Alone', 'Small', 'Large']
        )
        
        return df
    
    def _create_age_groups(self, df: pd.DataFrame) -> pd.DataFrame:
        """Crée des groupes d'âge."""
        df['AgeGroup'] = pd.cut(
            df['Age'],
            bins=[0, 12, 18, 35, 60, 100],
            labels=['Child', 'Teen', 'YoungAdult', 'Adult', 'Senior']
        )
        
        # Variable binaire pour enfant
        df['IsChild'] = (df['Age'] < 16).astype(int)
        
        return df
    
    def _predict_missing_age(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prédit les âges manquants à l'aide de régression."""
        from sklearn.ensemble import RandomForestRegressor
        
        # Séparer les données avec et sans âge
        age_data = df[df['Age'].notnull()]
        missing_age = df[df['Age'].isnull()]
        
        if len(missing_age) == 0 or len(age_data) == 0:
            return df
        
        # Features pour la prédiction
        features = ['Pclass', 'SibSp', 'Parch', 'Fare', 'Sex', 'Embarked']
        
        # Préparer les données
        X_train = pd.get_dummies(age_data[features], drop_first=True)
        y_train = age_data['Age']
        
        X_test = pd.get_dummies(missing_age[features], drop_first=True)
        
        # Aligner les colonnes
        X_test = X_test.reindex(columns=X_train.columns, fill_value=0)
        
        # Entraîner le modèle
        model = RandomForestRegressor(n_estimators=100, random_state=42)
        model.fit(X_train, y_train)
        
        # Prédire
        predicted_ages = model.predict(X_test)
        
        # Remplir les valeurs manquantes
        df.loc[df['Age'].isnull(), 'Age'] = predicted_ages
        
        return df
    
    def _final_encoding(self, df: pd.DataFrame) -> pd.DataFrame:
        """Encodage final des variables catégorielles."""
        # Encoder le sexe
        df['Sex'] = df['Sex'].map({'male': 0, 'female': 1})
        
        # One-hot encoding pour les autres variables catégorielles
        categorical_cols = ['Embarked', 'Title', 'Deck', 'FamilyType', 'AgeGroup']
        categorical_cols = [col for col in categorical_cols if col in df.columns]
        
        if categorical_cols:
            df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)
        
        return df