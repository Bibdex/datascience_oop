"""
Classes pour le chargement des données.
"""

import pandas as pd
import numpy as np
from typing import Union, Optional, Dict, Any
from abc import ABC, abstractmethod
import json
import sqlite3
from ..core.base import PipelineComponent
from ..core.decorators import timing_decorator, log_execution

class DataLoader(PipelineComponent, ABC):
    """Classe abstraite pour le chargement des données."""
    
    @abstractmethod
    def load(self, source: str) -> pd.DataFrame:
        """Charge les données depuis une source."""
        pass
    
    def process(self, data: Any) -> Any:
        """Interface pour PipelineComponent."""
        if isinstance(data, str):
            return self.load(data)
        return data

class CSVLoader(DataLoader):
    """Chargeur de fichiers CSV."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'sep': ',',
            'encoding': 'utf-8',
            'parse_dates': True,
            'infer_datetime_format': True,
            'low_memory': False
        }
        self.config = {**self.default_config, **(config or {})}
    
    @timing_decorator
    @log_execution
    def load(self, filepath: str) -> pd.DataFrame:
        """Charge un fichier CSV."""
        try:
            df = pd.read_csv(filepath, **self.config)
            self.metadata['filepath'] = filepath
            self.metadata['shape'] = df.shape
            self.metadata['columns'] = list(df.columns)
            return df
        except Exception as e:
            raise FileNotFoundError(f"Impossible de charger le fichier CSV {filepath}: {e}")

class JSONLoader(DataLoader):
    """Chargeur de fichiers JSON."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'orient': 'records',
            'encoding': 'utf-8'
        }
        self.config = {**self.default_config, **(config or {})}
    
    @timing_decorator
    @log_execution
    def load(self, filepath: str) -> pd.DataFrame:
        """Charge un fichier JSON."""
        try:
            # Essayer de charger directement en DataFrame
            try:
                df = pd.read_json(filepath, **self.config)
            except:
                # Si ça échoue, charger en tant que JSON et convertir
                with open(filepath, 'r', encoding=self.config['encoding']) as f:
                    data = json.load(f)
                df = pd.DataFrame(data)
            
            self.metadata['filepath'] = filepath
            self.metadata['shape'] = df.shape
            return df
        except Exception as e:
            raise FileNotFoundError(f"Impossible de charger le fichier JSON {filepath}: {e}")

class DatabaseLoader(DataLoader):
    """Chargeur de bases de données."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'database': ':memory:',
            'table': None,
            'query': None
        }
        self.config = {**self.default_config, **(config or {})}
    
    @timing_decorator
    @log_execution
    def load(self, source: str) -> pd.DataFrame:
        """Charge des données depuis une base de données."""
        database = self.config.get('database', source)
        table = self.config.get('table')
        query = self.config.get('query')
        
        if not table and not query:
            raise ValueError("Soit 'table' soit 'query' doit être spécifié")
        
        try:
            conn = sqlite3.connect(database)
            
            if query:
                df = pd.read_sql_query(query, conn)
            else:
                df = pd.read_sql_query(f"SELECT * FROM {table}", conn)
            
            conn.close()
            
            self.metadata['database'] = database
            self.metadata['shape'] = df.shape
            return df
        except Exception as e:
            raise ConnectionError(f"Impossible de charger depuis la base de données {database}: {e}")

class DataSplitter(PipelineComponent):
    """Composant pour diviser les données en train/test."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'target_column': None,
            'test_size': 0.2,
            'random_state': 42,
            'stratify': True,
            'shuffle': True
        }
        self.config = {**self.default_config, **(config or {})}
    
    @timing_decorator
    @log_execution
    def process(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Divise les données en ensembles d'entraînement et de test."""
        from sklearn.model_selection import train_test_split
        
        target_column = self.config['target_column']
        
        if target_column is None:
            raise ValueError("target_column doit être spécifié")
        
        if target_column not in data.columns:
            raise ValueError(f"La colonne cible '{target_column}' n'existe pas dans les données")
        
        # Séparer features et target
        X = data.drop(columns=[target_column])
        y = data[target_column]
        
        # Configurer les paramètres de train_test_split
        split_kwargs = {
            'test_size': self.config['test_size'],
            'random_state': self.config['random_state'],
            'shuffle': self.config['shuffle']
        }
        
        if self.config['stratify'] and y.nunique() > 1:
            split_kwargs['stratify'] = y
        
        # Diviser les données
        X_train, X_test, y_train, y_test = train_test_split(X, y, **split_kwargs)
        
        result = {
            'X_train': X_train,
            'X_test': X_test,
            'y_train': y_train,
            'y_test': y_test,
            'feature_names': list(X.columns),
            'target_name': target_column
        }
        
        self.metadata['train_size'] = len(X_train)
        self.metadata['test_size'] = len(X_test)
        self.metadata['n_features'] = X.shape[1]
        
        return result