"""
Générateur de datasets pour les exercices.
"""

import pandas as pd
import numpy as np
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import seaborn as sns

class DatasetGenerator:
    """Générateur de datasets pour les exercices OOP."""
    
    def __init__(self, seed: int = 42):
        self.seed = seed
        np.random.seed(seed)
    
    @staticmethod
    def generate_titanic(n_samples: int = 891) -> pd.DataFrame:
        """Génère un dataset Titanic synthétique."""
        print("Génération du dataset Titanic...")
        
        # Données de base
        passenger_ids = range(1, n_samples + 1)
        pclass = np.random.choice([1, 2, 3], n_samples, p=[0.24, 0.21, 0.55])
        
        # Noms
        first_names = ['John', 'Mary', 'James', 'Elizabeth', 'Robert', 'Jennifer', 
                      'Michael', 'Linda', 'William', 'Patricia']
        last_names = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 
                     'Davis', 'Garcia', 'Rodriguez', 'Wilson']
        
        names = []
        for i in range(n_samples):
            first = np.random.choice(first_names)
            last = np.random.choice(last_names)
            title = np.random.choice(['Mr.', 'Mrs.', 'Miss.', 'Master.', 'Dr.'], 
                                    p=[0.5, 0.25, 0.15, 0.05, 0.05])
            names.append(f"{title} {first} {last}")
        
        # Sexe
        sex = np.random.choice(['male', 'female'], n_samples, p=[0.65, 0.35])
        
        # Âge (distribution normale avec quelques outliers)
        age = np.random.normal(29, 14, n_samples)
        age = np.clip(age, 0.42, 80).round(1)
        
        # SibSp et Parch (distributions de Poisson)
        sibsp = np.random.poisson(0.5, n_samples)
        sibsp = np.clip(sibsp, 0, 8)
        
        parch = np.random.poisson(0.4, n_samples)
        parch = np.clip(parch, 0, 6)
        
        # Ticket
        ticket_prefixes = ['A/', 'PC ', 'STON/', 'SOTON/', 'C.A.']
        tickets = []
        for _ in range(n_samples):
            if np.random.random() > 0.7:
                prefix = np.random.choice(ticket_prefixes)
                number = np.random.randint(1000, 999999)
                tickets.append(f"{prefix}{number}")
            else:
                tickets.append(str(np.random.randint(100000, 999999)))
        
        # Fare (distribution exponentielle)
        fare = np.random.exponential(32, n_samples)
        fare = np.clip(fare, 0, 512).round(2)
        
        # Cabin
        decks = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
        cabins = []
        for _ in range(n_samples):
            if np.random.random() > 0.77:
                deck = np.random.choice(decks)
                number = np.random.randint(1, 101)
                cabins.append(f"{deck}{number}")
            else:
                cabins.append(np.nan)
        
        # Embarked
        embarked = np.random.choice(['C', 'Q', 'S', np.nan], n_samples, 
                                   p=[0.19, 0.09, 0.72, 0.0])
        
        # Créer le DataFrame
        data = {
            'PassengerId': passenger_ids,
            'Survived': np.zeros(n_samples, dtype=int),
            'Pclass': pclass,
            'Name': names,
            'Sex': sex,
            'Age': age,
            'SibSp': sibsp,
            'Parch': parch,
            'Ticket': tickets,
            'Fare': fare,
            'Cabin': cabins,
            'Embarked': embarked
        }
        
        df = pd.DataFrame(data)
        
        # Ajouter des patterns réalistes pour la survie
        
        # 1. Les femmes et enfants survivent plus
        female_child_mask = (df['Sex'] == 'female') | (df['Age'] < 16)
        df.loc[female_child_mask, 'Survived'] = np.random.choice(
            [0, 1], sum(female_child_mask), p=[0.3, 0.7]
        )
        
        # 2. La première classe survit plus
        first_class_mask = df['Pclass'] == 1
        df.loc[first_class_mask, 'Survived'] = np.random.choice(
            [0, 1], sum(first_class_mask), p=[0.4, 0.6]
        )
        
        # 3. Les passagers chers survivent plus
        high_fare_mask = df['Fare'] > df['Fare'].median() * 2
        df.loc[high_fare_mask, 'Survived'] = np.random.choice(
            [0, 1], sum(high_fare_mask), p=[0.4, 0.6]
        )
        
        # 4. Pour les autres, taux de survie plus bas
        other_mask = ~(female_child_mask | first_class_mask | high_fare_mask)
        df.loc[other_mask, 'Survived'] = np.random.choice(
            [0, 1], sum(other_mask), p=[0.7, 0.3]
        )
        
        # Ajouter des valeurs manquantes
        n_missing_age = int(n_samples * 0.2)
        missing_age_indices = np.random.choice(df.index, n_missing_age, replace=False)
        df.loc[missing_age_indices, 'Age'] = np.nan
        
        n_missing_cabin = int(n_samples * 0.78)
        missing_cabin_indices = np.random.choice(df.index, n_missing_cabin, replace=False)
        df.loc[missing_cabin_indices, 'Cabin'] = np.nan
        
        n_missing_embarked = int(n_samples * 0.002)
        missing_embarked_indices = np.random.choice(df.index, n_missing_embarked, replace=False)
        df.loc[missing_embarked_indices, 'Embarked'] = np.nan
        
        print(f"Dataset Titanic généré: {df.shape[0]} lignes, {df.shape[1]} colonnes")
        print(f"Taux de survie: {df['Survived'].mean():.1%}")
        
        return df
    
    @staticmethod
    def generate_customer_churn(n_samples: int = 1000) -> pd.DataFrame:
        """Génère un dataset de churn client."""
        print("Génération du dataset Customer Churn...")
        
        # IDs clients
        customer_ids = [f'CUST{str(i).zfill(5)}' for i in range(n_samples)]
        
        # Features démographiques
        geography = np.random.choice(['France', 'Germany', 'Spain'], 
                                    n_samples, p=[0.5, 0.25, 0.25])
        gender = np.random.choice(['Male', 'Female'], n_samples, p=[0.55, 0.45])
        age = np.random.normal(38, 10, n_samples)
        age = np.clip(age, 18, 70).astype(int)
        
        # Features financières
        credit_score = np.random.normal(650, 100, n_samples)
        credit_score = np.clip(credit_score, 300, 850).astype(int)
        
        tenure = np.random.choice(range(0, 11), n_samples, 
                                 p=[0.05, 0.1, 0.15, 0.2, 0.15, 
                                    0.1, 0.08, 0.07, 0.05, 0.03, 0.02])
        
        balance = np.random.exponential(75000, n_samples)
        balance = np.clip(balance, 0, 250000).round(2)
        
        num_products = np.random.choice([1, 2, 3, 4], n_samples, 
                                       p=[0.5, 0.35, 0.1, 0.05])
        
        has_credit_card = np.random.choice([0, 1], n_samples, p=[0.3, 0.7])
        is_active_member = np.random.choice([0, 1], n_samples, p=[0.5, 0.5])
        
        estimated_salary = np.random.uniform(15000, 150000, n_samples).round(2)
        
        # Créer le DataFrame
        data = {
            'CustomerID': customer_ids,
            'CreditScore': credit_score,
            'Geography': geography,
            'Gender': gender,
            'Age': age,
            'Tenure': tenure,
            'Balance': balance,
            'NumOfProducts': num_products,
            'HasCrCard': has_credit_card,
            'IsActiveMember': is_active_member,
            'EstimatedSalary': estimated_salary,
            'Churn': np.zeros(n_samples, dtype=int)
        }
        
        df = pd.DataFrame(data)
        
        # Calculer la probabilité de churn
        churn_prob = (
            0.3 * (df['Balance'] < 10000) +
            0.25 * (df['NumOfProducts'] == 1) +
            0.2 * (df['IsActiveMember'] == 0) +
            0.15 * (df['CreditScore'] < 600) +
            0.1 * (df['Tenure'] < 2) +
            0.05 * (df['Geography'] == 'Germany') +
            np.random.normal(0, 0.1, n_samples)
        )
        
        # Normaliser entre 0 et 1
        churn_prob = (churn_prob - churn_prob.min()) / (churn_prob.max() - churn_prob.min())
        churn_prob = np.clip(churn_prob, 0, 1)
        
        # Générer les labels de churn
        df['Churn'] = (churn_prob > 0.5).astype(int)
        
        # Ajuster le taux de churn pour qu'il soit réaliste (~20%)
        current_rate = df['Churn'].mean()
        if current_rate < 0.15:
            threshold = np.percentile(churn_prob, 80)
            df['Churn'] = (churn_prob > threshold).astype(int)
        elif current_rate > 0.25:
            threshold = np.percentile(churn_prob, 70)
            df['Churn'] = (churn_prob > threshold).astype(int)
        
        print(f"Dataset Customer Churn généré: {df.shape[0]} lignes, {df.shape[1]} colonnes")
        print(f"Taux de churn: {df['Churn'].mean():.1%}")
        
        return df
    
    @staticmethod
    def generate_time_series(n_days: int = 365 * 3) -> pd.DataFrame:
        """Génère des données de séries temporelles de ventes."""
        print("Génération des données de séries temporelles...")
        
        # Générer des dates
        dates = pd.date_range(start='2020-01-01', periods=n_days, freq='D')
        t = np.arange(n_days)
        
        # Composante de tendance (croissance lente)
        trend = 100 + 0.12 * t
        
        # Saisonnalité
        yearly_seasonality = 40 * np.sin(2 * np.pi * t / 365)
        quarterly_seasonality = 15 * np.sin(2 * np.pi * t / 91.25)
        weekly_seasonality = 10 * np.sin(2 * np.pi * t / 7)
        
        # Événements spéciaux
        events = np.zeros(n_days)
        
        for year in [0, 365, 730]:
            # Black Friday (dernier vendredi de novembre)
            bf_day = year + 300 + (4 - dates[year + 300].weekday()) % 7
            if bf_day < n_days:
                events[bf_day:bf_day+7] += np.random.uniform(50, 80, 7)
            
            # Saison de Noël
            xmas_start = year + 354  # 20 décembre
            if xmas_start < n_days:
                events[xmas_start:xmas_start+10] += np.random.uniform(40, 60, 10)
            
            # Soldes d'été (juillet)
            summer_start = year + 180
            if summer_start < n_days:
                events[summer_start:summer_start+14] += np.random.uniform(30, 50, 14)
        
        # Promotions aléatoires
        promo_days = np.random.choice(n_days, size=30, replace=False)
        promotions = np.zeros(n_days)
        for day in promo_days:
            duration = np.random.randint(3, 7)
            if day + duration < n_days:
                promotions[day:day+duration] += np.random.uniform(20, 40, duration)
        
        # Bruit
        noise = np.random.normal(0, 8, n_days)
        
        # Combiner tous les composants
        sales = (trend + yearly_seasonality + quarterly_seasonality + 
                weekly_seasonality + events + promotions + noise)
        sales = np.maximum(sales, 20)  # Ventes minimum
        
        # Créer des features supplémentaires
        temperature = np.random.uniform(-5, 35, n_days).round(1)
        is_weekend = (dates.weekday >= 5).astype(int)
        
        # Jours fériés
        is_holiday = (
            ((dates.month == 12) & (dates.day.isin([24, 25, 31]))) |
            ((dates.month == 1) & (dates.day == 1))
        ).astype(int)
        
        promotion_active = (promotions > 0).astype(int)
        
        # Store ID
        store_ids = ['Store_A', 'Store_B', 'Store_C', 'Store_D']
        store_id = np.random.choice(store_ids, n_days)
        
        # Catégorie de produit
        categories = ['Electronics', 'Clothing', 'Home', 'Books', 'Sports']
        category_weights = [0.3, 0.25, 0.2, 0.15, 0.1]
        product_category = np.random.choice(categories, n_days, p=category_weights)
        
        # Créer le DataFrame
        df = pd.DataFrame({
            'date': dates,
            'sales': sales.round(2),
            'temperature': temperature,
            'is_weekend': is_weekend,
            'is_holiday': is_holiday,
            'promotion_active': promotion_active,
            'store_id': store_id,
            'product_category': product_category
        })
        
        # Ajouter des valeurs manquantes pour les exercices
        missing_indices = np.random.choice(df.index, size=int(n_days * 0.05), replace=False)
        df.loc[missing_indices, 'temperature'] = np.nan
        
        print(f"Données de séries temporelles générées: {df.shape[0]} lignes, {df.shape[1]} colonnes")
        print(f"Période: {df['date'].min().date()} à {df['date'].max().date()}")
        print(f"Ventes moyennes: ${df['sales'].mean():.2f}")
        
        return df
    
    @staticmethod
    def generate_text_samples(n_samples: int = 100) -> List[Dict]:
        """Génère des échantillons de texte pour la classification."""
        print("Génération des échantillons de texte...")
        
        # Modèles de reviews
        templates = {
            'positive': [
                "Absolutely love this {product}! It exceeded all my expectations.",
                "High quality {product} and great value for money. Will definitely buy again.",
                "Excellent {product} and fast delivery. Very satisfied with my purchase.",
                "Works perfectly, exactly as described. Highly recommended!",
                "Best {product} I've bought this year. The quality is outstanding.",
                "Very happy with this {product}. It has made my life so much easier.",
                "Great customer service and excellent {product} quality.",
                "Perfect fit and great design. I get compliments every time I use it.",
                "This {product} works flawlessly. Setup was easy and intuitive.",
                "Superb quality and attention to detail. Worth every penny."
            ],
            'negative': [
                "Terrible {product}. Stopped working after just one week.",
                "Poor quality {product} and not worth the price. Very disappointed.",
                "Arrived damaged and customer service was unhelpful.",
                "{product} does not work as advertised. Complete waste of money.",
                "Low quality materials, feels cheap and broke easily.",
                "Shipping took forever and the {product} was defective.",
                "Would not recommend this {product}. Failed to meet basic expectations.",
                "Very frustrating experience. The {product} doesn't function properly.",
                "Poor craftsmanship and terrible customer support for this {product}.",
                "Overpriced for the quality received. Regret this {product} purchase."
            ],
            'neutral': [
                "Average {product}. It works but nothing special.",
                "Does the job but could be better designed.",
                "Okay for the price, but there are better {product} options available.",
                "It works as expected, no major complaints.",
                "Standard quality {product}, nothing exceptional but gets the job done.",
                "The {product} is fine, but the shipping was slower than expected.",
                "Mediocre performance, average build quality for a {product}.",
                "It serves its purpose but doesn't excel in any area.",
                "Fair {product} for the price point.",
                "Basic functionality, meets minimum requirements for a {product}."
            ]
        }
        
        # Catégories de produits
        products = {
            'Electronics': ['laptop', 'smartphone', 'headphones', 'tablet', 'smartwatch'],
            'Clothing': ['shirt', 'dress', 'jeans', 'jacket', 'shoes'],
            'Home': ['blender', 'vacuum', 'lamp', 'chair', 'cookware'],
            'Books': ['novel', 'textbook', 'cookbook', 'biography', 'self-help book']
        }
        
        samples = []
        
        for i in range(n_samples):
            # Choisir un sentiment
            sentiment = np.random.choice(['positive', 'negative', 'neutral'], 
                                        p=[0.5, 0.3, 0.2])
            
            # Choisir une catégorie et un produit
            category = np.random.choice(list(products.keys()))
            product = np.random.choice(products[category])
            
            # Générer le texte
            template = np.random.choice(templates[sentiment])
            text = template.format(product=product)
            
            # Déterminer la note basée sur le sentiment
            if sentiment == 'positive':
                rating = np.random.choice([4, 5], p=[0.3, 0.7])
            elif sentiment == 'negative':
                rating = np.random.choice([1, 2], p=[0.6, 0.4])
            else:
                rating = 3
            
            # Ajouter de la variété
            if np.random.random() > 0.7:
                if sentiment == 'positive':
                    additions = [
                        "The packaging was also very nice.",
                        "Arrived earlier than expected!",
                        "Customer service was very helpful.",
                        "Will be buying more from this brand."
                    ]
                    text += " " + np.random.choice(additions)
                elif sentiment == 'negative':
                    additions = [
                        "Waste of time and money.",
                        "I've requested a refund.",
                        "Never buying from this company again.",
                        "Complete disappointment."
                    ]
                    text += " " + np.random.choice(additions)
            
            # Créer l'échantillon
            sample = {
                'review_id': f'REV{str(i).zfill(5)}',
                'text': text,
                'label': sentiment,
                'rating': rating,
                'category': category,
                'product': product,
                'verified_purchase': np.random.choice([True, False], p=[0.8, 0.2]),
                'helpful_votes': np.random.poisson(3),
                'total_votes': np.random.poisson(5)
            }
            
            samples.append(sample)
        
        # Sauvegarder en JSON
        with open('text_classification_samples.json', 'w') as f:
            json.dump(samples, f, indent=2)
        
        # Sauvegarder en CSV
        df = pd.DataFrame(samples)
        df.to_csv('text_classification_samples.csv', index=False)
        
        print(f"Échantillons de texte générés: {len(samples)} reviews")
        
        # Afficher la distribution
        label_counts = df['label'].value_counts()
        for label, count in label_counts.items():
            print(f"  {label}: {count} ({count/len(samples):.1%})")
        
        return samples
    
    def generate_all(self, output_dir: str = '.') -> Dict[str, pd.DataFrame]:
        """Génère tous les datasets."""
        print("=" * 60)
        print("Génération de tous les datasets pour les exercices OOP")
        print("=" * 60)
        
        datasets = {}
        
        try:
            # Titanic
            datasets['titanic'] = self.generate_titanic()
            datasets['titanic'].to_csv(f'{output_dir}/titanic.csv', index=False)
            print()
            
            # Customer Churn
            datasets['customer_churn'] = self.generate_customer_churn()
            datasets['customer_churn'].to_csv(f'{output_dir}/customer_churn.csv', index=False)
            print()
            
            # Time Series
            datasets['time_series'] = self.generate_time_series()
            datasets['time_series'].to_csv(f'{output_dir}/time_series_sales.csv', index=False)
            print()
            
            # Text Samples
            text_samples = self.generate_text_samples()
            datasets['text'] = pd.DataFrame(text_samples)
            print()
            
            # Créer un fichier de résumé
            summary = {
                "generated_at": datetime.now().isoformat(),
                "datasets": {
                    "titanic": {
                        "rows": datasets['titanic'].shape[0],
                        "columns": datasets['titanic'].shape[1],
                        "file": "titanic.csv",
                        "description": "Données passagers Titanic pour exercices de classification"
                    },
                    "customer_churn": {
                        "rows": datasets['customer_churn'].shape[0],
                        "columns": datasets['customer_churn'].shape[1],
                        "file": "customer_churn.csv",
                        "churn_rate": float(datasets['customer_churn']['Churn'].mean()),
                        "description": "Données clients pour exercices de prédiction de churn"
                    },
                    "time_series_sales": {
                        "rows": datasets['time_series'].shape[0],
                        "columns": datasets['time_series'].shape[1],
                        "file": "time_series_sales.csv",
                        "date_range": {
                            "start": datasets['time_series']['date'].min().isoformat(),
                            "end": datasets['time_series']['date'].max().isoformat()
                        },
                        "description": "Données de ventes quotidiennes pour analyse de séries temporelles"
                    },
                    "text_classification": {
                        "samples": len(datasets['text']),
                        "files": [
                            "text_classification_samples.json",
                            "text_classification_samples.csv"
                        ],
                        "description": "Reviews de produits pour exercices de classification de texte"
                    }
                },
                "usage_notes": [
                    "Utiliser titanic.csv pour les exercices OOP de base et de nettoyage",
                    "Utiliser customer_churn.csv pour les pipelines ML et l'ingénierie des features",
                    "Utiliser time_series_sales.csv pour l'analyse de séries temporelles",
                    "Utiliser text_classification_samples.json pour le traitement de texte"
                ]
            }
            
            with open(f'{output_dir}/dataset_summary.json', 'w') as f:
                json.dump(summary, f, indent=2)
            
            print("\n" + "=" * 60)
            print("Tous les datasets ont été générés avec succès!")
            print("=" * 60)
            print("\nFichiers créés:")
            print("  titanic.csv")
            print("  customer_churn.csv")
            print("  time_series_sales.csv")
            print("  text_classification_samples.json")
            print("  text_classification_samples.csv")
            print("  dataset_summary.json")
            
        except Exception as e:
            print(f"\nErreur lors de la génération des datasets: {e}")
            print("Veuillez vérifier votre environnement Python et les dépendances.")
            return None
        
        return datasets