import pandas as pd
import numpy as np
from abc import ABC, abstractmethod

class DataCleaner(ABC):
    """Classe abstraite pour le nettoyage de données."""
    
    def __init__(self, config=None):
        self.config = config or {}
    
    @abstractmethod
    def clean(self, df):
        pass
    
    def load(self, filepath):
        return pd.read_csv(filepath)
    
    def save(self, df, output_path):
        df.to_csv(output_path, index=False)
        