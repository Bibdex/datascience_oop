"""
Classes pour la validation des données.
"""

import pandas as pd
import numpy as np
import re
from typing import Optional, Dict, Any, List, Tuple, Union
from abc import ABC, abstractmethod
import json
from ..core.base import ValidationRule
from ..core.decorators import timing_decorator, log_execution
from ..core.exceptions import DataValidationError, ValidationRuleError

class DataValidator:
    """Validateur qui exécute un ensemble de règles."""
    
    def __init__(self, rules: Optional[List[ValidationRule]] = None):
        self.rules = rules or []
        self.results = []
        self.summary = {}
    
    def add_rule(self, rule: ValidationRule):
        """Ajoute une règle de validation."""
        self.rules.append(rule)
    
    def add_rules(self, rules: List[ValidationRule]):
        """Ajoute plusieurs règles de validation."""
        self.rules.extend(rules)
    
    @timing_decorator
    @log_execution
    def validate(self, df: pd.DataFrame, fail_fast: bool = False) -> Dict[str, Any]:
        """Exécute toutes les règles et retourne un rapport."""
        self.results = []
        errors = []
        warnings = []
        
        for rule in self.rules:
            try:
                success, message = rule.validate(df)
                result = {
                    'rule': rule.get_name(),
                    'column': rule.column,
                    'success': success,
                    'message': message,
                    'severity': rule.severity,
                    'description': rule.description
                }
                self.results.append(result)
                
                if not success:
                    if rule.severity == 'error':
                        errors.append(result)
                        if fail_fast:
                            raise DataValidationError(f"Échec de validation: {message}")
                    elif rule.severity == 'warning':
                        warnings.append(result)
                
            except Exception as e:
                error_result = {
                    'rule': rule.get_name(),
                    'column': rule.column,
                    'success': False,
                    'message': f"Erreur lors de la validation: {str(e)}",
                    'severity': 'error',
                    'description': rule.description
                }
                self.results.append(error_result)
                errors.append(error_result)
                
                if fail_fast:
                    raise ValidationRuleError(f"Erreur dans la règle {rule.get_name()}: {e}")
        
        return self.generate_report()
    
    def generate_report(self) -> Dict[str, Any]:
        """Génère un rapport détaillé de validation."""
        if not self.results:
            return {'status': 'no_rules', 'score': 1.0}
        
        total = len(self.results)
        passed = sum(1 for r in self.results if r['success'])
        failed = total - passed
        
        errors = [r for r in self.results if not r['success'] and r['severity'] == 'error']
        warnings = [r for r in self.results if not r['success'] and r['severity'] == 'warning']
        infos = [r for r in self.results if not r['success'] and r['severity'] == 'info']
        
        score = passed / total if total > 0 else 1.0
        
        self.summary = {
            'status': 'passed' if len(errors) == 0 else 'failed',
            'score': score,
            'total_rules': total,
            'passed': passed,
            'failed': failed,
            'errors': len(errors),
            'warnings': len(warnings),
            'infos': len(infos),
            'details': self.results,
            'error_details': errors,
            'warning_details': warnings,
            'info_details': infos
        }
        
        return self.summary
    
    def save_report(self, filepath: str, format: str = 'json'):
        """Sauvegarde le rapport dans un fichier."""
        report = self.generate_report()
        
        if format == 'json':
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
        
        elif format == 'html':
            self._generate_html_report(report, filepath)
        
        elif format == 'markdown':
            self._generate_markdown_report(report, filepath)
        
        elif format == 'csv':
            # Extraire les détails dans un DataFrame
            df_details = pd.DataFrame(report['details'])
            df_details.to_csv(filepath, index=False)
        
        else:
            raise ValueError(f"Format non supporté: {format}")
    
    def _generate_html_report(self, report: Dict[str, Any], filepath: str):
        """Génère un rapport HTML."""
        status_color = 'green' if report['status'] == 'passed' else 'red'
        status_icon = '✅' if report['status'] == 'passed' else '❌'
        
        html = f"""
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Rapport de Validation des Données</title>
            <style>
                body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                        margin: 40px; background-color: #f5f5f5; color: #333; }}
                .container {{ max-width: 1200px; margin: 0 auto; background: white; 
                            padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
                h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }}
                .summary {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                          color: white; padding: 25px; border-radius: 8px; margin-bottom: 30px; }}
                .summary h2 {{ margin-top: 0; color: white; }}
                .stats {{ display: flex; justify-content: space-between; flex-wrap: wrap; }}
                .stat-box {{ background: rgba(255,255,255,0.2); padding: 15px; border-radius: 5px; 
                           text-align: center; flex: 1; margin: 10px; min-width: 150px; }}
                .stat-value {{ font-size: 2.5em; font-weight: bold; margin: 10px 0; }}
                .stat-label {{ font-size: 0.9em; opacity: 0.9; }}
                .score {{ font-size: 3em; font-weight: bold; text-align: center; margin: 20px 0; 
                         color: {status_color}; }}
                table {{ width: 100%; border-collapse: collapse; margin-top: 20px; }}
                th {{ background-color: #3498db; color: white; padding: 12px; text-align: left; }}
                td {{ padding: 12px; border-bottom: 1px solid #ddd; }}
                tr:nth-child(even) {{ background-color: #f8f9fa; }}
                .passed {{ color: green; }}
                .failed {{ color: red; }}
                .warning {{ color: orange; }}
                .info {{ color: blue; }}
                .severity {{ font-weight: bold; }}
                .status-badge {{ display: inline-block; padding: 5px 10px; border-radius: 20px; 
                               font-weight: bold; font-size: 0.9em; }}
                .status-passed {{ background: #d4edda; color: #155724; }}
                .status-failed {{ background: #f8d7da; color: #721c24; }}
                .timestamp {{ color: #7f8c8d; text-align: right; font-size: 0.9em; margin-top: 30px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>📊 Rapport de Validation des Données</h1>
                
                <div class="summary">
                    <h2>{status_icon} Résumé Global</h2>
                    <div class="score">{report['score']:.1%}</div>
                    
                    <div class="stats">
                        <div class="stat-box">
                            <div class="stat-value">{report['total_rules']}</div>
                            <div class="stat-label">Règles Total</div>
                        </div>
                        <div class="stat-box">
                            <div class="stat-value">{report['passed']}</div>
                            <div class="stat-label">Règles Passées</div>
                        </div>
                        <div class="stat-box">
                            <div class="stat-value">{report['failed']}</div>
                            <div class="stat-label">Règles Échouées</div>
                        </div>
                        <div class="stat-box">
                            <div class="stat-value">{report['errors']}</div>
                            <div class="stat-label">Erreurs</div>
                        </div>
                        <div class="stat-box">
                            <div class="stat-value">{report['warnings']}</div>
                            <div class="stat-label">Avertissements</div>
                        </div>
                    </div>
                    
                    <div style="text-align: center; margin-top: 20px;">
                        <span class="status-badge status-{report['status']}">
                            {report['status'].upper()}
                        </span>
                    </div>
                </div>
                
                <h2>📋 Détails des Règles</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Règle</th>
                            <th>Colonne</th>
                            <th>Statut</th>
                            <th>Sévérité</th>
                            <th>Message</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
        """
        
        for result in report['details']:
            status_class = 'passed' if result['success'] else 'failed'
            status_text = '✅ PASS' if result['success'] else '❌ FAIL'
            severity_class = result['severity']
            
            html += f"""
                        <tr>
                            <td><strong>{result['rule']}</strong></td>
                            <td>{result['column'] or 'N/A'}</td>
                            <td class="{status_class}">{status_text}</td>
                            <td class="severity {severity_class}">{severity_class.upper()}</td>
                            <td>{result['message']}</td>
                            <td>{result['description']}</td>
                        </tr>
            """
        
        html += f"""
                    </tbody>
                </table>
                
                <div class="timestamp">
                    Généré le {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}
                </div>
            </div>
        </body>
        </html>
        """
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html)
    
    def _generate_markdown_report(self, report: Dict[str, Any], filepath: str):
        """Génère un rapport Markdown."""
        status_emoji = '✅' if report['status'] == 'passed' else '❌'
        
        md = f"""# Rapport de Validation des Données

## Résumé Global

{status_emoji} **Statut**: {report['status'].upper()}

📊 **Score de validation**: {report['score']:.1%}

| Métrique | Valeur |
|----------|--------|
| Règles totales | {report['total_rules']} |
| Règles passées | {report['passed']} |
| Règles échouées | {report['failed']} |
| Erreurs | {report['errors']} |
| Avertissements | {report['warnings']} |
| Informations | {report['infos']} |

## Détails des Règles

| Règle | Colonne | Statut | Sévérité | Message | Description |
|-------|---------|--------|----------|---------|-------------|
"""
        
        for result in report['details']:
            status = "✅ PASS" if result['success'] else "❌ FAIL"
            severity = result['severity'].upper()
            column = result['column'] or 'N/A'
            
            md += f"| {result['rule']} | {column} | {status} | **{severity}** | {result['message']} | {result['description']} |\n"
        
        md += f"\n\n*Rapport généré le {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}*"
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(md)
    
    def get_failed_rules(self) -> List[Dict]:
        """Retourne la liste des règles échouées."""
        return [r for r in self.results if not r['success']]
    
    def get_passed_rules(self) -> List[Dict]:
        """Retourne la liste des règles passées."""
        return [r for r in self.results if r['success']]
    
    def clear_rules(self):
        """Efface toutes les règles."""
        self.rules = []
        self.results = []

# Règles de validation spécifiques

class NotNullRule(ValidationRule):
    """Vérifie qu'une colonne n'a pas de valeurs nulles."""
    
    def validate(self, df: pd.DataFrame) -> Tuple[bool, str]:
        if self.column is None:
            return False, "Aucune colonne spécifiée pour la règle NotNull"
        
        if self.column not in df.columns:
            return False, f"Colonne '{self.column}' non trouvée"
        
        null_count = df[self.column].isnull().sum()
        if null_count > 0:
            return False, f"{null_count} valeurs nulles dans '{self.column}'"
        
        return True, f"Colonne '{self.column}' n'a pas de valeurs nulles"

class DataTypeRule(ValidationRule):
    """Vérifie le type de données d'une colonne."""
    
    def __init__(self, column: str, expected_dtype: Union[str, type], **kwargs):
        super().__init__(column, **kwargs)
        self.expected_dtype = expected_dtype
    
    def validate(self, df: pd.DataFrame) -> Tuple[bool, str]:
        if self.column not in df.columns:
            return False, f"Colonne '{self.column}' non trouvée"
        
        actual_dtype = str(df[self.column].dtype)
        expected_str = str(self.expected_dtype) if isinstance(self.expected_dtype, type) else self.expected_dtype
        
        if actual_dtype != expected_str:
            return False, (
                f"Type incorrect pour '{self.column}': "
                f"{actual_dtype} au lieu de {expected_str}"
            )
        
        return True, f"Colonne '{self.column}' a le bon type: {actual_dtype}"

class ValueRangeRule(ValidationRule):
    """Vérifie que les valeurs sont dans une plage spécifiée."""
    
    def __init__(self, column: str, min_val: float = None, 
                 max_val: float = None, **kwargs):
        super().__init__(column, **kwargs)
        self.min_val = min_val
        self.max_val = max_val
    
    def validate(self, df: pd.DataFrame) -> Tuple[bool, str]:
        if self.column not in df.columns:
            return False, f"Colonne '{self.column}' non trouvée"
        
        violations = []
        
        if self.min_val is not None:
            below_min = df[df[self.column] < self.min_val]
            if len(below_min) > 0:
                violations.append(f"{len(below_min)} valeurs < {self.min_val}")
        
        if self.max_val is not None:
            above_max = df[df[self.column] > self.max_val]
            if len(above_max) > 0:
                violations.append(f"{len(above_max)} valeurs > {self.max_val}")
        
        if violations:
            return False, f"Valeurs hors plage dans '{self.column}': {', '.join(violations)}"
        
        return True, f"Toutes les valeurs de '{self.column}' sont dans la plage [{self.min_val}, {self.max_val}]"

class UniqueRule(ValidationRule):
    """Vérifie qu'une colonne a des valeurs uniques."""
    
    def validate(self, df: pd.DataFrame) -> Tuple[bool, str]:
        if self.column is None:
            # Vérifie que chaque ligne est unique
            duplicates = df.duplicated().sum()
            if duplicates > 0:
                return False, f"{duplicates} lignes en double dans le DataFrame"
            return True, "Toutes les lignes sont uniques"
        
        if self.column not in df.columns:
            return False, f"Colonne '{self.column}' non trouvée"
        
        duplicates = df[self.column].duplicated().sum()
        if duplicates > 0:
            return False, f"{duplicates} doublons dans '{self.column}'"
        
        return True, f"Colonne '{self.column}' a des valeurs uniques"

class PatternRule(ValidationRule):
    """Vérifie qu'une colonne suit un pattern regex."""
    
    def __init__(self, column: str, pattern: str, **kwargs):
        super().__init__(column, **kwargs)
        self.pattern = pattern
    
    def validate(self, df: pd.DataFrame) -> Tuple[bool, str]:
        if self.column not in df.columns:
            return False, f"Colonne '{self.column}' non trouvée"
        
        pattern = re.compile(self.pattern)
        
        # Convertir en string pour éviter les erreurs
        series_str = df[self.column].astype(str)
        non_matching = series_str[~series_str.str.match(pattern)]
        
        if len(non_matching) > 0:
            sample = non_matching.head(3).tolist()
            sample_str = ", ".join([f"'{s}'" for s in sample])
            return False, f"{len(non_matching)} valeurs ne suivent pas le pattern. Exemples: {sample_str}"
        
        return True, f"Toutes les valeurs de '{self.column}' suivent le pattern: {self.pattern}"

class ValueInListRule(ValidationRule):
    """Vérifie que les valeurs sont dans une liste spécifiée."""
    
    def __init__(self, column: str, allowed_values: List, **kwargs):
        super().__init__(column, **kwargs)
        self.allowed_values = allowed_values
    
    def validate(self, df: pd.DataFrame) -> Tuple[bool, str]:
        if self.column not in df.columns:
            return False, f"Colonne '{self.column}' non trouvée"
        
        invalid_values = df[~df[self.column].isin(self.allowed_values)]
        
        if len(invalid_values) > 0:
            sample = invalid_values[self.column].unique()[:3]
            sample_str = ", ".join([str(s) for s in sample])
            return False, f"{len(invalid_values)} valeurs non autorisées. Exemples: {sample_str}"
        
        return True, f"Toutes les valeurs de '{self.column}' sont dans la liste autorisée"

class CorrelationRule(ValidationRule):
    """Vérifie la corrélation entre les colonnes."""
    
    def __init__(self, column1: str, column2: str, 
                 max_correlation: float = 0.9, **kwargs):
        super().__init__(None, **kwargs)
        self.column1 = column1
        self.column2 = column2
        self.max_correlation = max_correlation
    
    def validate(self, df: pd.DataFrame) -> Tuple[bool, str]:
        if self.column1 not in df.columns:
            return False, f"Colonne '{self.column1}' non trouvée"
        if self.column2 not in df.columns:
            return False, f"Colonne '{self.column2}' non trouvée"
        
        # Calculer la corrélation
        corr = df[self.column1].corr(df[self.column2])
        
        if pd.isna(corr):
            return True, f"Corrélation non calculable entre '{self.column1}' et '{self.column2}'"
        
        if abs(corr) > self.max_correlation:
            return False, (
                f"Corrélation trop élevée entre '{self.column1}' et '{self.column2}': "
                f"{corr:.3f} > {self.max_correlation}"
            )
        
        return True, f"Corrélation acceptable entre '{self.column1}' et '{self.column2}': {corr:.3f}"