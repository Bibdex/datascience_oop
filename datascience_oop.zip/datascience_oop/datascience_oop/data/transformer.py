"""
Classes pour la transformation des données.
"""

import pandas as pd
import numpy as np
from typing import Optional, Dict, Any, List, Union
from abc import ABC, abstractmethod
from sklearn.preprocessing import (
    StandardScaler, MinMaxScaler, RobustScaler,
    LabelEncoder, OneHotEncoder
)
from sklearn.impute import SimpleImputer
from ..core.base import PipelineComponent
from ..core.decorators import timing_decorator, log_execution

class DataTransformer(PipelineComponent, ABC):
    """Classe abstraite pour la transformation des données."""
    
    @abstractmethod
    def transform(self, X):
        """Transforme les données."""
        pass

class MissingValueImputer(DataTransformer):
    """Impute les valeurs manquantes."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'strategy': 'mean',  # 'mean', 'median', 'most_frequent', 'constant'
            'fill_value': None,
            'numeric_only': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.imputer = None
    
    def fit(self, X, y=None):
        """Ajuste l'imputer aux données."""
        if self.config['numeric_only']:
            # Sélectionner seulement les colonnes numériques
            numeric_cols = X.select_dtypes(include=[np.number]).columns
            X_fit = X[numeric_cols]
        else:
            X_fit = X
        
        self.imputer = SimpleImputer(
            strategy=self.config['strategy'],
            fill_value=self.config['fill_value']
        )
        self.imputer.fit(X_fit)
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def transform(self, X):
        """Transforme les données."""
        self._check_is_fitted()
        
        X_transformed = X.copy()
        
        if self.config['numeric_only']:
            numeric_cols = X.select_dtypes(include=[np.number]).columns
            X_transformed[numeric_cols] = self.imputer.transform(X[numeric_cols])
        else:
            X_transformed = self.imputer.transform(X)
        
        return X_transformed

class CategoricalEncoder(DataTransformer):
    """Encode les variables catégorielles."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'strategy': 'onehot',  # 'onehot', 'label', 'ordinal', 'target'
            'columns': None,  # Liste de colonnes spécifiques
            'drop_first': True,
            'handle_unknown': 'ignore'  # Pour OneHotEncoder
        }
        self.config = {**self.default_config, **(config or {})}
        self.encoders = {}
        self.feature_names = []
    
    def fit(self, X, y=None):
        """Ajuste l'encodeur aux données."""
        # Déterminer les colonnes à encoder
        if self.config['columns'] is None:
            # Toutes les colonnes catégorielles
            categorical_cols = X.select_dtypes(include=['object', 'category']).columns
        else:
            # Colonnes spécifiées
            categorical_cols = [col for col in self.config['columns'] if col in X.columns]
        
        if len(categorical_cols) == 0:
            self.is_fitted = True
            return self
        
        if self.config['strategy'] == 'onehot':
            self._fit_onehot(X, categorical_cols)
        elif self.config['strategy'] == 'label':
            self._fit_label(X, categorical_cols)
        elif self.config['strategy'] == 'ordinal':
            self._fit_ordinal(X, categorical_cols)
        elif self.config['strategy'] == 'target':
            if y is None:
                raise ValueError("La stratégie 'target' nécessite y")
            self._fit_target(X, categorical_cols, y)
        
        self.is_fitted = True
        return self
    
    def _fit_onehot(self, X, categorical_cols):
        """Ajuste un OneHotEncoder."""
        self.encoder = OneHotEncoder(
            drop='first' if self.config['drop_first'] else None,
            handle_unknown=self.config['handle_unknown'],
            sparse_output=False
        )
        
        # Ajuster sur les colonnes catégorielles
        self.encoder.fit(X[categorical_cols])
        
        # Obtenir les noms des features
        self.feature_names = []
        for i, col in enumerate(categorical_cols):
            categories = self.encoder.categories_[i]
            if self.config['drop_first'] and len(categories) > 1:
                categories = categories[1:]
            
            for cat in categories:
                self.feature_names.append(f"{col}_{cat}")
    
    def _fit_label(self, X, categorical_cols):
        """Ajuste un LabelEncoder pour chaque colonne."""
        for col in categorical_cols:
            le = LabelEncoder()
            le.fit(X[col].astype(str))
            self.encoders[col] = le
    
    def _fit_ordinal(self, X, categorical_cols):
        """Ajuste un encodage ordinal basé sur l'ordre alphabétique."""
        for col in categorical_cols:
            # Trier les valeurs uniques
            unique_values = sorted(X[col].dropna().unique())
            mapping = {val: idx for idx, val in enumerate(unique_values)}
            self.encoders[col] = mapping
    
    def _fit_target(self, X, categorical_cols, y):
        """Ajuste un encodage basé sur la target (moyenne de y)."""
        for col in categorical_cols:
            # Calculer la moyenne de y pour chaque catégorie
            target_means = X.groupby(col)[y.name].mean()
            self.encoders[col] = target_means.to_dict()
    
    @timing_decorator
    @log_execution
    def transform(self, X):
        """Transforme les données."""
        self._check_is_fitted()
        
        X_transformed = X.copy()
        
        if self.config['strategy'] == 'onehot':
            # Appliquer OneHotEncoder
            categorical_cols = [col for col in self.encoder.feature_names_in_]
            encoded = self.encoder.transform(X_transformed[categorical_cols])
            
            # Créer un DataFrame avec les colonnes encodées
            encoded_df = pd.DataFrame(
                encoded,
                columns=self.feature_names,
                index=X_transformed.index
            )
            
            # Supprimer les colonnes originales et ajouter les encodées
            X_transformed = X_transformed.drop(categorical_cols, axis=1)
            X_transformed = pd.concat([X_transformed, encoded_df], axis=1)
        
        elif self.config['strategy'] == 'label':
            # Appliquer LabelEncoder à chaque colonne
            for col, encoder in self.encoders.items():
                if col in X_transformed.columns:
                    X_transformed[col] = encoder.transform(X_transformed[col].astype(str))
        
        elif self.config['strategy'] == 'ordinal':
            # Appliquer l'encodage ordinal
            for col, mapping in self.encoders.items():
                if col in X_transformed.columns:
                    X_transformed[col] = X_transformed[col].map(mapping)
                    # Remplir les valeurs manquantes par -1
                    X_transformed[col] = X_transformed[col].fillna(-1)
        
        elif self.config['strategy'] == 'target':
            # Appliquer l'encodage target
            for col, mapping in self.encoders.items():
                if col in X_transformed.columns:
                    X_transformed[col] = X_transformed[col].map(mapping)
                    # Remplir les valeurs manquantes par la moyenne globale
                    X_transformed[col] = X_transformed[col].fillna(np.mean(list(mapping.values())))
        
        return X_transformed

class FeatureScaler(DataTransformer):
    """Normalise les features."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'scaler_type': 'standard',  # 'standard', 'minmax', 'robust'
            'columns': None,  # Colonnes spécifiques à normaliser
            'with_mean': True,
            'with_std': True
        }
        self.config = {**self.default_config, **(config or {})}
        self.scaler = None
        self.columns_to_scale = []
    
    def fit(self, X, y=None):
        """Ajuste le scaler aux données."""
        # Déterminer les colonnes à normaliser
        if self.config['columns'] is None:
            # Toutes les colonnes numériques
            self.columns_to_scale = X.select_dtypes(include=[np.number]).columns.tolist()
        else:
            # Colonnes spécifiées
            self.columns_to_scale = [col for col in self.config['columns'] if col in X.columns]
        
        if len(self.columns_to_scale) == 0:
            self.is_fitted = True
            return self
        
        # Sélectionner le type de scaler
        if self.config['scaler_type'] == 'standard':
            self.scaler = StandardScaler(
                with_mean=self.config['with_mean'],
                with_std=self.config['with_std']
            )
        elif self.config['scaler_type'] == 'minmax':
            self.scaler = MinMaxScaler()
        elif self.config['scaler_type'] == 'robust':
            self.scaler = RobustScaler()
        else:
            raise ValueError(f"Type de scaler non reconnu: {self.config['scaler_type']}")
        
        # Ajuster le scaler
        self.scaler.fit(X[self.columns_to_scale])
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def transform(self, X):
        """Transforme les données."""
        self._check_is_fitted()
        
        X_transformed = X.copy()
        
        if len(self.columns_to_scale) > 0:
            # Appliquer la normalisation
            scaled_values = self.scaler.transform(X_transformed[self.columns_to_scale])
            
            # Mettre à jour le DataFrame
            X_transformed[self.columns_to_scale] = scaled_values
        
        return X_transformed
    
    def inverse_transform(self, X):
        """Transforme inverse les données normalisées."""
        self._check_is_fitted()
        
        X_inverse = X.copy()
        
        if len(self.columns_to_scale) > 0:
            # Appliquer la transformation inverse
            inverse_values = self.scaler.inverse_transform(X_inverse[self.columns_to_scale])
            
            # Mettre à jour le DataFrame
            X_inverse[self.columns_to_scale] = inverse_values
        
        return X_inverse

class FeatureSelector(DataTransformer):
    """Sélectionne des features."""
    
    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)
        self.default_config = {
            'method': 'variance',  # 'variance', 'correlation', 'model', 'kbest'
            'threshold': 0.0,
            'n_features': None,
            'target_column': None
        }
        self.config = {**self.default_config, **(config or {})}
        self.selected_features = []
        self.selector = None
    
    def fit(self, X, y=None):
        """Ajuste le sélecteur de features."""
        from sklearn.feature_selection import (
            VarianceThreshold, SelectKBest, f_classif,
            RFE, SelectFromModel
        )
        from sklearn.ensemble import RandomForestClassifier
        
        if self.config['method'] == 'variance':
            self.selector = VarianceThreshold(threshold=self.config['threshold'])
            self.selector.fit(X)
            self.selected_features = X.columns[self.selector.get_support()].tolist()
        
        elif self.config['method'] == 'kbest':
            if y is None:
                raise ValueError("La méthode 'kbest' nécessite y")
            
            n_features = self.config['n_features'] or X.shape[1]
            self.selector = SelectKBest(score_func=f_classif, k=n_features)
            self.selector.fit(X, y)
            self.selected_features = X.columns[self.selector.get_support()].tolist()
        
        elif self.config['method'] == 'model':
            if y is None:
                raise ValueError("La méthode 'model' nécessite y")
            
            model = RandomForestClassifier(n_estimators=100, random_state=42)
            self.selector = SelectFromModel(model, threshold=self.config['threshold'])
            self.selector.fit(X, y)
            self.selected_features = X.columns[self.selector.get_support()].tolist()
        
        elif self.config['method'] == 'correlation':
            if y is None:
                raise ValueError("La méthode 'correlation' nécessite y")
            
            # Calculer la corrélation avec la target
            correlations = X.corrwith(y)
            abs_correlations = correlations.abs()
            
            # Sélectionner les features avec corrélation supérieure au seuil
            self.selected_features = abs_correlations[
                abs_correlations >= self.config['threshold']
            ].index.tolist()
        
        self.is_fitted = True
        return self
    
    @timing_decorator
    @log_execution
    def transform(self, X):
        """Sélectionne les features."""
        self._check_is_fitted()
        
        if self.config['method'] in ['variance', 'kbest', 'model']:
            return self.selector.transform(X)
        else:
            # Pour la méthode correlation, sélectionner manuellement
            if self.selected_features:
                return X[self.selected_features]
            else:
                return X
    
    def get_feature_importance(self):
        """Retourne l'importance des features."""
        if self.config['method'] == 'kbest' and hasattr(self.selector, 'scores_'):
            return dict(zip(self.selected_features, self.selector.scores_))
        elif self.config['method'] == 'model' and hasattr(self.selector, 'estimator_'):
            if hasattr(self.selector.estimator_, 'feature_importances_'):
                return dict(zip(self.selected_features, self.selector.estimator_.feature_importances_))
        return {}