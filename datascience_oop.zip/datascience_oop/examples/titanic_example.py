"""
Exemple complet avec le dataset Titanic.
"""

import pandas as pd
from datascience_oop import (
    DataCleaner, TitanicDataCleaner, MLPipeline, 
    ValidatedMLPipeline, CrossValidationContext
)
from datascience_oop.data.loader import DataLoader
from datascience_oop.data.validator import DataValidator, NotNullRule, DataTypeRule, ValueRangeRule
from datascience_oop.models.trainer import RandomForestTrainer, LogisticRegressionTrainer
from datascience_oop.features.scaler import StandardScaler
from datascience_oop.models.cv_strategies import KFoldStrategy, StratifiedKFoldStrategy

def titanic_example():
    """Exemple complet avec le dataset Titanic."""
    
    print("=" * 60)
    print("Exemple: Analyse du Dataset Titanic")
    print("=" * 60)
    
    # 1. Charger les données
    print("\n1. Chargement des données Titanic...")
    try:
        data = pd.read_csv('titanic.csv')
    except FileNotFoundError:
        print("   Dataset non trouvé. Génération de données synthétiques...")
        from datascience_oop.data.generator import DatasetGenerator
        generator = DatasetGenerator()
        data = generator.generate_titanic()
    
    print(f"   Shape: {data.shape}")
    print(f"   Colonnes: {list(data.columns)}")
    
    # 2. Validation spécifique Titanic
    print("\n2. Validation des données Titanic...")
    validator = DataValidator([
        NotNullRule('Survived', severity='error'),
        DataTypeRule('Age', expected_dtype='float64'),
        ValueRangeRule('Age', min_val=0, max_val=100, severity='warning'),
        NotNullRule('Name', severity='error'),
        ValueRangeRule('Fare', min_val=0, max_val=512, severity='warning'),
    ])
    
    report = validator.validate(data)
    print(f"   Score de validation: {report['score']:.1%}")
    
    # 3. Nettoyage spécifique Titanic
    print("\n3. Nettoyage des données Titanic...")
    titanic_cleaner = TitanicDataCleaner(config={
        'age_strategy': 'median',
        'cabin_strategy': 'fill_unknown',
        'embarked_strategy': 'mode',
        'encode_categorical': True,
        'extract_features': True
    })
    
    clean_data = titanic_cleaner.clean(data)
    print(f"   Données nettoyées: {clean_data.shape}")
    print(f"   Nouvelles colonnes: {[c for c in clean_data.columns if c not in data.columns]}")
    
    # 4. Pipeline avec validation
    print("\n4. Pipeline ML avec validation...")
    pipeline = ValidatedMLPipeline(
        data_loader=DataLoader(target_column='Survived', test_size=0.2, random_state=42),
        scaler=StandardScaler(),
        model=RandomForestTrainer(n_estimators=100, random_state=42)
    )
    
    results = pipeline.run_with_validation(clean_data, fail_fast=False)
    
    # 5. Comparaison de modèles
    print("\n5. Comparaison de modèles...")
    models = {
        'Random Forest': RandomForestTrainer(n_estimators=100, random_state=42),
        'Logistic Regression': LogisticRegressionTrainer(max_iter=1000, random_state=42)
    }
    
    for model_name, model in models.items():
        pipeline.components['model'] = model
        results = pipeline.run(clean_data)
        print(f"   {model_name}: Accuracy = {results['accuracy']:.3f}")
    
    # 6. Validation croisée
    print("\n6. Validation croisée...")
    cv_context = CrossValidationContext()
    
    strategies = [
        KFoldStrategy(n_splits=5, shuffle=True, random_state=42),
        StratifiedKFoldStrategy(n_splits=5, shuffle=True, random_state=42)
    ]
    
    X = clean_data.drop('Survived', axis=1) if 'Survived' in clean_data.columns else clean_data
    y = clean_data['Survived'] if 'Survived' in clean_data.columns else None
    
    if y is not None:
        model = RandomForestTrainer(n_estimators=50, random_state=42).model_class()
        
        for strategy in strategies:
            cv_context.set_strategy(strategy)
            cv_results = cv_context.perform_cv(model, X, y)
            print(f"   {strategy.get_name()}: Score moyen = {cv_results['mean']:.3f}")
    
    # 7. Feature importance
    print("\n7. Analyse d'importance des features...")
    if 'feature_importance' in results:
        importance_df = pd.DataFrame(
            results['feature_importance'].items(),
            columns=['Feature', 'Importance']
        ).sort_values('Importance', ascending=False)
        
        print("\n   Top 10 des features les plus importantes:")
        for idx, row in importance_df.head(10).iterrows():
            print(f"   {row['Feature']}: {row['Importance']:.3f}")
    
    print("\n" + "=" * 60)
    print("Analyse Titanic terminée!")
    print("=" * 60)
    
    return {
        'data': data,
        'clean_data': clean_data,
        'validation_report': report,
        'results': results
    }

if __name__ == "__main__":
    titanic_example()