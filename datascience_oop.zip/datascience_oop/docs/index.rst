Datascience OOP Documentation
==============================

Un package Python pour la data science orientée objet, conçu pour les exercices pratiques.

.. toctree::
   :maxdepth: 2
   :caption: Contenu:

   installation
   quickstart
   modules
   examples
   api

Installation
------------

.. include:: installation.rst

Quick Start
-----------

.. include:: quickstart.rst

Modules
-------

.. include:: modules.rst

Exemples
--------

.. include:: examples.rst

API Reference
-------------

.. include:: api.rst