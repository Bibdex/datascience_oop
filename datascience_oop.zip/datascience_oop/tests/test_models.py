import pytest
import numpy as np
from sklearn.datasets import make_classification
from datascience_oop.models import (
    ModelTrainer, ModelEvaluator,
    CrossValidationContext, KFoldStrategy, StratifiedKFoldStrategy
)

class TestModelTrainer:
    @pytest.fixture
    def sample_data(self):
        """Crée des données de test."""
        X, y = make_classification(
            n_samples=100, n_features=5,
            n_classes=2, random_state=42
        )
        return X, y
    
    def test_model_trainer_fit(self, sample_data):
        """Test l'entraînement du modèle."""
        X, y = sample_data
        trainer = ModelTrainer()
        
        trainer.fit(X, y)
        
        assert trainer.model is not None
        assert hasattr(trainer.model, 'predict')
    
    def test_model_trainer_predict(self, sample_data):
        """Test les prédictions du modèle."""
        X, y = sample_data
        trainer = ModelTrainer()
        
        trainer.fit(X, y)
        predictions = trainer.transform(X)
        
        assert len(predictions) == len(X)
        assert predictions.shape == y.shape
    
    def test_custom_model(self):
        """Test avec un modèle personnalisé."""
        from sklearn.linear_model import LogisticRegression
        
        X = np.random.randn(50, 3)
        y = np.random.randint(0, 2, 50)
        
        trainer = ModelTrainer(
            model_class=LogisticRegression,
            max_iter=1000
        )
        
        trainer.fit(X, y)
        predictions = trainer.transform(X)
        
        assert len(predictions) == len(X)

class TestModelEvaluator:
    @pytest.fixture
    def sample_predictions(self):
        """Crée des prédictions de test."""
        y_true = np.array([0, 1, 0, 1, 0])
        y_pred = np.array([0, 1, 0, 0, 1])
        y_pred_proba = np.array([
            [0.8, 0.2],
            [0.3, 0.7],
            [0.9, 0.1],
            [0.4, 0.6],
            [0.2, 0.8]
        ])
        return y_true, y_pred, y_pred_proba
    
    def test_evaluator_basic(self, sample_predictions):
        """Test l'évaluateur de base."""
        y_true, y_pred, _ = sample_predictions
        evaluator = ModelEvaluator()
        
        metrics = evaluator.evaluate(y_true, y_pred)
        
        assert 'accuracy' in metrics
        assert 'report' in metrics
        assert 'confusion_matrix' in metrics
        assert 0 <= metrics['accuracy'] <= 1
    
    def test_evaluator_with_proba(self, sample_predictions):
        """Test l'évaluateur avec probabilités."""
        y_true, y_pred, y_pred_proba = sample_predictions
        evaluator = ModelEvaluator()
        
        metrics = evaluator.evaluate(y_true, y_pred, y_pred_proba)
        
        assert 'roc_auc' in metrics
        assert 'roc_curve' in metrics
        assert 0 <= metrics['roc_auc'] <= 1

class TestCrossValidation:
    @pytest.fixture
    def sample_data(self):
        """Crée des données de test pour CV."""
        X, y = make_classification(
            n_samples=100, n_features=5,
            n_classes=2, random_state=42
        )
        return X, y
    
    def test_kfold_strategy(self, sample_data):
        """Test la stratégie K-Fold."""
        X, y = sample_data
        strategy = KFoldStrategy(n_splits=5)
        
        from sklearn.ensemble import RandomForestClassifier
        model = RandomForestClassifier(n_estimators=10)
        
        results = strategy.evaluate(model, X, y)
        
        assert 'mean' in results
        assert 'std' in results
        assert 'scores' in results
        assert len(results['scores']) == 5
    
    def test_stratified_kfold_strategy(self, sample_data):
        """Test la stratégie Stratified K-Fold."""
        X, y = sample_data
        strategy = StratifiedKFoldStrategy(n_splits=5)
        
        from sklearn.ensemble import RandomForestClassifier
        model = RandomForestClassifier(n_estimators=10)
        
        results = strategy.evaluate(model, X, y)
        
        assert 'mean' in results
        assert 'std' in results
    
    def test_cv_context(self, sample_data):
        """Test le contexte de validation croisée."""
        X, y = sample_data
        
        strategies = [
            KFoldStrategy(n_splits=5),
            StratifiedKFoldStrategy(n_splits=5)
        ]
        
        context = CrossValidationContext()
        
        from sklearn.ensemble import RandomForestClassifier
        model = RandomForestClassifier(n_estimators=10)
        
        # Test d'une seule stratégie
        results = context.perform_cv(model, X, y)
        assert 'mean' in results
        
        # Test de comparaison
        comparison = context.compare_strategies(strategies, model, X, y)
        assert len(comparison) == 2
        assert all(key in comparison for key in [
            'KFold(n_splits=5)',
            'StratifiedKFold(n_splits=5)'
        ])