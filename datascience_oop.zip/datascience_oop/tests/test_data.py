import pytest
import pandas as pd
import numpy as np
import tempfile
import os
from datascience_oop.data import (
    DataCleaner, TitanicDataCleaner, 
    DataValidator, NotNullRule, DataTypeRule
)

class TestDataCleaner:
    @pytest.fixture
    def sample_data(self):
        """Crée des données de test."""
        data = pd.DataFrame({
            'A': [1, 2, 3, 4, 5],
            'B': [1.0, 2.0, np.nan, 4.0, 5.0],
            'C': ['a', 'b', 'c', 'd', 'e'],
            'D': [10, 20, 30, 40, 1000]  # Outlier
        })
        return data
    
    def test_basic_cleaner(self, sample_data):
        """Test le nettoyeur de base."""
        cleaner = DataCleaner()
        cleaned = cleaner.clean(sample_data)
        
        assert isinstance(cleaned, pd.DataFrame)
        assert len(cleaned) <= len(sample_data)
    
    def test_titanic_cleaner(self):
        """Test le nettoyeur Titanic."""
        # Créer des données Titanic de test
        titanic_data = pd.DataFrame({
            'PassengerId': [1, 2, 3],
            'Survived': [0, 1, 0],
            'Pclass': [1, 2, 3],
            'Name': ['A', 'B', 'C'],
            'Sex': ['male', 'female', 'male'],
            'Age': [22.0, np.nan, 35.0],
            'SibSp': [1, 0, 1],
            'Parch': [0, 0, 0],
            'Ticket': ['A', 'B', 'C'],
            'Fare': [7.25, 71.28, 8.05],
            'Cabin': [None, 'C85', None],
            'Embarked': ['S', 'C', 'S']
        })
        
        cleaner = TitanicDataCleaner({
            'age_strategy': 'median',
            'encode_categorical': True
        })
        
        cleaned = cleaner.clean(titanic_data)
        
        # Vérifier que les valeurs manquantes sont traitées
        assert not cleaned['Age'].isnull().any()
        
        # Vérifier l'encodage
        assert 'Sex' in cleaned.columns
        assert cleaned['Sex'].dtype in [np.int64, np.float64]

class TestDataValidator:
    @pytest.fixture
    def sample_data(self):
        """Crée des données de test."""
        return pd.DataFrame({
            'id': [1, 2, 3, 4, 5],
            'name': ['Alice', 'Bob', 'Charlie', 'David', 'Eve'],
            'age': [25, 30, 35, 40, 150],  # Valeur hors plage
            'email': ['a@b.com', 'b@c.com', None, 'd@e.com', 'e@f.com']  # Valeur manquante
        })
    
    def test_not_null_rule(self, sample_data):
        """Test la règle NotNull."""
        rule = NotNullRule(column='email')
        success, message = rule.validate(sample_data)
        
        assert not success
        assert 'valeurs nulles' in message
    
    def test_data_type_rule(self, sample_data):
        """Test la règle DataType."""
        rule = DataTypeRule(column='age', expected_dtype='int64')
        success, message = rule.validate(sample_data)
        
        assert success
    
    def test_validator_complete(self, sample_data):
        """Test le validateur complet."""
        validator = DataValidator([
            NotNullRule('email'),
            DataTypeRule('age', 'int64'),
            NotNullRule('name')
        ])
        
        report = validator.validate(sample_data)
        
        assert 'total_rules' in report
        assert 'passed' in report
        assert 'failed' in report
        assert report['score'] >= 0 and report['score'] <= 1
    
    def test_report_generation(self, sample_data, tmp_path):
        """Test la génération de rapports."""
        validator = DataValidator([
            NotNullRule('email'),
            NotNullRule('name')
        ])
        
        validator.validate(sample_data)
        
        # Test JSON
        json_path = tmp_path / 'report.json'
        validator.save_report(str(json_path), 'json')
        assert os.path.exists(json_path)
        
        # Test HTML
        html_path = tmp_path / 'report.html'
        validator.save_report(str(html_path), 'html')
        assert os.path.exists(html_path)
        
        # Test Markdown
        md_path = tmp_path / 'report.md'
        validator.save_report(str(md_path), 'markdown')
        assert os.path.exists(md_path)

class TestDataLoader:
    def test_data_loader(self):
        """Test le chargeur de données."""
        from datascience_oop.data.loader import DataLoader
        
        data = pd.DataFrame({
            'feature1': [1, 2, 3, 4, 5],
            'feature2': [10, 20, 30, 40, 50],
            'target': [0, 1, 0, 1, 0]
        })
        
        loader = DataLoader(target_column='target', test_size=0.4)
        result = loader.transform(data)
        
        assert 'X_train' in result
        assert 'X_test' in result
        assert 'y_train' in result
        assert 'y_test' in result
        
        # Vérifier les tailles
        assert len(result['X_train']) == 3  # 60% de 5
        assert len(result['X_test']) == 2   # 40% de 5