import pytest
import pandas as pd
import numpy as np
import tempfile
import os
from datascience_oop.pipelines import (
    MLPipeline, ValidatedMLPipeline, MLPipelineWithCV
)
from datascience_oop.data import DataLoader, StandardScaler
from datascience_oop.models import ModelTrainer

class TestMLPipeline:
    @pytest.fixture
    def sample_data(self):
        """Crée des données de test."""
        np.random.seed(42)
        n_samples = 100
        data = pd.DataFrame({
            'feature1': np.random.randn(n_samples),
            'feature2': np.random.randn(n_samples),
            'target': np.random.choice([0, 1], n_samples)
        })
        return data
    
    @pytest.fixture
    def pipeline_components(self):
        """Crée les composants du pipeline."""
        return {
            'data_loader': DataLoader(target_column='target'),
            'scaler': StandardScaler(),
            'model': ModelTrainer(n_estimators=10)
        }
    
    def test_pipeline_creation(self, pipeline_components):
        """Test la création du pipeline."""
        pipeline = MLPipeline(pipeline_components)
        
        assert pipeline is not None
        assert hasattr(pipeline, 'components')
        assert len(pipeline.components) == 3
    
    def test_pipeline_execution(self, sample_data, pipeline_components):
        """Test l'exécution du pipeline."""
        pipeline = MLPipeline(pipeline_components)
        results = pipeline.run(sample_data)
        
        assert 'X_train' in results
        assert 'X_test' in results
        assert 'y_train' in results
        assert 'y_test' in results
        assert 'y_pred' in results
    
    def test_pipeline_evaluation(self, sample_data, pipeline_components):
        """Test l'évaluation du pipeline."""
        pipeline = MLPipeline(pipeline_components)
        results = pipeline.run(sample_data)
        metrics = pipeline.evaluate(results)
        
        assert 'accuracy' in metrics
        assert 'report' in metrics
        assert 0 <= metrics['accuracy'] <= 1
    
    def test_pipeline_serialization(self, sample_data, pipeline_components, tmp_path):
        """Test la sérialisation du pipeline."""
        pipeline = MLPipeline(pipeline_components)
        pipeline.run(sample_data)
        
        # Sauvegarder
        save_path = tmp_path / 'pipeline.pkl'
        pipeline.save(str(save_path))
        assert os.path.exists(save_path)
        
        # Charger
        loaded_pipeline = MLPipeline.load(str(save_path))
        assert loaded_pipeline is not None
        assert hasattr(loaded_pipeline, 'components')

class TestValidatedMLPipeline:
    @pytest.fixture
    def sample_data_with_issues(self):
        """Crée des données avec des problèmes de validation."""
        data = pd.DataFrame({
            'feature1': [1, 2, 3, 4, 5],
            'feature2': [10, 20, None, 40, 50],  # Valeur manquante
            'target': [0, 1, 0, 1, 0]
        })
        return data
    
    def test_validation_pipeline(self, sample_data_with_issues):
        """Test le pipeline avec validation."""
        from datascience_oop.data.validator import NotNullRule
        
        components = {
            'data_loader': DataLoader(target_column='target'),
            'scaler': StandardScaler(),
            'model': ModelTrainer(n_estimators=10)
        }
        
        rules = [
            NotNullRule('feature2')
        ]
        
        pipeline = ValidatedMLPipeline(components, rules)
        
        # Test avec fail_fast=False
        results = pipeline.run_with_validation(
            sample_data_with_issues, 
            fail_fast=False
        )
        assert results is not None
        
        # Test avec fail_fast=True (doit échouer)
        with pytest.raises(ValueError):
            pipeline.run_with_validation(
                sample_data_with_issues, 
                fail_fast=True
            )

class TestMLPipelineWithCV:
    @pytest.fixture
    def sample_data(self):
        """Crée des données de test pour CV."""
        np.random.seed(42)
        n_samples = 100
        X = np.random.randn(n_samples, 5)
        y = np.random.choice([0, 1], n_samples)
        return X, y
    
    def test_cv_pipeline(self, sample_data):
        """Test le pipeline avec validation croisée."""
        from datascience_oop.models.cv_strategies import KFoldStrategy
        
        X, y = sample_data
        data = pd.DataFrame(X)
        data['target'] = y
        
        components = {
            'data_loader': DataLoader(target_column='target'),
            'scaler': StandardScaler(),
            'model': ModelTrainer(n_estimators=10)
        }
        
        cv_strategy = KFoldStrategy(n_splits=5)
        pipeline = MLPipelineWithCV(components, cv_strategy)
        
        # Exécuter le pipeline
        results = pipeline.run(data)
        
        # Tester la validation croisée
        cv_results = pipeline.cross_validate(X, y)
        assert 'mean' in cv_results
        assert 'std' in cv_results
    
    def test_hyperparameter_tuning(self, sample_data):
        """Test l'optimisation d'hyperparamètres."""
        X, y = sample_data
        data = pd.DataFrame(X)
        data['target'] = y
        
        components = {
            'data_loader': DataLoader(target_column='target'),
            'scaler': StandardScaler(),
            'model': ModelTrainer()
        }
        
        pipeline = MLPipelineWithCV(components)
        
        # Définir la grille d'hyperparamètres
        param_grid = {
            'n_estimators': [10, 50],
            'max_depth': [None, 5, 10]
        }
        
        # Lancer l'optimisation
        tuning_results = pipeline.hyperparameter_tuning(
            param_grid, X, y
        )
        
        assert 'best_params' in tuning_results
        assert 'best_score' in tuning_results
        assert 'cv_results' in tuning_results
        assert 0 <= tuning_results['best_score'] <= 1