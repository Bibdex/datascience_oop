"""
Générateur de datasets pour les exercices OOP.
"""
import pandas as pd
import numpy as np
import json
from datetime import datetime, timedelta

class DatasetGenerator:
    """Générateur de datasets pour les exercices."""
    
    @staticmethod
    def generate_titanic(n_samples=891):
        """Génère le dataset Titanic."""
        np.random.seed(42)
        
        data = {
            'PassengerId': range(1, n_samples + 1),
            'Survived': np.random.choice([0, 1], n_samples, p=[0.62, 0.38]),
            'Pclass': np.random.choice([1, 2, 3], n_samples, p=[0.24, 0.21, 0.55]),
            'Name': [f'Passenger_{i}' for i in range(1, n_samples + 1)],
            'Sex': np.random.choice(['male', 'female'], n_samples, p=[0.65, 0.35]),
            'Age': np.random.normal(29, 14, n_samples).clip(0.42, 80).round(1),
            'SibSp': np.random.poisson(0.5, n_samples).clip(0, 8),
            'Parch': np.random.poisson(0.4, n_samples).clip(0, 6),
            'Ticket': [f'Ticket_{np.random.randint(1000, 9999)}' for _ in range(n_samples)],
            'Fare': np.random.exponential(32, n_samples).clip(0, 512).round(2),
            'Cabin': [f'{chr(65 + np.random.randint(0, 7))}{np.random.randint(1, 101)}'
                     if np.random.random() > 0.77 else np.nan
                     for _ in range(n_samples)],
            'Embarked': np.random.choice(['C', 'Q', 'S', np.nan], n_samples, p=[0.19, 0.09, 0.72, 0.0])
        }
        
        df = pd.DataFrame(data)
        
        # Ajouter des patterns réalistes
        df.loc[df['Pclass'] == 1, 'Fare'] *= 1.5
        df.loc[(df['Sex'] == 'female') | (df['Age'] < 16), 'Survived'] = np.random.choice(
            [0, 1], sum((df['Sex'] == 'female') | (df['Age'] < 16)), p=[0.3, 0.7]
        )
        
        # Ajouter des valeurs manquantes
        df.loc[np.random.choice(df.index, size=int(n_samples * 0.2), replace=False), 'Age'] = np.nan
        df.loc[np.random.choice(df.index, size=int(n_samples * 0.78), replace=False), 'Cabin'] = np.nan
        
        df.to_csv('titanic.csv', index=False)
        print(f"Titanic dataset généré: {df.shape[0]} lignes, {df.shape[1]} colonnes")
        return df
    
    @staticmethod
    def generate_customer_churn(n_samples=1000):
        """Génère le dataset Customer Churn."""
        np.random.seed(42)
        
        customer_ids = [f'CUST{str(i).zfill(5)}' for i in range(n_samples)]
        
        data = {
            'CustomerID': customer_ids,
            'CreditScore': np.random.normal(650, 100, n_samples).clip(300, 850).astype(int),
            'Geography': np.random.choice(['France', 'Germany', 'Spain'], n_samples, p=[0.5, 0.25, 0.25]),
            'Gender': np.random.choice(['Male', 'Female'], n_samples, p=[0.55, 0.45]),
            'Age': np.random.normal(38, 10, n_samples).clip(18, 70).astype(int),
            'Tenure': np.random.choice(range(0, 11), n_samples, p=[0.05, 0.1, 0.15, 0.2, 0.15, 0.1, 0.08, 0.07, 0.05, 0.03, 0.02]),
            'Balance': np.random.exponential(75000, n_samples).clip(0, 250000).round(2),
            'NumOfProducts': np.random.choice([1, 2, 3, 4], n_samples, p=[0.5, 0.35, 0.1, 0.05]),
            'HasCrCard': np.random.choice([0, 1], n_samples, p=[0.3, 0.7]),
            'IsActiveMember': np.random.choice([0, 1], n_samples, p=[0.5, 0.5]),
            'EstimatedSalary': np.random.uniform(15000, 150000, n_samples).round(2),
        }
        
        df = pd.DataFrame(data)
        
        # Calculer la probabilité de churn
        churn_prob = (
            0.3 * (df['Balance'] < 10000) +
            0.25 * (df['NumOfProducts'] == 1) +
            0.2 * (df['IsActiveMember'] == 0) +
            0.15 * (df['CreditScore'] < 600) +
            0.1 * (df['Tenure'] < 2) +
            0.05 * (df['Geography'] == 'Germany') +
            np.random.normal(0, 0.1, n_samples)
        )
        
        # Normaliser
        churn_prob = (churn_prob - churn_prob.min()) / (churn_prob.max() - churn_prob.min())
        churn_prob = churn_prob.clip(0, 1)
        
        # Générer les labels
        df['Churn'] = (churn_prob > 0.5).astype(int)
        
        # Ajuster le taux de churn (~20%)
        current_rate = df['Churn'].mean()
        if current_rate < 0.15:
            threshold = np.percentile(churn_prob, 80)
            df['Churn'] = (churn_prob > threshold).astype(int)
        elif current_rate > 0.25:
            threshold = np.percentile(churn_prob, 70)
            df['Churn'] = (churn_prob > threshold).astype(int)
        
        df.to_csv('customer_churn.csv', index=False)
        print(f"Customer Churn dataset généré: {df.shape[0]} lignes, {df.shape[1]} colonnes")
        print(f"Taux de churn: {df['Churn'].mean():.1%}")
        return df
    
    @classmethod
    def generate_all(cls):
        """Génère tous les datasets."""
        print("Génération de tous les datasets...")
        titanic = cls.generate_titanic()
        print()
        churn = cls.generate_customer_churn()
        print("\nTous les datasets ont été générés avec succès!")
        return {'titanic': titanic, 'churn': churn}

if __name__ == "__main__":
    generator = DatasetGenerator()
    generator.generate_all()