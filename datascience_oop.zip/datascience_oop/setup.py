from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="datascience-oop",
    version="1.0.0",
    author="Abib DIATTA",
    author_email="abib.diatta@gmail.com",
    description="Un package OOP pour la data science avec design patterns",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/bibdex/datascience-oop",
    packages=find_packages(include=['datascience_oop', 'datascience_oop.*']),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "black>=23.0",
            "flake8>=6.0",
            "mypy>=1.0",
            "pre-commit>=3.0",
        ],
        "docs": [
            "sphinx>=7.0",
            "sphinx-rtd-theme>=1.0",
            "sphinx-autodoc-typehints>=1.0",
        ],
        "notebooks": [
            "jupyter>=1.0",
            "jupyterlab>=4.0",
            "ipywidgets>=8.0",
        ],
        "full": [
            "seaborn>=0.12",
            "plotly>=5.0",
            "prophet>=1.0",
            "nltk>=3.0",
            "tensorflow>=2.10",
        ]
    },
    include_package_data=True,
    package_data={
        "datascience_oop": ["py.typed"],
        "": ["*.json", "*.csv", "*.txt"],
    },
    entry_points={
        "console_scripts": [
            "datascience-oop-generate=scripts.generate_datasets:main",
            "datascience-oop-verify=scripts.verify_datasets:main",
        ],
    },
    project_urls={
        "Documentation": "https://datascience-oop.readthedocs.io",
        "Source Code": "https://github.com/bibdex/datascience-oop",
        "Issue Tracker": "https://github.com/bibdex/datascience-oop/issues",
    },
)