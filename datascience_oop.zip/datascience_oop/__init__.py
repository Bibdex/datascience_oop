"""
Datascience OOP - Un package pour la data science orientée objet.
"""

__version__ = '1.0.0'
__author__ = 'Abib DIATTA'
__email__ = 'abib.diatta@gmail.com'

# Import des classes principales
from .core.base import PipelineComponent, ValidationRule
from .data.loader import DataLoader
from .data.cleaner import DataCleaner, TitanicDataCleaner
from .data.validator import DataValidator
from .models.trainer import ModelTrainer
from .models.cv_strategies import CrossValidationContext, KFoldStrategy
from .pipelines.ml_pipeline import MLPipeline, ValidatedMLPipeline

# Décorateurs
from .core.decorators import timing_decorator, log_execution

# Utilitaires
from .utils.logging import setup_logger

__all__ = [
    # Core
    'PipelineComponent',
    'ValidationRule',
    
    # Data
    'DataLoader',
    'DataCleaner',
    'TitanicDataCleaner',
    'DataValidator',
    
    # Models
    'ModelTrainer',
    'CrossValidationContext',
    'KFoldStrategy',
    
    # Pipelines
    'MLPipeline',
    'ValidatedMLPipeline',
    
    # Decorators
    'timing_decorator',
    'log_execution',
    
    # Utils
    'setup_logger',
]