# Datascience OOP Package

Un package Python pour la data science orientée objet avec implémentation de design patterns.

##  Installation

```bash
# Installation depuis PyPI (futur)
pip install datascience-oop

# Installation depuis le code source
git clone https://github.com/votreusername/datascience-oop.git
cd datascience-oop
pip install -e .

# Avec les dépendances complètes
pip install -e ".[full]"

# Pour le développement
pip install -e ".[dev,docs,notebooks]"